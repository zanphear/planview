--
-- PostgreSQL database dump
--

-- Dumped from database version 16.6
-- Dumped by pg_dump version 16.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.activities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid,
    entity_name character varying(500),
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.activities OWNER TO planview;

--
-- Name: ai_chat_messages; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.ai_chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    tool_calls jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_chat_messages OWNER TO planview;

--
-- Name: ai_chat_sessions; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.ai_chat_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) DEFAULT 'New Chat'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_chat_sessions OWNER TO planview;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO planview;

--
-- Name: analysis_reports; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.analysis_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    report_type character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    content text,
    parameters jsonb,
    status character varying(20) DEFAULT 'generating'::character varying NOT NULL,
    generation_time_seconds double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.analysis_reports OWNER TO planview;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    filename character varying(500) NOT NULL,
    file_path character varying(1000) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(255) NOT NULL,
    task_id uuid NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.attachments OWNER TO planview;

--
-- Name: candidate_events; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.candidate_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    candidate_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    event_date date,
    interviewer_id uuid,
    outcome character varying(20),
    notes text,
    rejection_reason character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.candidate_events OWNER TO planview;

--
-- Name: candidates; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.candidates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    phone character varying(50),
    position_applied character varying(255),
    source character varying(50),
    status character varying(20) DEFAULT 'applied'::character varying NOT NULL,
    applied_date date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.candidates OWNER TO planview;

--
-- Name: career_pathways; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.career_pathways (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    levels jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.career_pathways OWNER TO planview;

--
-- Name: checklists; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.checklists (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(500) NOT NULL,
    is_completed boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    task_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.checklists OWNER TO planview;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.clients OWNER TO planview;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    body text NOT NULL,
    task_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.comments OWNER TO planview;

--
-- Name: competencies; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.competencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(50),
    description text,
    requires_certification boolean DEFAULT false NOT NULL,
    certification_validity_months integer,
    levels jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.competencies OWNER TO planview;

--
-- Name: compliance_items; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.compliance_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    item_type character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    reference_number character varying(255),
    issue_date date,
    expiry_date date,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    alert_days jsonb,
    document_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_items OWNER TO planview;

--
-- Name: custom_field_values; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.custom_field_values (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    value text,
    field_id uuid NOT NULL,
    task_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.custom_field_values OWNER TO planview;

--
-- Name: custom_fields; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.custom_fields (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    field_type character varying(20) DEFAULT 'text'::character varying NOT NULL,
    options text,
    sort_order integer DEFAULT 0 NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.custom_fields OWNER TO planview;

--
-- Name: development_checkpoints; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.development_checkpoints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    checkpoint_date date NOT NULL,
    reviewer_id uuid,
    notes text,
    overall_assessment character varying(20) NOT NULL,
    actions jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.development_checkpoints OWNER TO planview;

--
-- Name: development_goals; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.development_goals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    goal_type character varying(50),
    linked_competency_id uuid,
    target_date date,
    status character varying(20) DEFAULT 'not_started'::character varying NOT NULL,
    evidence text,
    cost_estimate double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    priority character varying(20),
    progress integer DEFAULT 0 NOT NULL,
    year integer,
    linked_objective_id uuid,
    actual_cost double precision,
    completed_date date
);


ALTER TABLE public.development_goals OWNER TO planview;

--
-- Name: development_milestones; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.development_milestones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    target_date date NOT NULL,
    completed_date date,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    year integer NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.development_milestones OWNER TO planview;

--
-- Name: development_plans; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.development_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    review_period_id uuid,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    career_aspiration text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    horizon_years integer,
    start_date date,
    end_date date,
    career_pathway_id uuid,
    overall_progress integer DEFAULT 0 NOT NULL,
    total_budget double precision
);


ALTER TABLE public.development_plans OWNER TO planview;

--
-- Name: early_talent_cohorts; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.early_talent_cohorts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    programme_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    intake_date date NOT NULL,
    expected_end_date date,
    status character varying(20) DEFAULT 'forming'::character varying NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.early_talent_cohorts OWNER TO planview;

--
-- Name: early_talent_milestones; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.early_talent_milestones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    participant_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    milestone_type character varying(50) NOT NULL,
    target_date date,
    completed_date date,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    evidence text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.early_talent_milestones OWNER TO planview;

--
-- Name: early_talent_participants; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.early_talent_participants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    programme_id uuid NOT NULL,
    cohort_id uuid,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    mentor_id uuid,
    buddy_id uuid,
    development_plan_id uuid,
    status character varying(20) DEFAULT 'enrolled'::character varying NOT NULL,
    qualification_target character varying(500),
    university character varying(255),
    qualification_level character varying(50),
    qualification_progress integer DEFAULT 0 NOT NULL,
    start_date date,
    expected_end_date date,
    actual_end_date date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.early_talent_participants OWNER TO planview;

--
-- Name: early_talent_programmes; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.early_talent_programmes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    programme_type character varying(50) NOT NULL,
    description text,
    start_date date NOT NULL,
    end_date date,
    duration_months integer,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    max_cohort_size integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.early_talent_programmes OWNER TO planview;

--
-- Name: early_talent_rotation_assignments; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.early_talent_rotation_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    participant_id uuid NOT NULL,
    rotation_id uuid NOT NULL,
    supervisor_id uuid,
    start_date date NOT NULL,
    end_date date,
    status character varying(20) DEFAULT 'scheduled'::character varying NOT NULL,
    assessment text,
    rating integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.early_talent_rotation_assignments OWNER TO planview;

--
-- Name: early_talent_rotations; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.early_talent_rotations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    programme_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    department character varying(255),
    duration_weeks integer NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    required_competencies jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.early_talent_rotations OWNER TO planview;

--
-- Name: feedback; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.feedback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    type character varying(20) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.feedback OWNER TO planview;

--
-- Name: key_results; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.key_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    objective_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    target_value double precision,
    current_value double precision,
    unit character varying(50),
    measurement_type character varying(20) DEFAULT 'numeric'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.key_results OWNER TO planview;

--
-- Name: kudos; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.kudos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    from_user_id uuid NOT NULL,
    to_user_id uuid NOT NULL,
    message character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.kudos OWNER TO planview;

--
-- Name: leave_allowances; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.leave_allowances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    year integer NOT NULL,
    entitlement_days integer DEFAULT 25 NOT NULL,
    carried_forward integer DEFAULT 0 NOT NULL,
    used_days integer DEFAULT 0 NOT NULL,
    booked_days integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.leave_allowances OWNER TO planview;

--
-- Name: leave_requests; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.leave_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    leave_type character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    days integer NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    approved_by uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.leave_requests OWNER TO planview;

--
-- Name: lookup_values; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.lookup_values (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    category character varying(50) NOT NULL,
    value character varying(100) NOT NULL,
    label character varying(255),
    colour character varying(20),
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lookup_values OWNER TO planview;

--
-- Name: meeting_actions; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.meeting_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    meeting_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    owner_id uuid,
    carried_from_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meeting_actions OWNER TO planview;

--
-- Name: meetings; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.meetings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    manager_id uuid NOT NULL,
    report_id uuid NOT NULL,
    scheduled_date date NOT NULL,
    actual_date date,
    notes text,
    mood character varying(20),
    status character varying(20) DEFAULT 'scheduled'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meetings OWNER TO planview;

--
-- Name: milestones; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.milestones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    date date NOT NULL,
    colour character varying(7) DEFAULT '#E44332'::character varying NOT NULL,
    project_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.milestones OWNER TO planview;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    event_type character varying(64) NOT NULL,
    title character varying(255) NOT NULL,
    body text,
    is_read boolean DEFAULT false NOT NULL,
    link character varying(512),
    actor_id uuid,
    task_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO planview;

--
-- Name: objectives; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.objectives (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    review_period_id uuid,
    parent_id uuid,
    title character varying(500) NOT NULL,
    description text,
    category character varying(50),
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    weight double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.objectives OWNER TO planview;

--
-- Name: onboarding_checklist_items; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.onboarding_checklist_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    checklist_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    assigned_to uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_checklist_items OWNER TO planview;

--
-- Name: onboarding_checklists; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.onboarding_checklists (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    template_id uuid,
    checklist_type character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'in_progress'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_checklists OWNER TO planview;

--
-- Name: onboarding_template_items; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.onboarding_template_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    template_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    default_assignee_role character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_template_items OWNER TO planview;

--
-- Name: onboarding_templates; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.onboarding_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    template_type character varying(20) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_templates OWNER TO planview;

--
-- Name: person_documents; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.person_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    document_type character varying(50) NOT NULL,
    filename character varying(500) NOT NULL,
    file_path character varying(1000) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(255) NOT NULL,
    expiry_date date,
    uploaded_by uuid NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.person_documents OWNER TO planview;

--
-- Name: person_profiles; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.person_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    job_title character varying(255),
    department character varying(255),
    manager_id uuid,
    contract_type character varying(50),
    contract_start date,
    contract_end date,
    probation_end date,
    location character varying(255),
    phone character varying(50),
    employee_id character varying(100),
    notes text,
    date_of_birth date,
    partner_name character varying(255),
    number_of_kids integer,
    kids_details text,
    interests text,
    dietary_requirements character varying(255),
    emergency_contact character varying(500),
    personal_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.person_profiles OWNER TO planview;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    colour character varying(7) DEFAULT '#4186E0'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    is_favourite boolean DEFAULT false NOT NULL,
    custom_statuses json,
    client_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_project_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'archived'::character varying])::text[])))
);


ALTER TABLE public.projects OWNER TO planview;

--
-- Name: pulse_responses; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.pulse_responses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    survey_id uuid NOT NULL,
    user_id uuid,
    morale integer,
    workload integer,
    support integer,
    comments text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pulse_responses OWNER TO planview;

--
-- Name: pulse_surveys; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.pulse_surveys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    end_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pulse_surveys OWNER TO planview;

--
-- Name: review_cycles; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.review_cycles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    status character varying(20) DEFAULT 'setup'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.review_cycles OWNER TO planview;

--
-- Name: review_periods; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.review_periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.review_periods OWNER TO planview;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cycle_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    reviewer_id uuid NOT NULL,
    self_assessment jsonb,
    manager_assessment jsonb,
    overall_rating integer,
    strengths text,
    areas_for_improvement text,
    status character varying(20) DEFAULT 'not_started'::character varying NOT NULL,
    sign_off_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reviews OWNER TO planview;

--
-- Name: rota_entries; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.rota_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rota_id uuid NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    date_from date NOT NULL,
    date_to date NOT NULL,
    notes character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rota_entries OWNER TO planview;

--
-- Name: rotas; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.rotas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    rota_type character varying(20) DEFAULT 'callout'::character varying NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    include_weekends boolean DEFAULT false NOT NULL,
    colour character varying(7) DEFAULT '#8A00E5'::character varying NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rotas OWNER TO planview;

--
-- Name: segments; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.segments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    project_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.segments OWNER TO planview;

--
-- Name: shared_timelines; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.shared_timelines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    token character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    team_id uuid,
    project_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.shared_timelines OWNER TO planview;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.tags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    colour character varying(7) DEFAULT '#8E8E8E'::character varying NOT NULL,
    project_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tags OWNER TO planview;

--
-- Name: task_assignees; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.task_assignees (
    task_id uuid NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.task_assignees OWNER TO planview;

--
-- Name: task_dependencies; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.task_dependencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    blocker_id uuid NOT NULL,
    blocked_id uuid NOT NULL,
    dependency_type character varying(20) DEFAULT 'finish_to_start'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.task_dependencies OWNER TO planview;

--
-- Name: task_tags; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.task_tags (
    task_id uuid NOT NULL,
    tag_id uuid NOT NULL
);


ALTER TABLE public.task_tags OWNER TO planview;

--
-- Name: task_templates; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.task_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    colour character varying(7),
    status character varying(50) DEFAULT 'todo'::character varying NOT NULL,
    time_estimate_minutes integer,
    checklist_items jsonb,
    tag_names jsonb,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.task_templates OWNER TO planview;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    colour character varying(7),
    status character varying(50) DEFAULT 'todo'::character varying NOT NULL,
    status_emoji character varying(10),
    date_from date,
    date_to date,
    start_time time without time zone,
    end_time time without time zone,
    time_estimate_minutes integer,
    time_estimate_mode character varying(10) DEFAULT 'total'::character varying NOT NULL,
    is_recurring boolean DEFAULT false NOT NULL,
    recurrence_rule character varying(500),
    sort_order integer DEFAULT 0 NOT NULL,
    project_id uuid,
    segment_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    parent_id uuid,
    time_logged_minutes integer DEFAULT 0 NOT NULL,
    CONSTRAINT ck_task_time_estimate_mode CHECK (((time_estimate_mode)::text = ANY ((ARRAY['total'::character varying, 'per_day'::character varying])::text[])))
);


ALTER TABLE public.tasks OWNER TO planview;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.team_members (
    team_id uuid NOT NULL,
    user_id uuid NOT NULL,
    sort_order integer DEFAULT 0
);


ALTER TABLE public.team_members OWNER TO planview;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.teams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    is_favourite boolean DEFAULT false NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.teams OWNER TO planview;

--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.time_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    task_id uuid NOT NULL,
    user_id uuid NOT NULL,
    minutes integer NOT NULL,
    description text,
    logged_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.time_entries OWNER TO planview;

--
-- Name: time_off; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.time_off (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    date_from date NOT NULL,
    date_to date NOT NULL,
    reason character varying(255) DEFAULT 'Time Off'::character varying NOT NULL,
    colour character varying(7) DEFAULT '#94A3B8'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.time_off OWNER TO planview;

--
-- Name: user_competencies; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.user_competencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    competency_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    level character varying(50),
    assessed_date date,
    assessed_by uuid,
    expiry_date date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_competencies OWNER TO planview;

--
-- Name: users; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    password_hash character varying(255),
    initials character varying(2),
    colour character varying(7) DEFAULT '#4186E0'::character varying NOT NULL,
    avatar_url character varying(500),
    role character varying(20) DEFAULT 'regular'::character varying NOT NULL,
    pin_on_top boolean DEFAULT false NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    notification_prefs jsonb,
    totp_secret character varying(255),
    totp_enabled boolean DEFAULT false NOT NULL,
    oidc_sub character varying(255),
    oidc_issuer character varying(500),
    auth_provider character varying(20) DEFAULT 'password'::character varying NOT NULL,
    CONSTRAINT ck_user_role CHECK (((role)::text = ANY ((ARRAY['owner'::character varying, 'admin'::character varying, 'regular'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO planview;

--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.webhook_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event character varying(100) NOT NULL,
    payload jsonb,
    response_status integer,
    response_body text,
    success boolean DEFAULT false NOT NULL,
    webhook_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.webhook_logs OWNER TO planview;

--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(2000) NOT NULL,
    secret character varying(255),
    events jsonb,
    is_active boolean DEFAULT true NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.webhooks OWNER TO planview;

--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.workspaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    enabled_modules jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.workspaces OWNER TO planview;

--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.activities (id, workspace_id, actor_id, action, entity_type, entity_id, entity_name, details, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_chat_messages; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.ai_chat_messages (id, session_id, role, content, tool_calls, created_at, updated_at) FROM stdin;
937669c1-245a-4616-9a31-29679d840ae8	240069bc-4fdb-4e3e-9af6-0fd3a10c82f3	user	Give me a summary of my team's status	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8f2bafdf-75a9-47d5-98ad-bbd534a04bd8	240069bc-4fdb-4e3e-9af6-0fd3a10c82f3	assistant	Here's a quick overview of your team at Acme Corp:\n\n**Team Size:** 20 members across Engineering, Design, Marketing, Product, and Data\n\n**Key Highlights:**\n- 30 objectives tracked, averaging ~50% progress across the board\n- 12 compliance items expiring within 90 days — several need urgent attention\n- 8 pending leave requests awaiting approval\n- Team morale trending upward at 3.8/5 in the latest pulse survey\n- 10 active candidates in the recruitment pipeline\n- 3 team members currently onboarding\n\nWould you like me to dig deeper into any of these areas?	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: ai_chat_sessions; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.ai_chat_sessions (id, workspace_id, user_id, title, created_at, updated_at) FROM stdin;
240069bc-4fdb-4e3e-9af6-0fd3a10c82f3	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	Team Overview	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.alembic_version (version_num) FROM stdin;
020
\.


--
-- Data for Name: analysis_reports; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.analysis_reports (id, workspace_id, user_id, report_type, title, content, parameters, status, generation_time_seconds, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.attachments (id, filename, file_path, file_size, mime_type, task_id, uploaded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: candidate_events; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.candidate_events (id, candidate_id, event_type, event_date, interviewer_id, outcome, notes, rejection_reason, created_at, updated_at) FROM stdin;
e0754325-47a1-48b7-a83d-35320453e21c	efd3e958-a69a-4543-92bf-95a787bbf9a5	cv_review	2026-02-08	7632a93b-0150-48a6-9639-b5f84c824690	maybe	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8f26722e-96c7-47b5-8cb6-25504099a96b	9369bffd-5fdc-42be-91de-b133273aa367	cv_review	2026-02-03	d661e296-5b5e-4b4d-bc00-e9d393137c57	pass	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e28fcf60-029f-4693-a034-80153d56abf3	9369bffd-5fdc-42be-91de-b133273aa367	phone_screen	2026-02-07	d661e296-5b5e-4b4d-bc00-e9d393137c57	pass	Phone Screen completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
147b427d-f0b9-4d06-93c9-7765eb0b3878	9369bffd-5fdc-42be-91de-b133273aa367	interview	2026-02-11	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	maybe	Interview completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3face801-a934-4cbe-9694-07ac3caaa49c	2057e025-b647-4206-8f06-3ff89d6f1358	cv_review	2026-02-13	d661e296-5b5e-4b4d-bc00-e9d393137c57	pass	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
068f7cc5-3ccc-4cd6-bc8a-61f92f76e6ff	2057e025-b647-4206-8f06-3ff89d6f1358	phone_screen	2026-02-17	7632a93b-0150-48a6-9639-b5f84c824690	pass	Phone Screen completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d32b154f-c4e9-4124-a898-31a3bd94a20c	2057e025-b647-4206-8f06-3ff89d6f1358	interview	2026-02-21	48c66b25-24b9-4dcf-8454-419266423422	maybe	Interview completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
eb519370-54f8-41c7-a75d-93adef50ba2e	633dc1e7-e2e4-4f13-a5c4-83ec39cc8940	cv_review	2026-01-29	48c66b25-24b9-4dcf-8454-419266423422	pass	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1e3d2fd4-5e23-4def-8e9e-948eec1ecadc	633dc1e7-e2e4-4f13-a5c4-83ec39cc8940	phone_screen	2026-02-02	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	pass	Phone Screen completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
fb210c79-c773-422a-a327-575cec2d319c	633dc1e7-e2e4-4f13-a5c4-83ec39cc8940	interview	2026-02-06	7632a93b-0150-48a6-9639-b5f84c824690	pass	Interview completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8eb2a0d1-92ea-4d08-bb3e-2074cba9ef17	633dc1e7-e2e4-4f13-a5c4-83ec39cc8940	technical_test	2026-02-10	48c66b25-24b9-4dcf-8454-419266423422	pass	Technical Test completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4a8ca8d4-76f0-4f75-8d61-20d94665bb96	23f8ed6e-ebe1-4e88-810b-4a768e60917f	cv_review	2026-01-19	e883e8c3-9f3c-4ca2-86ba-49841c392367	pass	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
00e2ec70-71f8-4c9d-8385-401a9a2f2853	23f8ed6e-ebe1-4e88-810b-4a768e60917f	phone_screen	2026-01-23	7632a93b-0150-48a6-9639-b5f84c824690	pass	Phone Screen completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
40a71059-e417-4c02-8c05-d9f555d96a2c	23f8ed6e-ebe1-4e88-810b-4a768e60917f	interview	2026-01-27	7632a93b-0150-48a6-9639-b5f84c824690	pass	Interview completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1d9d7405-f736-40b8-807d-dd64a91f2e4b	23f8ed6e-ebe1-4e88-810b-4a768e60917f	technical_test	2026-01-31	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	pass	Technical Test completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6547dfd1-c363-493b-a926-dfd6024c0205	23f8ed6e-ebe1-4e88-810b-4a768e60917f	offer	2026-02-04	48c66b25-24b9-4dcf-8454-419266423422	pass	Offer completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
cec5e18b-47e8-43b1-b272-1d05fecb000c	1370dd05-6f25-4f70-8f4d-8eaad3a57fa5	cv_review	2026-02-21	7632a93b-0150-48a6-9639-b5f84c824690	maybe	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
29687175-21a5-4036-8dcd-83ec1579f898	6598b6b9-47b1-4cba-998d-11e6d25d2ee9	cv_review	2026-02-15	48c66b25-24b9-4dcf-8454-419266423422	pass	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
76ecb409-9a25-43d2-92e3-34a479703552	6598b6b9-47b1-4cba-998d-11e6d25d2ee9	phone_screen	2026-02-19	e883e8c3-9f3c-4ca2-86ba-49841c392367	pass	Phone Screen completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
93257390-0611-4346-bdcb-c87514746510	6598b6b9-47b1-4cba-998d-11e6d25d2ee9	interview	2026-02-23	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	maybe	Interview completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
08899621-c6d2-4694-a35d-25e28ff966ac	95fdbf3d-b73d-479f-9e11-51432d75b002	cv_review	2026-01-24	e883e8c3-9f3c-4ca2-86ba-49841c392367	pass	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f770f2b2-78ab-40e0-978f-78427b9b18c9	95fdbf3d-b73d-479f-9e11-51432d75b002	phone_screen	2026-01-28	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	pass	Phone Screen completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4a611ae2-4f71-408f-99a0-97e6e16c3580	95fdbf3d-b73d-479f-9e11-51432d75b002	interview	2026-02-01	7632a93b-0150-48a6-9639-b5f84c824690	pass	Interview completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
905d7006-bc7a-4555-82aa-3594b8986055	95fdbf3d-b73d-479f-9e11-51432d75b002	technical_test	2026-02-05	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	pass	Technical Test completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
57920a45-11d7-4c79-9fd9-d554d28d67fe	00f99d35-0631-4d62-9abb-97278b38301c	cv_review	2026-01-14	d661e296-5b5e-4b4d-bc00-e9d393137c57	pass	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
772794c0-7187-4c96-8977-5410c2bdad52	00f99d35-0631-4d62-9abb-97278b38301c	phone_screen	2026-01-18	48c66b25-24b9-4dcf-8454-419266423422	pass	Phone Screen completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
891bb65d-8c55-4532-8ef2-87187c9e1b82	00f99d35-0631-4d62-9abb-97278b38301c	interview	2026-01-22	48c66b25-24b9-4dcf-8454-419266423422	fail	Interview completed	Skills not aligned with role requirements	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2bfea82e-785c-4766-9ae8-d3edf4861990	3dbec208-aae3-43d3-9a9d-156e599bd07c	cv_review	2026-02-18	d661e296-5b5e-4b4d-bc00-e9d393137c57	maybe	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c57b6cf7-a691-48cb-b528-b32a50ca4791	ddfe4e1f-c3b6-4fc2-994f-b922084f7d70	cv_review	2026-02-11	e883e8c3-9f3c-4ca2-86ba-49841c392367	pass	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
27ea4ccd-afe2-423a-ad58-3effd12c5a53	ddfe4e1f-c3b6-4fc2-994f-b922084f7d70	phone_screen	2026-02-15	d661e296-5b5e-4b4d-bc00-e9d393137c57	pass	Phone Screen completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
90c3d391-2407-4df5-a4fe-fdcd7f1b9ee9	d6b5d4df-191e-42df-a62c-1bbc3f01ae3f	cv_review	2026-02-19	7632a93b-0150-48a6-9639-b5f84c824690	pass	Cv Review completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
626963be-7fd4-40cb-9bd5-a8197ac4739d	d6b5d4df-191e-42df-a62c-1bbc3f01ae3f	phone_screen	2026-02-23	7632a93b-0150-48a6-9639-b5f84c824690	pass	Phone Screen completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
372e9403-3ce6-4920-ba72-1080852ae092	d6b5d4df-191e-42df-a62c-1bbc3f01ae3f	interview	2026-02-27	48c66b25-24b9-4dcf-8454-419266423422	maybe	Interview completed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: candidates; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.candidates (id, workspace_id, name, email, phone, position_applied, source, status, applied_date, notes, created_at, updated_at) FROM stdin;
efd3e958-a69a-4543-92bf-95a787bbf9a5	57794310-9d2b-47fd-9318-fc704a17709f	Alice Johnson	alice.j@mail.com	\N	Senior Developer	referral	screening	2026-02-05	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9369bffd-5fdc-42be-91de-b133273aa367	57794310-9d2b-47fd-9318-fc704a17709f	Frank Wilson	frank.w@mail.com	\N	DevOps Engineer	agency	interviewing	2026-01-31	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2057e025-b647-4206-8f06-3ff89d6f1358	57794310-9d2b-47fd-9318-fc704a17709f	Grace Lee	grace.l@mail.com	\N	UX Designer	direct	interviewing	2026-02-10	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
633dc1e7-e2e4-4f13-a5c4-83ec39cc8940	57794310-9d2b-47fd-9318-fc704a17709f	Henry Taylor	henry.t@mail.com	\N	Marketing Analyst	direct	offered	2026-01-26	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
23f8ed6e-ebe1-4e88-810b-4a768e60917f	57794310-9d2b-47fd-9318-fc704a17709f	Ivy Chen	ivy.c@mail.com	\N	Backend Developer	internal	hired	2026-01-16	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
55a7dd2d-48c5-457a-b3ba-372e918b8e4b	57794310-9d2b-47fd-9318-fc704a17709f	James Wright	james.w@mail.com	\N	Platform Engineer	agency	applied	2026-02-25	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1370dd05-6f25-4f70-8f4d-8eaad3a57fa5	57794310-9d2b-47fd-9318-fc704a17709f	Kim Nakamura	kim.n@mail.com	\N	Data Scientist	direct	screening	2026-02-18	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6598b6b9-47b1-4cba-998d-11e6d25d2ee9	57794310-9d2b-47fd-9318-fc704a17709f	Luca Bianchi	luca.b@mail.com	\N	Senior Developer	referral	interviewing	2026-02-12	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dd0a04c3-f9d0-44f0-b63d-a7aac40654fc	57794310-9d2b-47fd-9318-fc704a17709f	Maria Santos	maria.s@mail.com	\N	Product Designer	direct	applied	2026-02-27	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
95fdbf3d-b73d-479f-9e11-51432d75b002	57794310-9d2b-47fd-9318-fc704a17709f	Nadia Popov	nadia.p@mail.com	\N	Security Engineer	agency	offered	2026-01-21	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
00f99d35-0631-4d62-9abb-97278b38301c	57794310-9d2b-47fd-9318-fc704a17709f	Omar Hassan	omar.h@mail.com	\N	Full Stack Developer	direct	rejected	2026-01-11	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2cec712a-9e8c-4d4f-835d-08c9944fb300	57794310-9d2b-47fd-9318-fc704a17709f	Priya Sharma	priya.s@mail.com	\N	QA Engineer	referral	applied	2026-02-22	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3dbec208-aae3-43d3-9a9d-156e599bd07c	57794310-9d2b-47fd-9318-fc704a17709f	Ravi Patel	ravi.p@mail.com	\N	DevOps Engineer	agency	screening	2026-02-15	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ddfe4e1f-c3b6-4fc2-994f-b922084f7d70	57794310-9d2b-47fd-9318-fc704a17709f	Sofia Eriksson	sofia.e@mail.com	\N	UX Researcher	direct	withdrawn	2026-02-08	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d6b5d4df-191e-42df-a62c-1bbc3f01ae3f	57794310-9d2b-47fd-9318-fc704a17709f	Tom Mbeki	tom.m@mail.com	\N	Junior Developer	internal	interviewing	2026-02-16	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: career_pathways; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.career_pathways (id, workspace_id, name, description, levels, created_at, updated_at) FROM stdin;
0325dd55-32e6-457d-a004-ad0146b2922e	57794310-9d2b-47fd-9318-fc704a17709f	Engineering Career Ladder	Junior Engineer -> Engineer -> Senior Engineer -> Staff Engineer -> Principal Engineer	[{"title": "Junior Engineer", "typical_years": 2, "required_competencies": []}, {"title": "Engineer", "typical_years": 3, "required_competencies": []}, {"title": "Senior Engineer", "typical_years": 3, "required_competencies": []}, {"title": "Staff Engineer", "typical_years": 4, "required_competencies": []}, {"title": "Principal Engineer", "typical_years": 0, "required_competencies": []}]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2a10d6a1-65ea-47a0-845b-980690472cf4	57794310-9d2b-47fd-9318-fc704a17709f	Design Career Ladder	Junior Designer -> Designer -> Senior Designer -> Lead Designer -> Design Director	[{"title": "Junior Designer", "typical_years": 2, "required_competencies": []}, {"title": "Designer", "typical_years": 3, "required_competencies": []}, {"title": "Senior Designer", "typical_years": 3, "required_competencies": []}, {"title": "Lead Designer", "typical_years": 4, "required_competencies": []}, {"title": "Design Director", "typical_years": 0, "required_competencies": []}]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: checklists; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.checklists (id, title, is_completed, sort_order, task_id, created_at, updated_at) FROM stdin;
1370c3f1-1434-4b35-b2e9-12a09f5fa2b3	Research	t	0	413df965-4a6c-4e6e-9096-042830383305	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0067d0f7-96e2-44be-a05a-7346464be0c4	Implement	t	1	413df965-4a6c-4e6e-9096-042830383305	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
66c0bdc9-b028-42d0-a3b6-4973e88362e5	Review	t	2	413df965-4a6c-4e6e-9096-042830383305	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0c5ffd5d-79f5-4363-b390-15679029e690	Deploy	t	3	413df965-4a6c-4e6e-9096-042830383305	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f52ed49b-2cb6-4f81-b797-ea9c3337f596	Research	t	0	51c4d428-333f-4d02-9718-9a3622937432	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
50359f22-ddc8-428f-859b-5b77ccb51194	Implement	t	1	51c4d428-333f-4d02-9718-9a3622937432	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e204397d-1ac9-4ab8-be53-fdd012af0f35	Review	f	2	51c4d428-333f-4d02-9718-9a3622937432	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2170caab-9f7b-4723-b648-0f9e843c02f5	Deploy	f	3	51c4d428-333f-4d02-9718-9a3622937432	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
030bb693-2668-41a3-b8ef-2e27371da76c	Research	f	0	5846e378-e43a-4e9f-9499-8b2071f8dc73	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a1ea4735-23d9-4ee8-853b-233d4763d2be	Implement	f	1	5846e378-e43a-4e9f-9499-8b2071f8dc73	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
79a6cace-5e86-4572-8a73-dfbc25145807	Review	f	2	5846e378-e43a-4e9f-9499-8b2071f8dc73	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d1b7e3a0-d88a-4353-8c67-686e76d16376	Deploy	f	3	5846e378-e43a-4e9f-9499-8b2071f8dc73	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.clients (id, name, workspace_id, created_at, updated_at) FROM stdin;
709e5031-bbad-4b99-80b2-53a7e317120e	Zenith Industries	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
722d5e88-9189-4c75-852b-a98f1466a36a	Meridian Group	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f27dcdf8-5280-4913-b3a5-b3b6e886fd6e	Atlas Digital	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.comments (id, body, task_id, user_id, created_at, updated_at) FROM stdin;
373df35b-fcb7-4f7d-93c2-1031ca014cd3	Started working on Design homepage mockup. Looking good so far!	413df965-4a6c-4e6e-9096-042830383305	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f19fa4b6-43a7-48dc-8007-5860253f7f0f	Started working on Implement responsive header. Looking good so far!	51c4d428-333f-4d02-9718-9a3622937432	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8a0ed89b-0668-48a1-bcfb-baab860e2005	Started working on Build product card component. Looking good so far!	5846e378-e43a-4e9f-9499-8b2071f8dc73	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ba31be62-d834-4800-a21c-019150344a7f	Started working on Checkout form validation. Looking good so far!	d94d73fc-71b9-458b-bc2c-98e2c8d5c524	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7a027bfe-b242-4267-8873-f505fea27e1b	Started working on Payment gateway integration. Looking good so far!	1f0fdaf2-2cac-45b3-8ad4-c1e4d338b157	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: competencies; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.competencies (id, workspace_id, name, category, description, requires_certification, certification_validity_months, levels, created_at, updated_at) FROM stdin;
955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	Python	technical	\N	t	24	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
20d3d549-692c-4824-b426-ceacf105d2e9	57794310-9d2b-47fd-9318-fc704a17709f	TypeScript/React	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
34e2cc75-dc22-472a-bc69-879c76e3f8c1	57794310-9d2b-47fd-9318-fc704a17709f	AWS	technical	\N	t	12	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
454eb12b-74b9-45ba-ac5e-dd24b3dcc226	57794310-9d2b-47fd-9318-fc704a17709f	Kubernetes	technical	\N	t	24	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
edd58325-3641-4b5b-b87b-1daff314eafe	57794310-9d2b-47fd-9318-fc704a17709f	Project Management	management	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	Communication	soft_skill	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9950caf2-1044-4bb6-885a-25dda4121ff8	57794310-9d2b-47fd-9318-fc704a17709f	Cyber Security	technical	\N	t	12	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
74a0d2c3-bb19-4292-97ed-f58e684151ab	57794310-9d2b-47fd-9318-fc704a17709f	Data Analysis	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b8ec73a3-6fd5-474f-be7d-31f63ec9c136	57794310-9d2b-47fd-9318-fc704a17709f	Leadership	management	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5d22b22c-a0b8-498d-9749-a43e00f6911b	57794310-9d2b-47fd-9318-fc704a17709f	UX Research	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7ba7e885-2a7d-4736-a32d-640c88390cfd	57794310-9d2b-47fd-9318-fc704a17709f	CI/CD & DevOps	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ced3643f-06d3-4538-a1f7-3e21f4f27e9e	57794310-9d2b-47fd-9318-fc704a17709f	SQL & Databases	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
74a1af7c-309d-4893-979c-f6429036e961	57794310-9d2b-47fd-9318-fc704a17709f	Machine Learning	technical	\N	t	24	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	Agile/Scrum	management	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d77b6743-8cc3-45ad-9a78-e4ff57e95936	57794310-9d2b-47fd-9318-fc704a17709f	Stakeholder Mgmt	soft_skill	\N	f	\N	["awareness", "practitioner", "expert"]	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: compliance_items; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.compliance_items (id, workspace_id, user_id, item_type, title, reference_number, issue_date, expiry_date, status, alert_days, document_id, notes, created_at, updated_at) FROM stdin;
e8cd59af-2a6e-4e65-a3fb-0f0f4519e849	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	certification	AWS Solutions Architect Pro	\N	\N	2027-03-02	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b38a7cc5-d98e-462c-a576-22a21f6781dc	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	dbs_check	DBS Enhanced Check	\N	\N	2027-08-24	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
59c58985-8143-41ea-9a52-4e8d67754eb7	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	certification	ISO 27001 Lead Auditor	\N	\N	2026-05-01	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d5444765-889b-4743-9c84-c40b04eef050	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	right_to_work	UK Right to Work (Settled)	\N	\N	2031-02-04	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
76d5c8ed-6dff-4020-a201-6d21d649c0ee	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	certification	CSCS Card	\N	\N	2026-03-27	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d6d1acbe-fba2-437a-9429-d1561cf1ace6	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	certification	Certified Scrum Master	\N	\N	2026-12-27	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9c67de04-e97e-4a80-a51d-4742576faacd	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	right_to_work	UK Right to Work (Pre-Settled)	\N	\N	2026-04-16	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ad722862-daf0-4fe3-8634-b03275bfc86e	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	certification	First Aid at Work	\N	\N	2026-02-20	expired	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7faef68e-706e-4ac7-a260-092f4083778c	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	certification	AWS Developer Associate	\N	\N	2026-09-18	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0b3786bb-36a7-47cd-a5cd-d04a748f68c3	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	contract	Employment Contract	\N	\N	2028-11-26	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
fab71c7c-2c67-4e20-be38-98684bc0d3f2	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	certification	PRINCE2 Practitioner	\N	\N	2027-04-06	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
592878fd-a4db-44d5-af12-d90e556471ea	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	dbs_check	DBS Basic Check	\N	\N	2026-02-25	expired	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3e68b1c2-7285-4eef-bfba-535b2338234a	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	certification	Google Analytics 4 Cert	\N	\N	2026-12-07	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f261bead-31a3-4d37-bdf8-dd10e99eca40	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	certification	Kubernetes CKA	\N	\N	2026-08-29	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b8ef9185-8a37-442c-aaa3-666de3fabf1e	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	certification	Terraform Associate	\N	\N	2026-04-01	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9a5885f7-7b43-44ee-96a5-bf3f9eaebfe0	57794310-9d2b-47fd-9318-fc704a17709f	29b50239-3ff6-44aa-b8da-d5d67ef0659f	right_to_work	UK Right to Work	\N	\N	2028-01-31	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
78b2e6b0-a375-4763-aee2-1a0391ae2f24	57794310-9d2b-47fd-9318-fc704a17709f	476a5fd1-f313-41b0-ae18-9ae79a17d19b	certification	HubSpot Content Marketing	\N	\N	2027-02-15	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1ab76691-9778-4d8b-905f-0132860320cb	57794310-9d2b-47fd-9318-fc704a17709f	652f6dd7-4cad-4786-a938-149c19c645b4	right_to_work	BRP Card	\N	\N	2026-03-22	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
44e7b333-b01f-49ad-b539-1f3613f3a0df	57794310-9d2b-47fd-9318-fc704a17709f	652f6dd7-4cad-4786-a938-149c19c645b4	certification	Azure Developer Associate	\N	\N	2026-10-28	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
42380d2b-31f4-47a7-bca3-1c1e4b998071	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	certification	Docker Certified Associate	\N	\N	2026-02-15	expired	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1fa34d3e-dd63-4a2e-a5ad-8051d18aea04	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	certification	AWS SysOps Administrator	\N	\N	2026-07-30	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e274e303-a27c-4508-aebe-aedecb604eaf	57794310-9d2b-47fd-9318-fc704a17709f	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	contract	Employment Contract	\N	\N	2028-08-18	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bf367d7b-8a05-476a-be2c-dc2b40958de6	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	certification	Certified Product Manager	\N	\N	2027-01-16	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
92dd2ccc-0145-4160-a811-a0fa5ca60bed	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	certification	Snowflake Data Engineer	\N	\N	2026-04-11	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6ba61593-7eec-40ca-83d8-a868614ac9f0	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	right_to_work	UK Right to Work (Visa)	\N	\N	2026-04-26	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4ad45aa6-3ae9-4135-ae67-9af83cbf27ad	57794310-9d2b-47fd-9318-fc704a17709f	a2633e0c-d058-40da-a843-422fcf15adac	contract	Fixed-Term Contract	\N	\N	2026-05-16	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5aaba785-145b-4fc2-8d95-de988fe7e43e	57794310-9d2b-47fd-9318-fc704a17709f	a2633e0c-d058-40da-a843-422fcf15adac	certification	Google Ads Certification	\N	\N	2026-11-17	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
fdd610b4-0d78-485d-b8dd-5a0629fd8e8e	57794310-9d2b-47fd-9318-fc704a17709f	a8212044-03bd-4270-bf0a-1f407b2f9111	certification	Professional Scrum PO	\N	\N	2027-04-26	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
23d03c9f-7def-434c-a07b-c83b0021e6f3	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	certification	CISSP	\N	\N	2027-07-15	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0ef53b4a-af05-4581-9016-55ecbcb8001e	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	certification	CEH v12	\N	\N	2026-04-06	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
844cd228-83de-4130-8972-2a765d72fcfb	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	dbs_check	DBS Enhanced Check	\N	\N	2027-06-25	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
91f88cac-a84c-4ada-9097-eeaaf481f130	57794310-9d2b-47fd-9318-fc704a17709f	a03cbcf7-960e-4f51-8023-b914b77ea368	contract	Fixed-Term Contract	\N	\N	2026-08-29	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e2e6e893-09b4-430c-ab53-6d9a6dbf2bfb	57794310-9d2b-47fd-9318-fc704a17709f	a7a276c3-188c-48b6-a508-4d1e2bc24658	contract	Contractor Agreement	\N	\N	2026-04-21	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0131b4bf-045a-4148-9147-b678bcabb0f4	57794310-9d2b-47fd-9318-fc704a17709f	a7a276c3-188c-48b6-a508-4d1e2bc24658	right_to_work	UK Right to Work	\N	\N	2027-10-23	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
cdeaa3c4-2236-4417-9049-355fcad4a4aa	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	certification	TensorFlow Developer Cert	\N	\N	2026-11-27	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e756f34f-7fdf-45fe-affc-6fb20a117b09	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	certification	GCP Professional Data Eng	\N	\N	2026-02-10	expired	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
79e55dde-f2b3-4fcc-a52d-52f782ef7902	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	contract	Fixed-Term Contract	\N	\N	2026-05-06	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
68ba0c10-9ac2-4d34-ae1e-d3440b35cc55	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	dbs_check	DBS Basic Check	\N	\N	2027-02-15	active	[90, 60, 30, 14, 7]	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: custom_field_values; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.custom_field_values (id, value, field_id, task_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.custom_fields (id, name, field_type, options, sort_order, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: development_checkpoints; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.development_checkpoints (id, plan_id, checkpoint_date, reviewer_id, notes, overall_assessment, actions, created_at, updated_at) FROM stdin;
06bffea3-d421-43a8-b014-40735fa6dcfe	ffc59a12-7173-4f8f-8381-501b5a041713	2025-12-02	d661e296-5b5e-4b4d-bc00-e9d393137c57	Making excellent progress. TOGAF cert on track.	on_track	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b60cb029-c0a6-40e7-b929-118ae8b3e0ab	ffc59a12-7173-4f8f-8381-501b5a041713	2026-01-31	d661e296-5b5e-4b4d-bc00-e9d393137c57	Architecture board presentation went well. Continue current trajectory.	on_track	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b7ed65b7-1917-4c7c-ad95-f89faa7f638e	94346a46-0e32-4f9d-ba78-6c0a8833c253	2026-01-01	d661e296-5b5e-4b4d-bc00-e9d393137c57	Code review training delayed. Needs to catch up on mentoring goals.	behind	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
74a932bc-800e-4763-826e-e3c84f211627	94346a46-0e32-4f9d-ba78-6c0a8833c253	2026-02-15	d661e296-5b5e-4b4d-bc00-e9d393137c57	Back on track after focused sprint on goals.	on_track	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: development_goals; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.development_goals (id, plan_id, title, description, goal_type, linked_competency_id, target_date, status, evidence, cost_estimate, created_at, updated_at, priority, progress, year, linked_objective_id, actual_cost, completed_date) FROM stdin;
8f5dfc4e-c30b-4182-aff8-b5e569a90749	ffc59a12-7173-4f8f-8381-501b5a041713	Complete TOGAF certification	\N	training	\N	2026-05-01	in_progress	\N	2500	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
da5a2a56-858c-409e-bde3-e17e7fd714b7	ffc59a12-7173-4f8f-8381-501b5a041713	Lead architecture review board	\N	experience	\N	2026-05-31	not_started	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
ec35b436-1c34-468c-aa3d-0d1b2fa16447	ffc59a12-7173-4f8f-8381-501b5a041713	Present at QCon conference	\N	experience	\N	2026-01-31	completed	\N	1200	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
1a93aaab-8e05-4ebf-8109-6dc60222c5d3	94346a46-0e32-4f9d-ba78-6c0a8833c253	Complete system design course	\N	training	\N	2026-04-16	in_progress	\N	800	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
a1a096e3-7afd-4d5b-b7cb-ecd8dc6eddf8	94346a46-0e32-4f9d-ba78-6c0a8833c253	Lead cross-team feature delivery	\N	experience	\N	2026-06-30	not_started	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
c639d63e-0de8-43a3-9315-3ae758831239	94346a46-0e32-4f9d-ba78-6c0a8833c253	Mentor two junior developers	\N	mentoring	\N	2026-05-31	in_progress	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
918416e3-ebb6-473a-83f0-410459b1aa07	bfff640c-9283-4f62-b1e0-86e9583cd17d	AWS Solutions Architect certification	\N	qualification	\N	2026-05-16	in_progress	\N	300	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
23d88853-b58a-430a-856e-46843959640f	bfff640c-9283-4f62-b1e0-86e9583cd17d	Contribute to open-source project	\N	project	\N	2026-02-15	completed	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
3ca19994-e641-442b-b2b4-2e21acda95bd	3940d85d-1d23-452d-b0d8-c652e064439c	Complete Nielsen Norman UX certification	\N	qualification	\N	2026-06-10	not_started	\N	4000	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
0ad3ca44-d6c7-4dff-b6a6-60f73a449df1	3940d85d-1d23-452d-b0d8-c652e064439c	Run 5 user research sessions	\N	experience	\N	2026-05-01	in_progress	\N	500	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
952b1d36-322b-4da6-81eb-480c137976c3	3940d85d-1d23-452d-b0d8-c652e064439c	Build design system component library	\N	project	\N	2026-05-31	in_progress	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
711f2618-9123-4604-a9ac-4e559ca2d1b6	862fb416-d087-419b-917c-171e0b420ddd	Google Ads certification	\N	training	\N	2026-02-10	completed	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
8ba9e663-3b53-4e4e-b5be-d36378aeb764	862fb416-d087-419b-917c-171e0b420ddd	Run first A/B testing programme	\N	project	\N	2026-04-16	in_progress	\N	2000	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
818d2334-69d3-46c2-9832-17866bf41102	dfcdca73-02dc-464f-803d-ba0e5cf42997	CKA Kubernetes certification	\N	qualification	\N	2026-04-21	in_progress	\N	395	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
56e51792-0f68-4405-a509-5e9618628b58	dfcdca73-02dc-464f-803d-ba0e5cf42997	Build internal platform tooling	\N	project	\N	2026-06-30	not_started	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
6fea1ecd-83f9-4507-b8b2-809b5f79414f	18d0c5c9-205a-4ef8-a18d-1a7b9cc97d80	Attend Figma Config conference	\N	training	\N	2026-01-16	completed	\N	800	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
df3816c8-9821-4d76-a0c4-1b7d599da58b	18d0c5c9-205a-4ef8-a18d-1a7b9cc97d80	Shadow product manager for a sprint	\N	mentoring	\N	2026-04-01	in_progress	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
0425a722-d478-410f-acd3-dff8382f912d	452c0b63-6e25-454e-9032-0d0e80fea8cb	Complete content strategy course	\N	training	\N	2026-05-01	in_progress	\N	600	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
bb510a7b-16f0-4f18-8e41-09854a98656a	77db7895-3068-4e53-a56b-6c9d3dc6a22a	Full-stack project ownership end-to-end	\N	experience	\N	2026-05-31	in_progress	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
16ccf989-8a32-4c60-bc39-7fe1f25ac759	77db7895-3068-4e53-a56b-6c9d3dc6a22a	Complete React Advanced workshop	\N	training	\N	2026-02-20	completed	\N	450	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
dd50cf20-5dfe-43e2-842a-ef76adb4f0e4	866ec4f7-bae0-4804-9300-beb38e6c3371	HashiCorp Terraform Associate cert	\N	qualification	\N	2026-05-21	not_started	\N	250	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
7406f983-246e-467a-9ae9-cdeed3931f0d	866ec4f7-bae0-4804-9300-beb38e6c3371	Lead incident response improvements	\N	experience	\N	2026-05-01	in_progress	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
fb36e773-fffd-48aa-b221-a46617f04e30	c6cf0570-6b9f-4ed9-8031-de57dd99aa1a	Run design sprint workshops	\N	experience	\N	2026-06-10	not_started	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
897da350-60a0-45e2-b7e2-d87c1d62e978	10e5e2b9-fafb-451c-b721-5da0105c153a	Product analytics deep-dive course	\N	training	\N	2026-04-16	in_progress	\N	900	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
19f8b2bf-1780-4c16-b7c7-8c946f36f7db	10e5e2b9-fafb-451c-b721-5da0105c153a	Present strategy to exec team	\N	experience	\N	2026-05-31	not_started	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
6e29e66b-01ea-47a5-914b-a9bc4648a5b2	61d19a56-88c5-4f66-acad-be01c65f31da	Databricks certified associate	\N	qualification	\N	2026-04-26	in_progress	\N	300	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
033ad075-0680-4c62-82c7-914af8deb9a9	61d19a56-88c5-4f66-acad-be01c65f31da	Build automated data quality pipeline	\N	project	\N	2026-06-30	not_started	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
e04d0614-18e7-4fe2-98fe-1419ae564fe9	970baf1a-6c31-443e-ad1b-9e4a853c1245	SEO masterclass certification	\N	training	\N	2026-02-05	completed	\N	200	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
dddb976f-ab1d-4948-bfcd-251e6070e841	34fd0493-dc6c-40e5-876e-ec6a4c84538a	Pragmatic Institute PMC cert	\N	qualification	\N	2026-06-10	not_started	\N	2800	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
d4fe58f5-a29e-41f0-85bb-48e4a792ce28	157392a6-7082-4d54-ac7c-88696d3a4d26	OSCP certification	\N	qualification	\N	2026-05-31	in_progress	\N	1599	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
02c501da-f8ce-4b0b-949f-25efac1b88c3	157392a6-7082-4d54-ac7c-88696d3a4d26	Lead red team exercise	\N	experience	\N	2026-06-30	not_started	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
0a06b0a0-781a-4041-a907-ca6bf00cf704	8524831b-c92c-4d1d-8108-f9e21cf804cf	SQL and data analysis bootcamp	\N	training	\N	2026-04-01	in_progress	\N	400	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
767eda53-d048-4297-9bb8-92b3260d4ed4	62744923-4fc8-4288-9575-8ac8ba4692d4	Framer and prototyping masterclass	\N	training	\N	2026-05-01	not_started	\N	350	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
df010867-196b-478d-b90e-bdf046ade15e	066dbff3-04f2-4a26-a07b-e6616682f77e	MLOps specialisation (Coursera)	\N	training	\N	2026-05-16	in_progress	\N	500	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
485ff287-db8a-4e32-b607-ce6f5fcfd987	066dbff3-04f2-4a26-a07b-e6616682f77e	Publish internal ML best practices guide	\N	project	\N	2026-05-31	not_started	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
3512f1ac-5dca-4fcf-8746-affc6be3c860	44e602e9-7100-4ed9-96fc-bdb1589c189e	Marketing automation certification	\N	training	\N	2026-05-21	not_started	\N	300	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0	\N	\N	\N	\N
\.


--
-- Data for Name: development_milestones; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.development_milestones (id, plan_id, title, description, target_date, completed_date, status, year, sort_order, created_at, updated_at) FROM stdin;
f7e90f42-b2df-40e3-91e7-f1a6e77b698d	ffc59a12-7173-4f8f-8381-501b5a041713	Complete core technical training	\N	2026-01-31	2026-01-21	completed	1	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
09c32416-da8d-481f-b65c-536c461bc546	ffc59a12-7173-4f8f-8381-501b5a041713	Pass architecture review assessment	\N	2026-05-01	\N	in_progress	1	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ffe885fa-21f4-4de0-ac12-113a43f880a6	ffc59a12-7173-4f8f-8381-501b5a041713	Lead a major project delivery	\N	2026-09-18	\N	pending	2	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a0a0bd56-30d8-4569-add9-c0767118a025	ffc59a12-7173-4f8f-8381-501b5a041713	Achieve senior certification	\N	2027-07-15	\N	pending	3	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
85ba6b45-bb0f-4396-b108-6f3db93c7ac5	94346a46-0e32-4f9d-ba78-6c0a8833c253	Complete code review mastery	\N	2026-01-01	2025-12-22	completed	1	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7f64d85c-b245-48d1-be8d-124277fbe7de	94346a46-0e32-4f9d-ba78-6c0a8833c253	Lead feature delivery independently	\N	2026-04-16	\N	in_progress	1	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dc6c0ecc-b82f-4f00-8188-b582c228693c	94346a46-0e32-4f9d-ba78-6c0a8833c253	Mentor a junior developer	\N	2026-08-29	\N	pending	2	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
49922e8f-6750-4e48-9d63-4a7df02c0fc3	bfff640c-9283-4f62-b1e0-86e9583cd17d	AWS certification	\N	2026-02-10	2026-01-31	completed	1	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
52c57fe6-0adb-4037-a24a-e818bc6cb784	bfff640c-9283-4f62-b1e0-86e9583cd17d	Cloud architecture project	\N	2026-05-31	\N	in_progress	1	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
db5d9d82-97ec-4efd-8ab5-16f4457296b9	bfff640c-9283-4f62-b1e0-86e9583cd17d	Present at internal tech talk	\N	2026-07-30	\N	pending	2	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: development_plans; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.development_plans (id, workspace_id, user_id, review_period_id, status, career_aspiration, created_at, updated_at, horizon_years, start_date, end_date, career_pathway_id, overall_progress, total_budget) FROM stdin;
dfcdca73-02dc-464f-803d-ba0e5cf42997	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	5acf4864-1579-4d54-a572-94b0a9225996	active	Staff Engineer	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
18d0c5c9-205a-4ef8-a18d-1a7b9cc97d80	57794310-9d2b-47fd-9318-fc704a17709f	29b50239-3ff6-44aa-b8da-d5d67ef0659f	5acf4864-1579-4d54-a572-94b0a9225996	active	Head of Design	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
452c0b63-6e25-454e-9032-0d0e80fea8cb	57794310-9d2b-47fd-9318-fc704a17709f	476a5fd1-f313-41b0-ae18-9ae79a17d19b	5acf4864-1579-4d54-a572-94b0a9225996	active	Content Director	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
77db7895-3068-4e53-a56b-6c9d3dc6a22a	57794310-9d2b-47fd-9318-fc704a17709f	652f6dd7-4cad-4786-a938-149c19c645b4	5acf4864-1579-4d54-a572-94b0a9225996	active	Architect	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
866ec4f7-bae0-4804-9300-beb38e6c3371	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	5acf4864-1579-4d54-a572-94b0a9225996	active	Site Reliability Lead	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
c6cf0570-6b9f-4ed9-8031-de57dd99aa1a	57794310-9d2b-47fd-9318-fc704a17709f	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	5acf4864-1579-4d54-a572-94b0a9225996	active	Head of Product Design	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
10e5e2b9-fafb-451c-b721-5da0105c153a	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	5acf4864-1579-4d54-a572-94b0a9225996	active	VP Product	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
61d19a56-88c5-4f66-acad-be01c65f31da	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	5acf4864-1579-4d54-a572-94b0a9225996	active	Data Engineering Lead	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
970baf1a-6c31-443e-ad1b-9e4a853c1245	57794310-9d2b-47fd-9318-fc704a17709f	a2633e0c-d058-40da-a843-422fcf15adac	5acf4864-1579-4d54-a572-94b0a9225996	active	Head of Digital	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
34fd0493-dc6c-40e5-876e-ec6a4c84538a	57794310-9d2b-47fd-9318-fc704a17709f	a8212044-03bd-4270-bf0a-1f407b2f9111	5acf4864-1579-4d54-a572-94b0a9225996	draft	CPO	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
157392a6-7082-4d54-ac7c-88696d3a4d26	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	5acf4864-1579-4d54-a572-94b0a9225996	draft	CISO	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
8524831b-c92c-4d1d-8108-f9e21cf804cf	57794310-9d2b-47fd-9318-fc704a17709f	a03cbcf7-960e-4f51-8023-b914b77ea368	5acf4864-1579-4d54-a572-94b0a9225996	draft	Senior Analyst	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
62744923-4fc8-4288-9575-8ac8ba4692d4	57794310-9d2b-47fd-9318-fc704a17709f	a7a276c3-188c-48b6-a508-4d1e2bc24658	5acf4864-1579-4d54-a572-94b0a9225996	completed	Creative Director	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
066dbff3-04f2-4a26-a07b-e6616682f77e	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	5acf4864-1579-4d54-a572-94b0a9225996	completed	Chief Data Officer	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
44e602e9-7100-4ed9-96fc-bdb1589c189e	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	5acf4864-1579-4d54-a572-94b0a9225996	archived	Marketing Director	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	\N	\N	0	\N
3940d85d-1d23-452d-b0d8-c652e064439c	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	5acf4864-1579-4d54-a572-94b0a9225996	active	Design Director	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	3	2025-12-23	2028-12-22	2a10d6a1-65ea-47a0-845b-980690472cf4	40	15000
862fb416-d087-419b-917c-171e0b420ddd	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	5acf4864-1579-4d54-a572-94b0a9225996	active	CMO	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	3	2025-08-13	2028-08-12	2a10d6a1-65ea-47a0-845b-980690472cf4	79	15000
94346a46-0e32-4f9d-ba78-6c0a8833c253	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	5acf4864-1579-4d54-a572-94b0a9225996	active	Tech Lead	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	3	2025-09-27	2028-09-26	0325dd55-32e6-457d-a004-ad0146b2922e	76	15000
bfff640c-9283-4f62-b1e0-86e9583cd17d	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	5acf4864-1579-4d54-a572-94b0a9225996	active	Principal Engineer	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	3	2025-03-17	2028-03-16	0325dd55-32e6-457d-a004-ad0146b2922e	45	10000
ffc59a12-7173-4f8f-8381-501b5a041713	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	5acf4864-1579-4d54-a572-94b0a9225996	active	CTO	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	3	2025-11-11	2028-11-10	0325dd55-32e6-457d-a004-ad0146b2922e	67	20000
\.


--
-- Data for Name: early_talent_cohorts; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.early_talent_cohorts (id, programme_id, name, intake_date, expected_end_date, status, notes, created_at, updated_at) FROM stdin;
b5fa0b61-3663-4652-be59-2fa909c816bb	bd724b28-1800-4b3b-9ad9-f1c703ddf604	Jan 2026 Intake	2026-01-06	2027-12-31	active	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f744b931-3072-45e7-88b4-96383977d2a0	4436138d-7eda-4277-a745-2a3ece15f1eb	Sep 2025 Intake	2025-09-01	2028-08-31	active	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: early_talent_milestones; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.early_talent_milestones (id, participant_id, title, description, milestone_type, target_date, completed_date, status, evidence, sort_order, created_at, updated_at) FROM stdin;
075112d0-8415-4b7c-9b67-ef26247fdb2b	ab9052fe-c0a8-4b57-a542-ccc03bc34b14	Complete Software Engineering rotation	\N	rotation	2026-01-31	2026-01-26	completed	\N	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5aef5782-6578-42a1-9fc2-45eae1115fdb	ab9052fe-c0a8-4b57-a542-ccc03bc34b14	Pass mid-programme review	\N	review	2026-02-15	2026-02-10	completed	\N	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
973fc73a-1280-4123-9714-cd0d6c7ec8c7	ab9052fe-c0a8-4b57-a542-ccc03bc34b14	Start DevOps rotation	\N	rotation	2026-03-02	\N	in_progress	\N	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4e264b1f-47e2-4cc8-a9ed-bdecbf5296cf	ab9052fe-c0a8-4b57-a542-ccc03bc34b14	Year 1 academic submission	\N	qualification	2026-05-31	\N	pending	\N	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b5d3b816-ef1d-4bfe-8f19-480d9e797ea5	c81896cb-f31d-47cb-a31a-8b85a3f9b411	Complete orientation week	\N	probation	2026-01-01	2025-12-27	completed	\N	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e7c2083a-ed27-4ad6-9327-50621e486ed6	c81896cb-f31d-47cb-a31a-8b85a3f9b411	First rotation assessment	\N	rotation	2026-05-01	\N	pending	\N	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
92c33fd4-d3a8-4b21-b869-a832956ed614	c81896cb-f31d-47cb-a31a-8b85a3f9b411	Year 1 academic submission	\N	qualification	2026-06-30	\N	pending	\N	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: early_talent_participants; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.early_talent_participants (id, programme_id, cohort_id, workspace_id, user_id, mentor_id, buddy_id, development_plan_id, status, qualification_target, university, qualification_level, qualification_progress, start_date, expected_end_date, actual_end_date, notes, created_at, updated_at) FROM stdin;
ab9052fe-c0a8-4b57-a542-ccc03bc34b14	bd724b28-1800-4b3b-9ad9-f1c703ddf604	b5fa0b61-3663-4652-be59-2fa909c816bb	57794310-9d2b-47fd-9318-fc704a17709f	a03cbcf7-960e-4f51-8023-b914b77ea368	d661e296-5b5e-4b4d-bc00-e9d393137c57	48c66b25-24b9-4dcf-8454-419266423422	\N	active	BEng Computer Science	University of Sheffield	level_6	35	2026-01-06	2027-12-31	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c81896cb-f31d-47cb-a31a-8b85a3f9b411	bd724b28-1800-4b3b-9ad9-f1c703ddf604	b5fa0b61-3663-4652-be59-2fa909c816bb	57794310-9d2b-47fd-9318-fc704a17709f	a7a276c3-188c-48b6-a508-4d1e2bc24658	d661e296-5b5e-4b4d-bc00-e9d393137c57	48c66b25-24b9-4dcf-8454-419266423422	\N	active	BEng Electrical Engineering	Leeds Beckett	level_6	25	2026-01-06	2027-12-31	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e628c53f-d500-4d94-ab43-4be40d4de653	bd724b28-1800-4b3b-9ad9-f1c703ddf604	b5fa0b61-3663-4652-be59-2fa909c816bb	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	d661e296-5b5e-4b4d-bc00-e9d393137c57	48c66b25-24b9-4dcf-8454-419266423422	\N	enrolled	BSc Data Science	Sheffield Hallam	level_6	15	2026-01-06	2027-12-31	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
08f3be4f-e719-482a-8232-4b6f0214777f	4436138d-7eda-4277-a745-2a3ece15f1eb	f744b931-3072-45e7-88b4-96383977d2a0	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	c6686137-146d-43b4-8919-ed25043403c0	652f6dd7-4cad-4786-a938-149c19c645b4	\N	active	BSc Digital & Technology Solutions	University of Lincoln	level_6	45	2025-09-01	2028-08-31	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: early_talent_programmes; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.early_talent_programmes (id, workspace_id, name, programme_type, description, start_date, end_date, duration_months, status, max_cohort_size, created_at, updated_at) FROM stdin;
bd724b28-1800-4b3b-9ad9-f1c703ddf604	57794310-9d2b-47fd-9318-fc704a17709f	Graduate Programme 2026	graduate	Two-year graduate development programme with four 6-month rotations across engineering disciplines.	2026-01-06	2027-12-31	24	active	8	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4436138d-7eda-4277-a745-2a3ece15f1eb	57794310-9d2b-47fd-9318-fc704a17709f	Apprenticeship Programme 2025	apprentice	Three-year Level 6 degree apprenticeship in Digital & Technology Solutions.	2025-09-01	2028-08-31	36	active	4	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: early_talent_rotation_assignments; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.early_talent_rotation_assignments (id, participant_id, rotation_id, supervisor_id, start_date, end_date, status, assessment, rating, created_at, updated_at) FROM stdin;
92294996-690a-4021-8766-0184944f5b7e	ab9052fe-c0a8-4b57-a542-ccc03bc34b14	9abb0075-ee56-4f83-b9d1-615fd02d8fbe	48c66b25-24b9-4dcf-8454-419266423422	2026-01-06	2026-06-30	completed	Excellent performance. Strong coding ability and good teamwork.	4	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6d586864-5146-4a20-bd1e-43024606fdb7	ab9052fe-c0a8-4b57-a542-ccc03bc34b14	492a7108-0cdd-497e-9c30-bd0e434dc59a	c6686137-146d-43b4-8919-ed25043403c0	2026-07-01	\N	in_progress	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: early_talent_rotations; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.early_talent_rotations (id, programme_id, name, department, duration_weeks, description, sort_order, required_competencies, created_at, updated_at) FROM stdin;
9abb0075-ee56-4f83-b9d1-615fd02d8fbe	bd724b28-1800-4b3b-9ad9-f1c703ddf604	Software Engineering	Engineering	26	Core development rotation — backend and frontend.	0	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
492a7108-0cdd-497e-9c30-bd0e434dc59a	bd724b28-1800-4b3b-9ad9-f1c703ddf604	DevOps & Platform	Platform Engineering	26	Infrastructure, CI/CD, and cloud platform work.	1	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
82d885a4-c5b8-4657-8c89-ab05ffc368e3	bd724b28-1800-4b3b-9ad9-f1c703ddf604	Data Engineering	Data	26	Data pipelines, analytics, and ML infrastructure.	2	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8dc78631-5874-48e3-a147-e416e6593910	bd724b28-1800-4b3b-9ad9-f1c703ddf604	Cyber Security	Security	26	Security operations, penetration testing, and compliance.	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.feedback (id, workspace_id, user_id, type, title, description, status, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: key_results; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.key_results (id, objective_id, title, description, target_value, current_value, unit, measurement_type, created_at, updated_at) FROM stdin;
f5b1c21f-9f51-4907-8b26-5f6e0b3d907b	cc50c036-73e4-472c-bc3c-68cbcceff2b0	P95 latency < 200ms	\N	200	280	ms	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
327565b2-95e9-4f82-9a4e-c2539d739c96	cc50c036-73e4-472c-bc3c-68cbcceff2b0	P99 latency < 500ms	\N	500	620	ms	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b96ead22-b692-4fff-9309-41a6afad28ec	0b28ce57-f277-4e57-918f-66957db76ff7	Complete App Store submission	\N	1	0	milestone	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6f5b582f-17a4-43fa-9e5a-ba46ee8f7763	0b28ce57-f277-4e57-918f-66957db76ff7	Pass all QA regression tests	\N	100	78	%	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3a9801e6-4520-4baa-9d9e-6d4f7a9c86a8	5ea7f009-ca5c-4d16-8d60-bcad40f98cc0	Core module coverage >= 90%	\N	90	72	%	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e658ae2d-8f9a-423a-b1df-90425f98bb83	5ea7f009-ca5c-4d16-8d60-bcad40f98cc0	Zero critical untested paths	\N	0	3	count	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a384092a-73bc-4b8e-8412-df6784db052c	1fa14c45-3002-4537-8fb2-c8713805a00a	User testing score >= 4.5	\N	4.5	3.2	score	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e7dfc113-36ce-47d0-87cf-cc4e950d305f	1fa14c45-3002-4537-8fb2-c8713805a00a	Reduce onboarding drop-off to <10%	\N	10	22	%	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3f70e13a-ab69-4ee7-8774-f3512750dc92	6c845e55-0013-44e5-bb85-4d7df9861a3f	Automated a11y scan pass rate 100%	\N	100	65	%	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
192b84a2-2b7c-46d5-bf62-434b33726623	38a915bb-d612-452a-92b9-608889e72c43	Mean deploy time < 300s	\N	300	380	seconds	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
431d32ff-2e51-44cf-aa7d-ac6f02e2e292	38a915bb-d612-452a-92b9-608889e72c43	Zero failed deployments per sprint	\N	0	1	count	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4790f7c9-0cc8-453c-98f7-87449e7c08de	2bb69123-40f0-4b77-98c3-0dc52ca92647	Components documented in Storybook	\N	50	28	components	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0df789eb-60db-4651-8d46-fadb9c27d7fc	0485dab7-9ea4-402d-ade9-654fcfc56db7	Security audit findings resolved	\N	0	4	count	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b25167fc-a375-4808-a07d-7c858c66ef7e	0485dab7-9ea4-402d-ade9-654fcfc56db7	Penetration test pass rate	\N	100	85	%	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b5e49eb8-4c4a-48a4-9f7a-aff9703316f3	96aa8463-31fe-48c0-af65-af08cb9f5ed2	Dashboard MAU > 500	\N	500	230	users	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
34eae83d-4868-4da2-99c9-31a2a9ce7b9d	50afcea0-cd62-45a5-8e3b-d910c257bc7b	Discovery sessions per quarter	\N	12	3	sessions	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
45df766e-170f-4073-becb-fba8a3c29f00	1aa8d9d6-6727-4590-9092-508c8d4454a0	Legacy services containerised	\N	8	6	services	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b8774e65-6051-47e2-9dba-bb7edaa1bfce	41aeaf27-fc60-4a48-98b2-9dc58c6d2a4a	CI build time < 3 minutes	\N	180	195	seconds	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2dcdee9f-7a7c-4fbf-8de2-30e4aa21c114	8f3c12a1-f351-43ea-83a8-560083ce0ca4	Slow queries eliminated	\N	0	12	count	numeric	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: kudos; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.kudos (id, workspace_id, from_user_id, to_user_id, message, created_at, updated_at) FROM stdin;
592f1395-9259-4ba8-9daa-a61c19f6083a	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	48c66b25-24b9-4dcf-8454-419266423422	Outstanding work on the API migration — zero downtime!	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
39a09130-9729-4014-b022-1c821204cc42	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	e883e8c3-9f3c-4ca2-86ba-49841c392367	Thanks for the thorough code review, caught a nasty bug	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
79d00552-74ae-43c8-afa0-c3b65526af2a	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	29b50239-3ff6-44aa-b8da-d5d67ef0659f	The new dashboard designs are absolutely brilliant	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f4bb0159-4fad-4c31-bee8-9a5f3950fea1	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	Love the new design system — it's transformed our velocity	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ee94e651-e2f4-4a6f-aabb-1dc708fb9d9d	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	d661e296-5b5e-4b4d-bc00-e9d393137c57	Thanks for unblocking the deployment pipeline issue	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9806d0c0-a1aa-42a1-bac9-35b0e038f2b2	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	476a5fd1-f313-41b0-ae18-9ae79a17d19b	Great blog post — the engagement numbers are incredible	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
31a520b2-9dfc-4612-8596-ed4fb806c94e	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	c6686137-146d-43b4-8919-ed25043403c0	Your Kubernetes setup saved us hours of debugging	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
660da297-9fbe-4d2b-9e99-6b507f32ab83	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	652f6dd7-4cad-4786-a938-149c19c645b4	Brilliant full-stack work on the customer portal	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
73c6a4da-f107-4e65-854f-1af22d644251	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	a8212044-03bd-4270-bf0a-1f407b2f9111	Excellent product discovery work — really insightful	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
194e0f2f-f321-445e-80bd-75232c9f8d28	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	Beautiful component library — the team loves it	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a6181a49-d73d-4ebc-b36a-05b7148c2dbe	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	363609f8-48c4-4e82-98c2-a2c7f42e1f46	Thanks for the quick incident response last night	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
46ad21b5-a144-4070-b962-9a7110d1890d	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	The security audit report was exceptional work	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5274ffc2-53f0-4ce6-9416-3fce019a08cf	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	a2633e0c-d058-40da-a843-422fcf15adac	Great social media campaign — best metrics this quarter	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f38b45c0-9891-49e3-95a7-b0ed0b91833f	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	Solid data pipeline work — love the monitoring you added	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5560846a-00c8-4b9d-8260-cee2cb53b7c8	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	Impressive ML model accuracy — well researched approach	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
832ebf9d-6a77-45fe-be6c-89715ca0060a	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	a03cbcf7-960e-4f51-8023-b914b77ea368	Great analysis work — really helped shape the roadmap	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
526778bf-d80a-4f7b-8cd6-5164bcd8ad16	57794310-9d2b-47fd-9318-fc704a17709f	29b50239-3ff6-44aa-b8da-d5d67ef0659f	a7a276c3-188c-48b6-a508-4d1e2bc24658	Stunning UI work on the new feature — pixel perfect	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dfdb61c3-064b-4515-a8bd-e1ceb5eba0fd	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	7a6a5744-371f-4561-90d4-d6b470339606	Excellent product strategy presentation to the board	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
08b4916d-fb31-4222-9a11-be78b3dd71d4	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	363609f8-48c4-4e82-98c2-a2c7f42e1f46	Thanks for the Terraform modules — massive time saver	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5db4dfe4-517a-44b8-82b5-42cd67d25445	57794310-9d2b-47fd-9318-fc704a17709f	476a5fd1-f313-41b0-ae18-9ae79a17d19b	7632a93b-0150-48a6-9639-b5f84c824690	Brilliant campaign strategy — exceeding all targets	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: leave_allowances; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.leave_allowances (id, workspace_id, user_id, year, entitlement_days, carried_forward, used_days, booked_days, created_at, updated_at) FROM stdin;
61ac7250-8bd4-4359-b52a-b9f6d121ac87	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026	25	0	3	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b29cb445-86a7-4dc9-ae7e-5869db7df974	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	2026	25	1	4	5	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
941e08f4-d42b-41ba-8991-357466edf691	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	2026	25	4	12	3	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e8709733-03c9-4bc8-8bbe-1ea5bf19d3c6	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	2026	25	3	3	3	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5c77b6f1-5af6-4a5e-87b8-0ab1bf5b8b48	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	2026	25	4	11	3	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8ed69f9e-d75d-42d3-bb57-21f0493a5759	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	2026	25	0	6	4	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f2a6bef5-cf8a-46be-9986-f881a306f5ed	57794310-9d2b-47fd-9318-fc704a17709f	29b50239-3ff6-44aa-b8da-d5d67ef0659f	2026	25	0	12	5	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7f2a85bf-7a61-489f-91e6-3aa5779b1295	57794310-9d2b-47fd-9318-fc704a17709f	476a5fd1-f313-41b0-ae18-9ae79a17d19b	2026	25	2	12	4	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8d40dc15-2fea-4d70-b4e8-dc43384ea46e	57794310-9d2b-47fd-9318-fc704a17709f	652f6dd7-4cad-4786-a938-149c19c645b4	2026	25	0	12	2	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1ec63f2f-f44b-418e-9cca-2c2b1e063530	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	2026	25	1	6	3	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4cb2c38d-8ebc-49e8-807b-33c5028738a1	57794310-9d2b-47fd-9318-fc704a17709f	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	2026	25	5	9	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
cfe715b9-04fb-4d10-b3b8-2f307d21522f	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	2026	25	1	6	4	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
728cf50d-391a-4b95-ac58-096b0fa424be	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	2026	25	5	10	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e8a17b18-d0aa-41e6-aebc-f68297ac9a01	57794310-9d2b-47fd-9318-fc704a17709f	a2633e0c-d058-40da-a843-422fcf15adac	2026	25	4	6	5	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
36a7f512-9334-44ed-bf1f-04c2769f570b	57794310-9d2b-47fd-9318-fc704a17709f	a8212044-03bd-4270-bf0a-1f407b2f9111	2026	25	1	11	1	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
42234f3d-fae8-4c82-86a6-8b3355b3eb75	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	2026	20	4	7	1	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bb2e98d3-9170-48f8-ad14-2e619c744e29	57794310-9d2b-47fd-9318-fc704a17709f	a03cbcf7-960e-4f51-8023-b914b77ea368	2026	20	4	10	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
83f2bf8b-141c-4400-81cc-0dfa9ee1c073	57794310-9d2b-47fd-9318-fc704a17709f	a7a276c3-188c-48b6-a508-4d1e2bc24658	2026	20	0	7	3	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d80f828e-18e3-46b1-9eaa-217ce39b803a	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	2026	20	2	3	2	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e84e2c9b-cb87-48b4-bd93-65c2144cf0c5	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	2026	20	1	5	0	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: leave_requests; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.leave_requests (id, workspace_id, user_id, leave_type, start_date, end_date, days, status, approved_by, notes, created_at, updated_at) FROM stdin;
a0e884ee-22ca-43e1-abd2-22f083ee97ed	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	annual	2026-03-07	2026-03-12	5	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4498db72-ca10-4e20-9771-6ac2d6bd2fc5	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	annual	2026-04-11	2026-04-13	2	pending	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bf1c7259-c868-4700-b1b8-990b2c3ac45e	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	sick	2026-02-27	2026-03-01	3	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
150a5d7d-2483-4ef2-9cd4-198b33906b9f	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	annual	2026-03-16	2026-03-23	5	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
db307643-0eed-411d-ad4a-3ec577fbdd5e	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	training	2026-04-06	2026-04-07	2	pending	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0947381e-2387-459a-aa10-77e004dd9529	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	annual	2026-03-09	2026-03-16	5	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a843b50f-1374-4eeb-8d93-a7618f6c6014	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	toil	2026-03-05	2026-03-05	1	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8837aad9-31ad-44d7-8a79-b2e0ae2a4c94	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	annual	2026-03-22	2026-03-29	5	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
297d3b72-1c92-4b75-b841-1a3931161335	57794310-9d2b-47fd-9318-fc704a17709f	29b50239-3ff6-44aa-b8da-d5d67ef0659f	annual	2026-03-12	2026-03-14	2	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4c53c858-7def-4637-885e-3bbd04fdfe59	57794310-9d2b-47fd-9318-fc704a17709f	476a5fd1-f313-41b0-ae18-9ae79a17d19b	sick	2026-02-25	2026-02-26	2	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9bb4362a-440d-4013-8f91-fab3f59914ee	57794310-9d2b-47fd-9318-fc704a17709f	652f6dd7-4cad-4786-a938-149c19c645b4	annual	2026-04-01	2026-04-06	4	pending	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ab1fc1bc-609e-475a-aa28-356cc3999c9b	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	annual	2026-03-17	2026-03-21	4	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6bf7428d-73ae-4529-b193-722ed45c4ef9	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	compassionate	2026-04-16	2026-04-18	3	pending	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2c617ec1-2f9c-4b29-9d6b-587e24b59c00	57794310-9d2b-47fd-9318-fc704a17709f	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	annual	2026-03-10	2026-03-14	4	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
48956eb8-1735-4f13-9e5c-2134509d5e79	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	training	2026-03-27	2026-03-29	3	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
985eb730-186e-4cb8-b261-8c9d790478ff	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	annual	2026-03-20	2026-03-24	4	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7374e12b-a0bd-4302-a39b-3180aa83e6f4	57794310-9d2b-47fd-9318-fc704a17709f	a2633e0c-d058-40da-a843-422fcf15adac	annual	2026-03-07	2026-03-11	4	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
31d0aa9a-077c-4668-8b35-7b92533b1739	57794310-9d2b-47fd-9318-fc704a17709f	a8212044-03bd-4270-bf0a-1f407b2f9111	sick	2026-02-28	2026-03-01	2	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
11d4c4c0-6979-4bca-b4b8-981016a66882	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	annual	2026-04-21	2026-04-26	4	pending	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6af66e8b-d869-4932-9343-17ed167147e1	57794310-9d2b-47fd-9318-fc704a17709f	a03cbcf7-960e-4f51-8023-b914b77ea368	annual	2026-03-14	2026-03-16	2	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8ad98a25-7a76-4008-88d3-8e0295f5e977	57794310-9d2b-47fd-9318-fc704a17709f	a7a276c3-188c-48b6-a508-4d1e2bc24658	unpaid	2026-04-01	2026-04-05	5	pending	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4a2345ab-ef94-48c8-b110-368be302f0f3	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	annual	2026-03-24	2026-03-28	4	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7b97201c-aaa8-40e8-b4d7-204594ccf8ec	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	annual	2026-03-08	2026-03-10	2	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9a4d83e8-8356-4bc8-8b25-99bf559ca917	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	sick	2026-02-23	2026-02-25	3	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
60fb8a0c-9183-42a0-a165-539f0f1fb6bd	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	compassionate	2026-04-26	2026-04-28	3	pending	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
372df583-bc6e-4cc9-adcb-540064a42145	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	training	2026-05-01	2026-05-03	3	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
28353597-cce3-4b2c-85c6-776c93cfc6e4	57794310-9d2b-47fd-9318-fc704a17709f	652f6dd7-4cad-4786-a938-149c19c645b4	annual	2026-05-06	2026-05-13	5	pending	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
20c651a3-71e8-4cac-ad88-a9dcf65b6cda	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	sick	2026-03-01	2026-03-01	1	approved	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: lookup_values; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.lookup_values (id, workspace_id, category, value, label, colour, display_order, is_active, created_at, updated_at) FROM stdin;
b2e113db-3160-45da-abde-bc9d90c8e3ea	57794310-9d2b-47fd-9318-fc704a17709f	department	engineering	Engineering	\N	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1489afa0-842a-47be-9b16-c970f218d1ba	57794310-9d2b-47fd-9318-fc704a17709f	department	design	Design	\N	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b818f57f-be49-4651-b28b-c3e3381585fb	57794310-9d2b-47fd-9318-fc704a17709f	department	marketing	Marketing	\N	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b4d61507-1459-492e-a196-646224e95ad0	57794310-9d2b-47fd-9318-fc704a17709f	department	product	Product	\N	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1f1a8cfc-9f1a-45aa-9826-5f1904a1ac0f	57794310-9d2b-47fd-9318-fc704a17709f	department	hr	HR	\N	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4802768b-08a2-4da0-a1c6-5dfe7ca12680	57794310-9d2b-47fd-9318-fc704a17709f	department	finance	Finance	\N	5	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ba2cca11-4d00-4000-9649-c21c97869d2f	57794310-9d2b-47fd-9318-fc704a17709f	department	operations	Operations	\N	6	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a9588974-5859-4144-9681-3c92605b1b74	57794310-9d2b-47fd-9318-fc704a17709f	department	sales	Sales	\N	7	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
aecf0341-a4d5-49aa-bc94-57a805def8a0	57794310-9d2b-47fd-9318-fc704a17709f	job_title	software_engineer	Software Engineer	\N	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
74f4ea71-999e-4c59-9b7b-be29b5b861a6	57794310-9d2b-47fd-9318-fc704a17709f	job_title	senior_engineer	Senior Engineer	\N	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
10f91df9-34f3-4f96-9ef5-9fc45cb6d352	57794310-9d2b-47fd-9318-fc704a17709f	job_title	lead_engineer	Lead Engineer	\N	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9a6d9c58-98ee-464f-a78d-2f6eb0c8dfbd	57794310-9d2b-47fd-9318-fc704a17709f	job_title	engineering_manager	Engineering Manager	\N	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d6ace417-35be-4bbb-bf02-6cbe6d19022b	57794310-9d2b-47fd-9318-fc704a17709f	job_title	product_manager	Product Manager	\N	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c27d1cab-f904-4a02-aeb5-b1434b4ee432	57794310-9d2b-47fd-9318-fc704a17709f	job_title	designer	Designer	\N	5	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1d78e683-1076-46a8-96a0-2eff036c2fa2	57794310-9d2b-47fd-9318-fc704a17709f	job_title	analyst	Analyst	\N	6	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d8b6cd75-990c-4b94-9363-d809c9d86796	57794310-9d2b-47fd-9318-fc704a17709f	job_title	devops_engineer	DevOps Engineer	\N	7	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f2cac2cc-0645-4d61-b082-206c196f1bb0	57794310-9d2b-47fd-9318-fc704a17709f	location	london	London	\N	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7b610582-d44c-4793-858c-7ae6206ecfdb	57794310-9d2b-47fd-9318-fc704a17709f	location	manchester	Manchester	\N	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
54f11b5a-34e7-497d-90b0-980c097d42f7	57794310-9d2b-47fd-9318-fc704a17709f	location	bristol	Bristol	\N	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
67c2dcf3-58fe-43d7-8fb2-4371ea4d93e1	57794310-9d2b-47fd-9318-fc704a17709f	location	edinburgh	Edinburgh	\N	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c29b9dba-33d3-4995-a54f-74a1487b86f3	57794310-9d2b-47fd-9318-fc704a17709f	location	birmingham	Birmingham	\N	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0dc3cf2c-96f1-4390-a744-511a8b639bbe	57794310-9d2b-47fd-9318-fc704a17709f	location	remote	Remote	\N	5	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
69c745d3-c4d7-40e5-bb48-b1837f6d1a1f	57794310-9d2b-47fd-9318-fc704a17709f	competency_category	technical	Technical	\N	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
18b14bd0-1ea9-4e05-8936-909335c0739e	57794310-9d2b-47fd-9318-fc704a17709f	competency_category	safety	Safety	\N	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c42ec9a1-7676-4069-87fc-a67ead0a672f	57794310-9d2b-47fd-9318-fc704a17709f	competency_category	leadership	Leadership	\N	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0eb6638a-c019-4821-9b01-d186bdfa973f	57794310-9d2b-47fd-9318-fc704a17709f	competency_category	communication	Communication	\N	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
348d9c13-07e5-44ed-87e9-808800f4c388	57794310-9d2b-47fd-9318-fc704a17709f	competency_category	compliance	Compliance	\N	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
710f38ff-2f77-4baf-9b4d-db31098eee45	57794310-9d2b-47fd-9318-fc704a17709f	competency_category	domain_knowledge	Domain Knowledge	\N	5	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0570669c-8a09-48b5-b8a7-1339d557c52e	57794310-9d2b-47fd-9318-fc704a17709f	leave_type	annual	Annual	#3b82f6	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
18cd5884-cde7-4f22-a07e-9facbdd2c34b	57794310-9d2b-47fd-9318-fc704a17709f	leave_type	sick	Sick	#ef4444	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
16c9555e-898c-4cb8-8208-f65924381f73	57794310-9d2b-47fd-9318-fc704a17709f	leave_type	compassionate	Compassionate	#8b5cf6	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
86f672e6-bab8-4aed-98ea-0a056804f16b	57794310-9d2b-47fd-9318-fc704a17709f	leave_type	toil	TOIL	#14b8a6	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a4a5cc0a-0ddf-454a-a2d7-f67960e744f0	57794310-9d2b-47fd-9318-fc704a17709f	leave_type	training	Training	#f59e0b	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
286bb6a8-2af0-4151-9ca4-300293308bd5	57794310-9d2b-47fd-9318-fc704a17709f	leave_type	unpaid	Unpaid	#64748b	5	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4adc7ea1-1531-48fd-a8cf-a6d2dcd08395	57794310-9d2b-47fd-9318-fc704a17709f	leave_type	other	Other	#6b7280	6	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
471afb16-b32a-4c8d-96c6-2d947f6fad39	57794310-9d2b-47fd-9318-fc704a17709f	compliance_item_type	certificate	Certificate	#3b82f6	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2d556a8f-d096-4576-8941-439de68ac880	57794310-9d2b-47fd-9318-fc704a17709f	compliance_item_type	visa	Visa	#8b5cf6	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
00f8c331-7a80-4e9c-87e8-b20f47d81ab1	57794310-9d2b-47fd-9318-fc704a17709f	compliance_item_type	contract	Contract	#14b8a6	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f179dfff-dad9-486f-982a-42b30f413b23	57794310-9d2b-47fd-9318-fc704a17709f	compliance_item_type	licence	Licence	#f59e0b	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
69b31b5f-8e61-41b5-ab7a-3fef0de150bc	57794310-9d2b-47fd-9318-fc704a17709f	compliance_item_type	training	Training	#22c55e	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
81c7256a-8de0-4fd1-8ff9-473a595e5253	57794310-9d2b-47fd-9318-fc704a17709f	compliance_item_type	dbs_check	DBS Check	#ef4444	5	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b147cbd9-3c4f-432e-9dff-5739c49275fe	57794310-9d2b-47fd-9318-fc704a17709f	compliance_item_type	right_to_work	Right to Work	#ec4899	6	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ccc8741c-9fed-47cb-ba3d-f82ecd7558b0	57794310-9d2b-47fd-9318-fc704a17709f	candidate_source	linkedin	LinkedIn	#0a66c2	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
762d612d-3f7b-4acd-89bb-40edd93b5cee	57794310-9d2b-47fd-9318-fc704a17709f	candidate_source	referral	Referral	#22c55e	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
da13ab09-a431-4cbb-900f-6b47c677ce0c	57794310-9d2b-47fd-9318-fc704a17709f	candidate_source	website	Website	#3b82f6	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5d58faf2-5279-4f39-81c8-1a5bed77c150	57794310-9d2b-47fd-9318-fc704a17709f	candidate_source	agency	Agency	#f59e0b	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
06382ba6-47c2-4dc3-bc82-b601d973a110	57794310-9d2b-47fd-9318-fc704a17709f	candidate_source	job_board	Job Board	#8b5cf6	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
798ed601-0637-4dc8-8b16-b74a9c2a63ac	57794310-9d2b-47fd-9318-fc704a17709f	candidate_source	internal	Internal	#14b8a6	5	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9dc997dd-f067-44f0-ba1f-613cc3e72750	57794310-9d2b-47fd-9318-fc704a17709f	candidate_source	other	Other	#6b7280	6	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
77747804-7beb-4ca1-8306-14a070b233e9	57794310-9d2b-47fd-9318-fc704a17709f	event_outcome	pass	Pass	#22c55e	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e6f0eee9-790a-43d1-a445-2195a43d9317	57794310-9d2b-47fd-9318-fc704a17709f	event_outcome	fail	Fail	#ef4444	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c94f78b1-7cf0-47b4-8239-a1b8a92db042	57794310-9d2b-47fd-9318-fc704a17709f	event_outcome	maybe	Maybe	#f59e0b	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7602ae18-9333-4ded-933f-ae4187bfd05b	57794310-9d2b-47fd-9318-fc704a17709f	event_outcome	deferred	Deferred	#8b5cf6	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4713bee0-8789-4f72-9211-5c2745b60ad0	57794310-9d2b-47fd-9318-fc704a17709f	event_outcome	no_show	No Show	#64748b	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2242afed-a64b-43e4-b33a-f2b80cb79208	57794310-9d2b-47fd-9318-fc704a17709f	onboarding_assignee_role	manager	Manager	\N	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
fca0207c-b8fc-4ab7-bd07-c2d7fd8a3bf6	57794310-9d2b-47fd-9318-fc704a17709f	onboarding_assignee_role	it	IT	\N	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4838d791-bf92-4c96-a83f-37ad4373d419	57794310-9d2b-47fd-9318-fc704a17709f	onboarding_assignee_role	hr	HR	\N	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
85006c9e-2e45-4ef2-b18a-0aeb8dc56c2a	57794310-9d2b-47fd-9318-fc704a17709f	onboarding_assignee_role	new_starter	New Starter	\N	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dcc1f965-6091-4a9b-8a66-0b5bf504acba	57794310-9d2b-47fd-9318-fc704a17709f	onboarding_assignee_role	buddy	Buddy	\N	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0a928042-f9ad-4ba9-a2db-c04a662790fb	57794310-9d2b-47fd-9318-fc704a17709f	onboarding_assignee_role	facilities	Facilities	\N	5	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
60015821-d38e-4f2e-900f-8d0d4b086b7d	57794310-9d2b-47fd-9318-fc704a17709f	kudos_category	teamwork	Teamwork	#3b82f6	0	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9588c06f-d9fe-4187-9174-d4b2634a4b80	57794310-9d2b-47fd-9318-fc704a17709f	kudos_category	innovation	Innovation	#8b5cf6	1	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
24b16e53-82e0-4bcf-be65-b11295c59c2d	57794310-9d2b-47fd-9318-fc704a17709f	kudos_category	leadership	Leadership	#f59e0b	2	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
60be623b-9b60-44ea-8e79-7f3716012810	57794310-9d2b-47fd-9318-fc704a17709f	kudos_category	above_and_beyond	Going Above & Beyond	#22c55e	3	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
823cd4f8-547a-408e-9aad-df475482f5a0	57794310-9d2b-47fd-9318-fc704a17709f	kudos_category	customer_focus	Customer Focus	#14b8a6	4	t	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: meeting_actions; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.meeting_actions (id, meeting_id, title, status, owner_id, carried_from_id, created_at, updated_at) FROM stdin;
c0eb6ab0-ed41-4f43-9787-70c744b3dbd4	d500fdcd-9ec1-418e-ade7-704235468856	Follow up on deployment pipeline	done	48c66b25-24b9-4dcf-8454-419266423422	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
41c20d2f-46df-4581-8f51-34452a4d79b7	d500fdcd-9ec1-418e-ade7-704235468856	Review PR backlog	done	48c66b25-24b9-4dcf-8454-419266423422	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
10c72f65-a870-48eb-9023-601313064c2b	c11184cb-d13e-4f60-843b-ebae425e8357	Schedule design review	done	e883e8c3-9f3c-4ca2-86ba-49841c392367	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
17e31498-e314-44a6-9d1f-e39d34c6edb5	c11184cb-d13e-4f60-843b-ebae425e8357	Update project timeline	done	e883e8c3-9f3c-4ca2-86ba-49841c392367	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
04621414-b01d-45df-808b-c016451c1c07	4b42b579-d63b-40c7-9400-d352e51bd33e	Prepare training materials	done	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
47694fa3-a968-4db4-ad7d-89b90ea8e165	4b42b579-d63b-40c7-9400-d352e51bd33e	Set up monitoring dashboards	done	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9c6eaf53-ec89-49b0-bda4-54d03f9eb070	fd545f05-418a-40e5-ba99-c06a204788cf	Review code coverage targets	done	7632a93b-0150-48a6-9639-b5f84c824690	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a4a563c9-333f-4792-b099-afec418da58d	fd545f05-418a-40e5-ba99-c06a204788cf	Investigate CI failures	done	7632a93b-0150-48a6-9639-b5f84c824690	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a430b38d-166f-44c0-92c2-05b1ef7c813d	68325290-ffab-432a-88ea-ee367cdc56eb	Draft career development plan	done	c6686137-146d-43b4-8919-ed25043403c0	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d2a8887b-cc35-4bb1-b79d-14406e76a5e4	68325290-ffab-432a-88ea-ee367cdc56eb	Book team retrospective	done	c6686137-146d-43b4-8919-ed25043403c0	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4936e4bd-77ab-4d8d-844e-c7883a50d39d	e9b9f73d-18e2-49dc-a353-f5f1f08fa094	Chase vendor for licence renewal	done	c6686137-146d-43b4-8919-ed25043403c0	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e7e50bc5-ab7d-4e47-b313-9c755b5a68e6	e9b9f73d-18e2-49dc-a353-f5f1f08fa094	Prepare sprint demo	done	c6686137-146d-43b4-8919-ed25043403c0	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b0ffcd95-9a25-4f92-afef-4303d49e3bff	6a233d09-30ea-46cd-ac4c-35587c957235	Update risk register	done	652f6dd7-4cad-4786-a938-149c19c645b4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ea142007-2d5a-4496-aee7-044125fcab68	6a233d09-30ea-46cd-ac4c-35587c957235	Arrange knowledge-sharing session	done	652f6dd7-4cad-4786-a938-149c19c645b4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
79927e89-e82a-47c8-a964-edd4a2faf1d3	31d38882-72b1-4430-b32d-49832096b3d1	Write onboarding docs for new starters	done	363609f8-48c4-4e82-98c2-a2c7f42e1f46	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
30d3fc35-a337-40ee-9e71-23a7219794bb	31d38882-72b1-4430-b32d-49832096b3d1	Review budget forecast	done	363609f8-48c4-4e82-98c2-a2c7f42e1f46	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
24f2b7b7-6446-40ed-ba9c-c7b3af34c65b	a7a8d9af-5b95-4b1e-9316-56db8363c2e7	Follow up on deployment pipeline	done	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c4c7b3f0-4522-461f-ac4e-2c937be5ae81	a7a8d9af-5b95-4b1e-9316-56db8363c2e7	Review PR backlog	done	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
711d9c20-46c3-470b-b107-eacc2f28ff62	79874a63-bcb6-4ea4-b665-091e18372fbd	Schedule design review	done	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0b438087-e77c-43c1-8869-e08d3c1d1fda	79874a63-bcb6-4ea4-b665-091e18372fbd	Update project timeline	done	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
028c5d20-f062-4f92-90d6-014cf636faff	88218c33-82e9-4490-8639-920b55a398d1	Prepare training materials	open	29b50239-3ff6-44aa-b8da-d5d67ef0659f	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
10961d5e-3915-45de-bc7b-4a83ad6b58da	88218c33-82e9-4490-8639-920b55a398d1	Set up monitoring dashboards	open	29b50239-3ff6-44aa-b8da-d5d67ef0659f	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5b402f4e-1db4-472d-8809-8df2d5f9570a	c0d21d48-dc44-4ae4-9d92-85600bc8fb95	Review code coverage targets	open	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ab87c9f8-e274-4c7b-8d62-957cd3c62c55	c0d21d48-dc44-4ae4-9d92-85600bc8fb95	Investigate CI failures	open	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2f91753e-8348-4dfd-809d-187d71b23560	ea4e1f07-50df-4ccc-a7a4-fdeb4da260dd	Draft career development plan	open	a7a276c3-188c-48b6-a508-4d1e2bc24658	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
35c5fc4d-6c5d-4d56-adbe-26adf68c375d	ea4e1f07-50df-4ccc-a7a4-fdeb4da260dd	Book team retrospective	open	a7a276c3-188c-48b6-a508-4d1e2bc24658	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
39251794-7ed3-4be2-9b12-a96dd7293406	8fa93004-b2ef-460c-bdce-9c1aea3e2cc5	Chase vendor for licence renewal	open	476a5fd1-f313-41b0-ae18-9ae79a17d19b	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
56df70ca-4989-44cf-8bca-49a53a5824a4	8fa93004-b2ef-460c-bdce-9c1aea3e2cc5	Prepare sprint demo	open	476a5fd1-f313-41b0-ae18-9ae79a17d19b	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: meetings; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.meetings (id, workspace_id, manager_id, report_id, scheduled_date, actual_date, notes, mood, status, created_at, updated_at) FROM stdin;
d500fdcd-9ec1-418e-ade7-704235468856	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	48c66b25-24b9-4dcf-8454-419266423422	2025-12-22	2025-12-22	Regular 1:1 — discussed progress and blockers	good	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c11184cb-d13e-4f60-843b-ebae425e8357	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	e883e8c3-9f3c-4ca2-86ba-49841c392367	2025-12-29	2025-12-29	Regular 1:1 — discussed progress and blockers	neutral	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4b42b579-d63b-40c7-9400-d352e51bd33e	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	2026-01-05	2026-01-05	Regular 1:1 — discussed progress and blockers	good	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
fd545f05-418a-40e5-ba99-c06a204788cf	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	7632a93b-0150-48a6-9639-b5f84c824690	2026-01-12	2026-01-12	Regular 1:1 — discussed progress and blockers	concern	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
68325290-ffab-432a-88ea-ee367cdc56eb	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	c6686137-146d-43b4-8919-ed25043403c0	2026-01-19	2026-01-19	Regular 1:1 — discussed progress and blockers	good	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e9b9f73d-18e2-49dc-a353-f5f1f08fa094	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	c6686137-146d-43b4-8919-ed25043403c0	2026-01-26	2026-01-26	Regular 1:1 — discussed progress and blockers	good	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6a233d09-30ea-46cd-ac4c-35587c957235	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	652f6dd7-4cad-4786-a938-149c19c645b4	2026-02-02	2026-02-02	Regular 1:1 — discussed progress and blockers	neutral	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
31d38882-72b1-4430-b32d-49832096b3d1	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	363609f8-48c4-4e82-98c2-a2c7f42e1f46	2026-02-09	2026-02-09	Regular 1:1 — discussed progress and blockers	good	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a7a8d9af-5b95-4b1e-9316-56db8363c2e7	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	2026-02-16	2026-02-16	Regular 1:1 — discussed progress and blockers	good	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
79874a63-bcb6-4ea4-b665-091e18372fbd	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	2026-02-23	2026-02-23	Regular 1:1 — discussed progress and blockers	neutral	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
88218c33-82e9-4490-8639-920b55a398d1	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	29b50239-3ff6-44aa-b8da-d5d67ef0659f	2026-03-02	2026-03-02	Regular 1:1 — discussed progress and blockers	good	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c0d21d48-dc44-4ae4-9d92-85600bc8fb95	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	2026-03-09	2026-03-09	Regular 1:1 — discussed progress and blockers	concern	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ea4e1f07-50df-4ccc-a7a4-fdeb4da260dd	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	a7a276c3-188c-48b6-a508-4d1e2bc24658	2026-03-16	2026-03-16	Regular 1:1 — discussed progress and blockers	good	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8fa93004-b2ef-460c-bdce-9c1aea3e2cc5	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	476a5fd1-f313-41b0-ae18-9ae79a17d19b	2026-03-23	2026-03-23	Regular 1:1 — discussed progress and blockers	good	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
29e1093d-92db-42ec-99f9-7f28c396d0f3	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	a2633e0c-d058-40da-a843-422fcf15adac	2026-03-09	\N	\N	\N	scheduled	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f581c359-8bba-4d31-a258-7a97833918bf	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	622ebdf1-e160-4a28-91df-0b7089713829	2026-03-16	\N	\N	\N	scheduled	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2e85c7b3-438b-43c4-ae86-d0e6b1277938	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	a8212044-03bd-4270-bf0a-1f407b2f9111	2026-03-23	\N	\N	\N	scheduled	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
acaaffa0-be62-4262-b799-59ccb3fcc310	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	a03cbcf7-960e-4f51-8023-b914b77ea368	2026-03-30	\N	\N	\N	scheduled	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
757c68c0-c097-44dd-bf67-94ce4bb11b3f	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	7a6a5744-371f-4561-90d4-d6b470339606	2026-04-06	\N	\N	\N	scheduled	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2c1b2e85-216f-45da-bf6e-df93d7b33e73	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	2026-04-13	\N	\N	\N	scheduled	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.milestones (id, name, date, colour, project_id, workspace_id, created_at, updated_at) FROM stdin;
a859f874-9b5a-4e18-9daf-527b9b98e128	Sprint 1 Complete	2026-03-09	#E44332	371652ef-a083-4558-9e6a-cd5dee1b6acf	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
78e11df2-3dc1-419b-b229-11845f43b09e	Beta Release	2026-03-16	#4186E0	6effa62a-7e17-4c33-b749-4a69ad341e35	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1a465d9f-3e87-454f-aa98-5a9d05bb9c61	Launch Day	2026-03-23	#5CBF4D	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.notifications (id, user_id, workspace_id, event_type, title, body, is_read, link, actor_id, task_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: objectives; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.objectives (id, workspace_id, user_id, review_period_id, parent_id, title, description, category, status, progress, weight, created_at, updated_at) FROM stdin;
cc50c036-73e4-472c-bc3c-68cbcceff2b0	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	5acf4864-1579-4d54-a572-94b0a9225996	\N	Reduce API P95 latency below 200ms	\N	performance	active	65	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0b28ce57-f277-4e57-918f-66957db76ff7	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	5acf4864-1579-4d54-a572-94b0a9225996	\N	Ship mobile app v3.0 to App Store	\N	business	active	45	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5ea7f009-ca5c-4d16-8d60-bcad40f98cc0	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	5acf4864-1579-4d54-a572-94b0a9225996	\N	Achieve 90% test coverage on core modules	\N	performance	active	70	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1fa14c45-3002-4537-8fb2-c8713805a00a	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	5acf4864-1579-4d54-a572-94b0a9225996	\N	Redesign onboarding user flow	\N	business	active	30	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bf0546f1-8692-49af-8761-9350497a5ba4	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	5acf4864-1579-4d54-a572-94b0a9225996	\N	Launch Q1 multi-channel marketing campaign	\N	business	completed	100	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6c845e55-0013-44e5-bb85-4d7df9861a3f	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	5acf4864-1579-4d54-a572-94b0a9225996	\N	Implement WCAG 2.1 AA accessibility across portal	\N	development	active	20	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
38a915bb-d612-452a-92b9-608889e72c43	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	5acf4864-1579-4d54-a572-94b0a9225996	\N	Reduce deployment time to under 5 minutes	\N	performance	active	80	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2bb69123-40f0-4b77-98c3-0dc52ca92647	57794310-9d2b-47fd-9318-fc704a17709f	29b50239-3ff6-44aa-b8da-d5d67ef0659f	5acf4864-1579-4d54-a572-94b0a9225996	\N	Create comprehensive design system documentation	\N	development	active	55	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f538978d-0014-4a92-b052-b08914e2f0a9	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	5acf4864-1579-4d54-a572-94b0a9225996	\N	Migrate entire data layer to async	\N	performance	completed	100	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e7ad56c0-edfc-4db3-a1dd-5ecbfcb4ff96	57794310-9d2b-47fd-9318-fc704a17709f	476a5fd1-f313-41b0-ae18-9ae79a17d19b	5acf4864-1579-4d54-a572-94b0a9225996	\N	Increase social media engagement by 25%	\N	business	active	40	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0485dab7-9ea4-402d-ade9-654fcfc56db7	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	5acf4864-1579-4d54-a572-94b0a9225996	\N	Implement zero-trust security architecture	\N	performance	active	35	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
96aa8463-31fe-48c0-af65-af08cb9f5ed2	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	5acf4864-1579-4d54-a572-94b0a9225996	\N	Build real-time analytics dashboard	\N	business	active	50	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
50afcea0-cd62-45a5-8e3b-d910c257bc7b	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	5acf4864-1579-4d54-a572-94b0a9225996	\N	Establish product discovery framework	\N	development	active	25	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b99909a3-524b-41d0-8e45-7f4286650fe7	57794310-9d2b-47fd-9318-fc704a17709f	a8212044-03bd-4270-bf0a-1f407b2f9111	5acf4864-1579-4d54-a572-94b0a9225996	\N	Reduce customer support tickets by 30%	\N	business	active	15	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
87e3204b-1d45-4d07-bf51-f315bd9551fe	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	5acf4864-1579-4d54-a572-94b0a9225996	\N	Launch employee referral programme	\N	business	active	60	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1aa8d9d6-6727-4590-9092-508c8d4454a0	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	5acf4864-1579-4d54-a572-94b0a9225996	\N	Containerise all legacy services	\N	performance	active	75	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
94046e3c-3918-42d8-877f-8c69f69992fd	57794310-9d2b-47fd-9318-fc704a17709f	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	5acf4864-1579-4d54-a572-94b0a9225996	\N	Design component library v2	\N	development	active	40	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e6a5ede4-f818-4e6b-bb5a-991f683c596c	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	5acf4864-1579-4d54-a572-94b0a9225996	\N	Implement automated compliance reporting	\N	performance	active	10	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
faf72c4e-4258-4258-9f55-fc0fc3891481	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	5acf4864-1579-4d54-a572-94b0a9225996	\N	Build ML model for churn prediction	\N	business	draft	0	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
41aeaf27-fc60-4a48-98b2-9dc58c6d2a4a	57794310-9d2b-47fd-9318-fc704a17709f	652f6dd7-4cad-4786-a938-149c19c645b4	5acf4864-1579-4d54-a572-94b0a9225996	\N	Migrate CI/CD to GitHub Actions	\N	performance	active	90	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b8ecd491-284b-4c67-82fe-2b8a8e0ca474	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	5acf4864-1579-4d54-a572-94b0a9225996	\N	Create customer feedback loop process	\N	business	active	35	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ba6af086-efed-490c-ad74-71ff57edf7a7	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	5acf4864-1579-4d54-a572-94b0a9225996	\N	Develop brand guidelines v3	\N	development	active	70	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8f3c12a1-f351-43ea-83a8-560083ce0ca4	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	5acf4864-1579-4d54-a572-94b0a9225996	\N	Optimise database query performance	\N	performance	active	55	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dfd13c8b-7529-4443-86a5-b471e9cd776c	57794310-9d2b-47fd-9318-fc704a17709f	a8212044-03bd-4270-bf0a-1f407b2f9111	5acf4864-1579-4d54-a572-94b0a9225996	\N	Improve NPS score from 42 to 55	\N	business	active	20	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0a51645a-7bc4-492a-872f-9c5dbc2ed60e	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	5acf4864-1579-4d54-a572-94b0a9225996	\N	Reduce infrastructure costs by 20%	\N	performance	cancelled	30	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7ba8b444-a113-4572-8d99-ada76aa642ac	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	576200d2-f0e9-4273-adbe-683d29aececd	\N	Launch website redesign	\N	business	completed	100	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d1762308-467a-4a60-99a3-7febb3bc1548	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	576200d2-f0e9-4273-adbe-683d29aececd	\N	Hire 5 engineers	\N	business	completed	100	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
eb8e2d36-1f0a-4dbb-9be0-81a6dfea9cbc	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	576200d2-f0e9-4273-adbe-683d29aececd	\N	Set up design system foundations	\N	development	completed	100	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b1bc31a4-3431-4883-890e-ee4899f8cf49	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	576200d2-f0e9-4273-adbe-683d29aececd	\N	Implement SSO across all products	\N	performance	completed	100	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b7217b91-bd05-4928-b09e-832f9a7b686d	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	576200d2-f0e9-4273-adbe-683d29aececd	\N	Run first pulse survey	\N	business	completed	100	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: onboarding_checklist_items; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.onboarding_checklist_items (id, checklist_id, title, description, sort_order, completed, assigned_to, created_at, updated_at) FROM stdin;
4da96cb4-1f41-4447-bc7b-899bf117ab93	da29e25c-7342-48fd-b412-8825afab424e	IT setup — laptop, monitors, peripherals	\N	0	t	a03cbcf7-960e-4f51-8023-b914b77ea368	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2e810dd1-1e95-4096-a218-dba29e4de0c0	da29e25c-7342-48fd-b412-8825afab424e	Create accounts — GitHub, Jira, Slack, AWS	\N	1	t	a03cbcf7-960e-4f51-8023-b914b77ea368	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e6c25afe-0f55-4e7d-b284-d5cf99692e61	da29e25c-7342-48fd-b412-8825afab424e	HR induction session	\N	2	t	a03cbcf7-960e-4f51-8023-b914b77ea368	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
91971412-94ff-4db5-9a13-d8f006f82d9f	da29e25c-7342-48fd-b412-8825afab424e	Meet the team lunch	\N	3	t	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
de224d65-ddd8-4f11-b399-0b271ef44e59	da29e25c-7342-48fd-b412-8825afab424e	Dev environment setup walkthrough	\N	4	t	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3fb826cf-0e1e-4e36-a744-a58a0f7750ea	da29e25c-7342-48fd-b412-8825afab424e	Complete security awareness training	\N	5	t	a03cbcf7-960e-4f51-8023-b914b77ea368	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b68d8796-55f2-42dd-83b6-328be513c6fe	da29e25c-7342-48fd-b412-8825afab424e	Review architecture documentation	\N	6	t	a03cbcf7-960e-4f51-8023-b914b77ea368	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
365bf147-a1ac-4894-9398-54c3287e1c4a	da29e25c-7342-48fd-b412-8825afab424e	First week 1:1 with manager	\N	7	t	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
280b52bc-da72-448c-83c9-17c898ef2d5d	da29e25c-7342-48fd-b412-8825afab424e	Pair programming session with buddy	\N	8	f	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b0949c28-1439-426f-95fb-f96cd94124c4	da29e25c-7342-48fd-b412-8825afab424e	Set initial 90-day objectives	\N	9	f	a03cbcf7-960e-4f51-8023-b914b77ea368	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
53ab8e9e-0f98-4677-8297-3e6263770f6f	da29e25c-7342-48fd-b412-8825afab424e	Building access and security badge	\N	10	f	a03cbcf7-960e-4f51-8023-b914b77ea368	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
49ae8fae-2ddd-42d0-ae02-25fca21ac99c	da29e25c-7342-48fd-b412-8825afab424e	Complete code review training	\N	11	f	a03cbcf7-960e-4f51-8023-b914b77ea368	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
19119760-b025-4bd2-91d0-5e1c6b49af73	41b2b458-af00-44bd-b939-1c5688817faf	IT setup — laptop and accounts	\N	0	t	622ebdf1-e160-4a28-91df-0b7089713829	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
11142b3c-6fa6-4b03-ae78-826f1b69399c	41b2b458-af00-44bd-b939-1c5688817faf	HR induction session	\N	1	t	622ebdf1-e160-4a28-91df-0b7089713829	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dda1b257-6686-4828-8ca5-aae66b7a1890	41b2b458-af00-44bd-b939-1c5688817faf	Meet the team lunch	\N	2	t	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
fd088517-2d41-4ff1-b980-73e56257e330	41b2b458-af00-44bd-b939-1c5688817faf	Complete compliance training	\N	3	t	622ebdf1-e160-4a28-91df-0b7089713829	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c3c5d125-f0a5-42e0-95b5-f38041338dae	41b2b458-af00-44bd-b939-1c5688817faf	First week check-in with manager	\N	4	f	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1218e034-8011-4f63-ac36-62ca8ff1daf0	41b2b458-af00-44bd-b939-1c5688817faf	Set initial objectives	\N	5	f	622ebdf1-e160-4a28-91df-0b7089713829	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6db27f0e-f3db-430b-94bc-56670e034227	41b2b458-af00-44bd-b939-1c5688817faf	Building access and security badge	\N	6	f	622ebdf1-e160-4a28-91df-0b7089713829	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c95bec77-d384-45ff-84d0-e94e819ea4d3	bf331b31-195f-4e45-bfce-16097678b18e	IT setup — laptop and accounts	\N	0	t	a7a276c3-188c-48b6-a508-4d1e2bc24658	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bbfe6aa1-5774-4f2b-af91-aeedbec25488	bf331b31-195f-4e45-bfce-16097678b18e	HR induction session	\N	1	t	a7a276c3-188c-48b6-a508-4d1e2bc24658	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
806ef6a7-7896-417c-b8e3-7033de243239	bf331b31-195f-4e45-bfce-16097678b18e	Meet the team lunch	\N	2	t	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
77ff0af6-4452-4f69-8554-24cc7e6f87d9	bf331b31-195f-4e45-bfce-16097678b18e	Complete compliance training	\N	3	t	a7a276c3-188c-48b6-a508-4d1e2bc24658	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2c48b015-1111-40dd-908f-9df3cd0d7603	bf331b31-195f-4e45-bfce-16097678b18e	First week check-in with manager	\N	4	t	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1350a850-e0d2-40ce-963e-c48bd7b8458c	bf331b31-195f-4e45-bfce-16097678b18e	Set initial objectives	\N	5	t	a7a276c3-188c-48b6-a508-4d1e2bc24658	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9775ab7e-c4fe-49b1-b76a-cc3aca0664c3	bf331b31-195f-4e45-bfce-16097678b18e	Building access and security badge	\N	6	f	a7a276c3-188c-48b6-a508-4d1e2bc24658	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
603bf847-f948-48c5-8f49-6612fca8c28b	6cc5ff5a-01bf-4ef8-9078-eca7e77399c2	IT setup — laptop and accounts	\N	0	t	a2633e0c-d058-40da-a843-422fcf15adac	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ffcea5e3-9e9c-4964-a8d7-eb0f3fb65798	6cc5ff5a-01bf-4ef8-9078-eca7e77399c2	HR induction session	\N	1	t	a2633e0c-d058-40da-a843-422fcf15adac	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e0085872-dcff-43ad-996d-86eadf35c8f0	6cc5ff5a-01bf-4ef8-9078-eca7e77399c2	Meet the team lunch	\N	2	t	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
77bda29b-9cac-4174-a254-8e91ff13bb8a	6cc5ff5a-01bf-4ef8-9078-eca7e77399c2	Complete compliance training	\N	3	t	a2633e0c-d058-40da-a843-422fcf15adac	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d0a64e52-c867-46c1-b271-47f9116a327c	6cc5ff5a-01bf-4ef8-9078-eca7e77399c2	First week check-in with manager	\N	4	t	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bec1266f-ba04-4242-954d-c2a2c88842b8	6cc5ff5a-01bf-4ef8-9078-eca7e77399c2	Set initial objectives	\N	5	t	a2633e0c-d058-40da-a843-422fcf15adac	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3661dba7-b8d6-464b-975e-191fca2b7e8e	6cc5ff5a-01bf-4ef8-9078-eca7e77399c2	Building access and security badge	\N	6	t	a2633e0c-d058-40da-a843-422fcf15adac	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: onboarding_checklists; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.onboarding_checklists (id, workspace_id, user_id, template_id, checklist_type, status, created_at, updated_at) FROM stdin;
da29e25c-7342-48fd-b412-8825afab424e	57794310-9d2b-47fd-9318-fc704a17709f	a03cbcf7-960e-4f51-8023-b914b77ea368	39991ecb-0a1e-4cb9-90b0-58f6223c989e	onboarding	in_progress	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
41b2b458-af00-44bd-b939-1c5688817faf	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	2d583208-e27f-4591-9f1b-5df08f1d9e85	onboarding	in_progress	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bf331b31-195f-4e45-bfce-16097678b18e	57794310-9d2b-47fd-9318-fc704a17709f	a7a276c3-188c-48b6-a508-4d1e2bc24658	2d583208-e27f-4591-9f1b-5df08f1d9e85	onboarding	in_progress	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6cc5ff5a-01bf-4ef8-9078-eca7e77399c2	57794310-9d2b-47fd-9318-fc704a17709f	a2633e0c-d058-40da-a843-422fcf15adac	2d583208-e27f-4591-9f1b-5df08f1d9e85	onboarding	completed	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: onboarding_template_items; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.onboarding_template_items (id, template_id, title, description, sort_order, default_assignee_role, created_at, updated_at) FROM stdin;
e8024f9c-578e-4bda-8d63-82c4866dc69e	39991ecb-0a1e-4cb9-90b0-58f6223c989e	IT setup — laptop, monitors, peripherals	\N	0	it	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9e37b0b2-7f26-4cdf-8bb9-c80d3a239885	39991ecb-0a1e-4cb9-90b0-58f6223c989e	Create accounts — GitHub, Jira, Slack, AWS	\N	1	it	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0fbc0aa9-94a5-4cd2-beb5-7c4f49ca964f	39991ecb-0a1e-4cb9-90b0-58f6223c989e	HR induction session	\N	2	hr	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2a6f9e90-06e4-4dad-9684-d0500359f26e	39991ecb-0a1e-4cb9-90b0-58f6223c989e	Meet the team lunch	\N	3	manager	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
35fded07-559f-4364-a1c5-b314d0cdeff2	39991ecb-0a1e-4cb9-90b0-58f6223c989e	Dev environment setup walkthrough	\N	4	manager	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
956f1f0d-ffd9-4cfd-9fe3-b24518a1565f	39991ecb-0a1e-4cb9-90b0-58f6223c989e	Complete security awareness training	\N	5	new_starter	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1cf66766-de75-4046-99ea-72ec50ea5b09	39991ecb-0a1e-4cb9-90b0-58f6223c989e	Review architecture documentation	\N	6	new_starter	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
776c6689-be46-423c-a5de-fe411917924e	39991ecb-0a1e-4cb9-90b0-58f6223c989e	First week 1:1 with manager	\N	7	manager	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b7e67361-ca98-4b9f-a211-096d333a6a76	39991ecb-0a1e-4cb9-90b0-58f6223c989e	Pair programming session with buddy	\N	8	manager	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
454a343d-5f67-4840-aa48-ccccdae2e8b9	39991ecb-0a1e-4cb9-90b0-58f6223c989e	Set initial 90-day objectives	\N	9	new_starter	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a171df0d-3ab4-4447-885f-17b583faad02	39991ecb-0a1e-4cb9-90b0-58f6223c989e	Building access and security badge	\N	10	it	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
339b85f8-6534-4d82-a6fd-e1879378af11	39991ecb-0a1e-4cb9-90b0-58f6223c989e	Complete code review training	\N	11	new_starter	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dffd1dc6-3531-49f3-8da1-369412c6f436	2d583208-e27f-4591-9f1b-5df08f1d9e85	IT setup — laptop and accounts	\N	0	it	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6761fda4-8254-4e92-825f-e258dfbd51e7	2d583208-e27f-4591-9f1b-5df08f1d9e85	HR induction session	\N	1	hr	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f03abaea-2bdc-4a00-815d-84ab91fa35ef	2d583208-e27f-4591-9f1b-5df08f1d9e85	Meet the team lunch	\N	2	manager	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
faccf2a0-e3fc-4641-9121-701748c3a939	2d583208-e27f-4591-9f1b-5df08f1d9e85	Complete compliance training	\N	3	new_starter	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4b6a9da1-3129-4e5a-9ac5-571c9b5f123e	2d583208-e27f-4591-9f1b-5df08f1d9e85	First week check-in with manager	\N	4	manager	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
63ecb575-3662-45e7-8c1b-ef5e57c5b119	2d583208-e27f-4591-9f1b-5df08f1d9e85	Set initial objectives	\N	5	new_starter	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
18ecc355-370a-48c3-9cd4-d1cb77272958	2d583208-e27f-4591-9f1b-5df08f1d9e85	Building access and security badge	\N	6	it	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: onboarding_templates; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.onboarding_templates (id, workspace_id, name, template_type, description, created_at, updated_at) FROM stdin;
39991ecb-0a1e-4cb9-90b0-58f6223c989e	57794310-9d2b-47fd-9318-fc704a17709f	Engineering Onboarding	onboarding	Full onboarding for engineering hires	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2d583208-e27f-4591-9f1b-5df08f1d9e85	57794310-9d2b-47fd-9318-fc704a17709f	General Onboarding	onboarding	Standard onboarding for all departments	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
089b6f3d-46a3-41a6-a6e1-626ca9b7f987	57794310-9d2b-47fd-9318-fc704a17709f	Offboarding Process	offboarding	Standard offboarding checklist	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: person_documents; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.person_documents (id, profile_id, workspace_id, document_type, filename, file_path, file_size, mime_type, expiry_date, uploaded_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: person_profiles; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.person_profiles (id, user_id, workspace_id, job_title, department, manager_id, contract_type, contract_start, contract_end, probation_end, location, phone, employee_id, notes, date_of_birth, partner_name, number_of_kids, kids_details, interests, dietary_requirements, emergency_contact, personal_notes, created_at, updated_at) FROM stdin;
8fae3148-c243-4e8d-9c17-1ed479afba86	d661e296-5b5e-4b4d-bc00-e9d393137c57	57794310-9d2b-47fd-9318-fc704a17709f	VP of Engineering	Engineering	\N	permanent	2021-03-03	\N	\N	London	+44 7700 900000	EMP100	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e23ea49e-fbbf-456f-8724-1044751c2ec0	48c66b25-24b9-4dcf-8454-419266423422	57794310-9d2b-47fd-9318-fc704a17709f	Senior Developer	Engineering	d661e296-5b5e-4b4d-bc00-e9d393137c57	permanent	2022-03-03	\N	\N	London	+44 7700 900001	EMP101	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1d2c51df-fa66-4eb7-9202-d6410b212e2f	e883e8c3-9f3c-4ca2-86ba-49841c392367	57794310-9d2b-47fd-9318-fc704a17709f	Backend Developer	Engineering	d661e296-5b5e-4b4d-bc00-e9d393137c57	permanent	2023-03-03	\N	\N	London	+44 7700 900002	EMP102	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f13c254e-bc88-4ad0-8898-9775adb3c9de	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	57794310-9d2b-47fd-9318-fc704a17709f	Lead Designer	Design	d661e296-5b5e-4b4d-bc00-e9d393137c57	permanent	2022-03-03	\N	\N	Manchester	+44 7700 900003	EMP103	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
03988a38-9fae-4e8b-8925-6b4280631d19	7632a93b-0150-48a6-9639-b5f84c824690	57794310-9d2b-47fd-9318-fc704a17709f	Marketing Manager	Marketing	d661e296-5b5e-4b4d-bc00-e9d393137c57	permanent	2024-03-02	\N	\N	Manchester	+44 7700 900004	EMP104	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
73cde2c3-5c6a-4dbc-81ea-0b8dc94185d6	c6686137-146d-43b4-8919-ed25043403c0	57794310-9d2b-47fd-9318-fc704a17709f	Platform Engineer	Engineering	48c66b25-24b9-4dcf-8454-419266423422	permanent	2023-03-03	\N	\N	London	+44 7700 900005	EMP105	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
049dc5cf-92fd-4cbb-879a-8fd6fa3b0c70	29b50239-3ff6-44aa-b8da-d5d67ef0659f	57794310-9d2b-47fd-9318-fc704a17709f	UX Designer	Design	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	permanent	2024-03-02	\N	\N	Manchester	+44 7700 900006	EMP106	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
70dc1be1-4e25-47e2-9a1a-e48d4da977a2	476a5fd1-f313-41b0-ae18-9ae79a17d19b	57794310-9d2b-47fd-9318-fc704a17709f	Content Strategist	Marketing	7632a93b-0150-48a6-9639-b5f84c824690	permanent	2025-03-02	\N	\N	London	+44 7700 900007	EMP107	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1a437a05-046e-45db-a584-f66245309993	652f6dd7-4cad-4786-a938-149c19c645b4	57794310-9d2b-47fd-9318-fc704a17709f	Full Stack Developer	Engineering	48c66b25-24b9-4dcf-8454-419266423422	permanent	2024-03-02	\N	\N	Bristol	+44 7700 900008	EMP108	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
09af346a-e06e-4053-bc30-6f4b1b2d1cee	363609f8-48c4-4e82-98c2-a2c7f42e1f46	57794310-9d2b-47fd-9318-fc704a17709f	DevOps Engineer	Engineering	48c66b25-24b9-4dcf-8454-419266423422	permanent	2023-03-03	\N	\N	London	+44 7700 900009	EMP109	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c5fda538-1f7f-4bb1-a8d0-8236b5d5788c	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	57794310-9d2b-47fd-9318-fc704a17709f	Product Designer	Design	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	permanent	2025-03-02	\N	\N	Edinburgh	+44 7700 900010	EMP110	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
edf2da04-6c4e-4389-908a-8c322435e0a1	7a6a5744-371f-4561-90d4-d6b470339606	57794310-9d2b-47fd-9318-fc704a17709f	Product Manager	Product	d661e296-5b5e-4b4d-bc00-e9d393137c57	permanent	2023-03-03	\N	\N	London	+44 7700 900011	EMP111	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a25277a2-fbeb-421c-ba35-fcff727f3f29	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	57794310-9d2b-47fd-9318-fc704a17709f	Data Engineer	Engineering	48c66b25-24b9-4dcf-8454-419266423422	permanent	2024-03-02	\N	\N	London	+44 7700 900012	EMP112	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
877a7b54-18c1-4bf8-8b80-f42b0c0d96eb	a2633e0c-d058-40da-a843-422fcf15adac	57794310-9d2b-47fd-9318-fc704a17709f	Digital Marketing Exec	Marketing	7632a93b-0150-48a6-9639-b5f84c824690	fixed_term	2025-03-02	2026-08-29	\N	Manchester	+44 7700 900013	EMP113	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bdd81546-e4bb-40a0-b37e-e02846573663	a8212044-03bd-4270-bf0a-1f407b2f9111	57794310-9d2b-47fd-9318-fc704a17709f	Product Owner	Product	7a6a5744-371f-4561-90d4-d6b470339606	permanent	2024-03-02	\N	\N	London	+44 7700 900014	EMP114	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
df7847b4-f91c-4709-8e93-563e905b8770	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	57794310-9d2b-47fd-9318-fc704a17709f	Security Engineer	Engineering	d661e296-5b5e-4b4d-bc00-e9d393137c57	permanent	2022-03-03	\N	\N	London	+44 7700 900015	EMP115	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c5336991-ce0d-4f09-bab7-a4559cdaaf96	a03cbcf7-960e-4f51-8023-b914b77ea368	57794310-9d2b-47fd-9318-fc704a17709f	Junior Product Analyst	Product	7a6a5744-371f-4561-90d4-d6b470339606	fixed_term	2026-03-02	2026-08-29	2026-05-31	Bristol	+44 7700 900016	EMP116	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f275a0a0-bd50-4ef8-8b56-41ce53550220	a7a276c3-188c-48b6-a508-4d1e2bc24658	57794310-9d2b-47fd-9318-fc704a17709f	UI Designer	Design	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	contractor	2025-03-02	2026-08-29	\N	Remote	+44 7700 900017	EMP117	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d3c2f24b-1c7b-461f-a955-7bd2b7e513dc	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	57794310-9d2b-47fd-9318-fc704a17709f	Data Scientist	Engineering	48c66b25-24b9-4dcf-8454-419266423422	permanent	2024-03-02	\N	\N	Edinburgh	+44 7700 900018	EMP118	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6b5fdc4f-be30-405b-9bb5-5e8f47d13c71	622ebdf1-e160-4a28-91df-0b7089713829	57794310-9d2b-47fd-9318-fc704a17709f	Marketing Coordinator	Marketing	7632a93b-0150-48a6-9639-b5f84c824690	fixed_term	2026-03-02	2026-08-29	2026-05-31	Manchester	+44 7700 900019	EMP119	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.projects (id, name, colour, status, is_favourite, custom_statuses, client_id, workspace_id, created_at, updated_at) FROM stdin;
371652ef-a083-4558-9e6a-cd5dee1b6acf	Website Redesign	#4186E0	active	f	\N	709e5031-bbad-4b99-80b2-53a7e317120e	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6effa62a-7e17-4c33-b749-4a69ad341e35	Mobile App v3	#E44332	active	f	\N	709e5031-bbad-4b99-80b2-53a7e317120e	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0d645a1e-2e1c-4410-b3bc-5a2e88fe2c33	API Platform	#5CBF4D	active	f	\N	722d5e88-9189-4c75-852b-a98f1466a36a	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c561ac35-916a-4299-92f3-1f3fb4cca3b0	Marketing Campaign Q1	#F0C239	active	f	\N	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bf8bc581-8926-4df6-80ce-9b018d7a3499	Data Pipeline	#9B59B6	active	f	\N	f27dcdf8-5280-4913-b3a5-b3b6e886fd6e	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5bc7deb4-9bca-4203-9dda-247f13eafe5f	Customer Portal	#1ABC9C	active	f	\N	722d5e88-9189-4c75-852b-a98f1466a36a	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: pulse_responses; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.pulse_responses (id, survey_id, user_id, morale, workload, support, comments, created_at, updated_at) FROM stdin;
f9979013-dd14-4503-adbc-4118e2f6f680	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	7632a93b-0150-48a6-9639-b5f84c824690	3	3	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
765cfc87-603b-4b1f-9402-b6a1ffa6df4c	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	a8212044-03bd-4270-bf0a-1f407b2f9111	2	3	4	Feeling a bit overwhelmed with workload recently	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b36df873-6800-4090-936c-aa52d0b594e7	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	d661e296-5b5e-4b4d-bc00-e9d393137c57	3	3	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1bd73201-5f20-4df0-af6d-33d83e8cdf30	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	48c66b25-24b9-4dcf-8454-419266423422	3	2	4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
96f8a2d5-8ac7-4362-9aad-20456ac5c591	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	c6686137-146d-43b4-8919-ed25043403c0	3	2	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2f0ae894-4e69-47e7-963c-501ae47097f7	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	7a6a5744-371f-4561-90d4-d6b470339606	5	3	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5df86497-42d0-44ab-bf0d-7d2304c00089	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	29b50239-3ff6-44aa-b8da-d5d67ef0659f	2	3	4	Feeling a bit overwhelmed with workload recently	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b6cc3ef5-4f0f-4414-9197-c4c6c4d6e0bc	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	5	4	5	Great team atmosphere lately	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d0962779-3262-4939-ad56-5ecc325a8eef	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	a2633e0c-d058-40da-a843-422fcf15adac	3	3	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
50b5d6f2-2c34-49d7-8dc3-d374a8aa59c8	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	363609f8-48c4-4e82-98c2-a2c7f42e1f46	5	2	2	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d95c4fa9-fb2e-4b8f-a40a-6ae51970b98c	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	3	4	4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
215dd280-b353-456e-8b3d-e72ef4032019	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	3	4	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
072aa435-cc50-4e0e-a646-8f1dccf6c04b	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	4	4	3	Feeling productive and supported	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
08611837-754b-401c-96a8-766ed014df18	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	a7a276c3-188c-48b6-a508-4d1e2bc24658	3	2	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
885812ee-9ab5-4c5b-9b19-f590b7e611a5	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	622ebdf1-e160-4a28-91df-0b7089713829	2	2	2	Would appreciate more clarity on team priorities	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e7559cd3-9cdf-4f7e-947f-560f280f7f81	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	652f6dd7-4cad-4786-a938-149c19c645b4	4	4	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
41ac7fa5-02ba-45e2-ae51-e3b924b81292	c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	476a5fd1-f313-41b0-ae18-9ae79a17d19b	2	2	4	Struggling to maintain work-life balance	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
07d936f0-d16e-4fbf-b5e1-8606bd951cf7	ad6487a7-8db3-4cb6-80e8-d34d82848562	d661e296-5b5e-4b4d-bc00-e9d393137c57	4	3	3	Things are going well, enjoying the current projects	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
72608638-e0e9-4efb-9f6b-4f678ecd9cbb	ad6487a7-8db3-4cb6-80e8-d34d82848562	7632a93b-0150-48a6-9639-b5f84c824690	2	4	4	Feeling a bit overwhelmed with workload recently	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c4488084-717a-4c1b-af94-b80ee4df874c	ad6487a7-8db3-4cb6-80e8-d34d82848562	a7a276c3-188c-48b6-a508-4d1e2bc24658	2	3	3	Would appreciate more clarity on team priorities	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d44dfc82-d726-4c77-bae4-5a21c6bfc8c7	ad6487a7-8db3-4cb6-80e8-d34d82848562	a03cbcf7-960e-4f51-8023-b914b77ea368	4	5	3	Great team atmosphere lately	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0a7a6601-62bc-4480-bb4d-10035994fcec	ad6487a7-8db3-4cb6-80e8-d34d82848562	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	3	4	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
30cb9c82-9575-4961-be9f-e84574aff5cc	ad6487a7-8db3-4cb6-80e8-d34d82848562	a2633e0c-d058-40da-a843-422fcf15adac	5	4	4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
cd03450e-2e64-4322-b488-c360a15dac73	ad6487a7-8db3-4cb6-80e8-d34d82848562	e883e8c3-9f3c-4ca2-86ba-49841c392367	3	4	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
546a603c-4d91-41ed-a8af-87bc9ca4476c	ad6487a7-8db3-4cb6-80e8-d34d82848562	c6686137-146d-43b4-8919-ed25043403c0	2	2	2	Struggling to maintain work-life balance	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
07629c3d-f324-4339-a187-4d31aa9607a5	ad6487a7-8db3-4cb6-80e8-d34d82848562	652f6dd7-4cad-4786-a938-149c19c645b4	2	3	3	Would appreciate more clarity on team priorities	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2a4d3f7a-b424-482b-89af-7b30da2baf88	ad6487a7-8db3-4cb6-80e8-d34d82848562	7a6a5744-371f-4561-90d4-d6b470339606	2	4	3	Would appreciate more clarity on team priorities	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
28b61db0-a993-47b4-a93f-382852d6b05a	ad6487a7-8db3-4cb6-80e8-d34d82848562	a8212044-03bd-4270-bf0a-1f407b2f9111	2	5	2	Struggling to maintain work-life balance	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
85f31ba6-28bd-4b6d-94f4-991b34fbf601	ad6487a7-8db3-4cb6-80e8-d34d82848562	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	3	3	2	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
18a89a6c-5ff4-4936-8f49-2edd1a4cb701	ad6487a7-8db3-4cb6-80e8-d34d82848562	29b50239-3ff6-44aa-b8da-d5d67ef0659f	4	4	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0abb21a9-6485-4f77-aea5-3552862e72e4	ad6487a7-8db3-4cb6-80e8-d34d82848562	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	3	3	2	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
47f7811a-88a2-4a86-afc6-20eb0b94afd9	ad6487a7-8db3-4cb6-80e8-d34d82848562	363609f8-48c4-4e82-98c2-a2c7f42e1f46	2	5	5	Struggling to maintain work-life balance	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
98c49257-8291-4690-b42d-51770e504c76	677efef0-56f4-4861-b1ad-3c9deec5ffe2	622ebdf1-e160-4a28-91df-0b7089713829	5	5	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ee5e6b14-e9ce-49f3-ae81-a0dd287206cc	677efef0-56f4-4861-b1ad-3c9deec5ffe2	29b50239-3ff6-44aa-b8da-d5d67ef0659f	2	4	3	Would appreciate more clarity on team priorities	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1f9c0e1f-1a11-46c6-84aa-78da7a97d71f	677efef0-56f4-4861-b1ad-3c9deec5ffe2	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	5	4	5	Feeling productive and supported	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c09256ca-db77-49d3-9c03-f1be92c94cdb	677efef0-56f4-4861-b1ad-3c9deec5ffe2	476a5fd1-f313-41b0-ae18-9ae79a17d19b	3	4	4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1658df91-1168-4ece-8cc8-368899fc78e3	677efef0-56f4-4861-b1ad-3c9deec5ffe2	a8212044-03bd-4270-bf0a-1f407b2f9111	2	3	3	Would appreciate more clarity on team priorities	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
253f1c7f-a167-44ac-abd9-50fe5b325708	677efef0-56f4-4861-b1ad-3c9deec5ffe2	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	3	4	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1e4c3d76-378e-4b42-b110-a9dd4d4c8bfb	677efef0-56f4-4861-b1ad-3c9deec5ffe2	363609f8-48c4-4e82-98c2-a2c7f42e1f46	3	4	4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e621bab6-d46a-4c00-bece-a17cbef6f9fc	677efef0-56f4-4861-b1ad-3c9deec5ffe2	652f6dd7-4cad-4786-a938-149c19c645b4	3	2	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
af3da904-0e50-4957-961c-dfa659a268b1	677efef0-56f4-4861-b1ad-3c9deec5ffe2	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	3	3	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2436d07e-c88e-46e8-8fa6-9cfac4b44908	677efef0-56f4-4861-b1ad-3c9deec5ffe2	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	5	3	3	Feeling productive and supported	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
fa907b7a-5e92-420f-9759-f648a10f6ddb	677efef0-56f4-4861-b1ad-3c9deec5ffe2	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	3	5	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9081aaf0-7a12-4095-986a-14dde1b6f3eb	677efef0-56f4-4861-b1ad-3c9deec5ffe2	c6686137-146d-43b4-8919-ed25043403c0	3	3	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
747e52f0-fc5d-4991-a7ec-1f9deff6f2b7	677efef0-56f4-4861-b1ad-3c9deec5ffe2	a03cbcf7-960e-4f51-8023-b914b77ea368	3	4	4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6b66fb5a-4b71-4b63-ae8d-7dd1b890396e	677efef0-56f4-4861-b1ad-3c9deec5ffe2	d661e296-5b5e-4b4d-bc00-e9d393137c57	3	3	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
aa222196-3ee9-49ec-a224-6e64e511a926	677efef0-56f4-4861-b1ad-3c9deec5ffe2	e883e8c3-9f3c-4ca2-86ba-49841c392367	4	2	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e541a001-85be-41cb-93ed-b43537a60797	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	a8212044-03bd-4270-bf0a-1f407b2f9111	5	4	5	Feeling productive and supported	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bfe55732-d831-4c91-99f4-69584df90d12	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	a7a276c3-188c-48b6-a508-4d1e2bc24658	4	4	4	Great team atmosphere lately	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
48fae620-0848-432f-a812-420c5d63b2bc	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	d661e296-5b5e-4b4d-bc00-e9d393137c57	4	3	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b107a005-7fb8-42b3-976a-d8aa6bac45ba	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	4	3	4	Great team atmosphere lately	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
06800451-7be4-4d6a-949c-bcd5a462675f	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	476a5fd1-f313-41b0-ae18-9ae79a17d19b	4	2	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4ca3cf7f-031b-42d0-ae9a-6c98301e67e7	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	4	4	5	Feeling productive and supported	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f96efae8-a032-4c51-bcbe-b12aae4c42d1	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	a03cbcf7-960e-4f51-8023-b914b77ea368	3	2	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7da64d83-1469-4056-888e-bd7522e50fb8	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	622ebdf1-e160-4a28-91df-0b7089713829	3	3	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7e59fecd-e774-4936-a829-e33f576e9295	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	3	3	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c3be5233-006d-4525-80f4-26726dcc10d2	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	652f6dd7-4cad-4786-a938-149c19c645b4	3	3	4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
256400c9-dd7a-428e-aedb-a063555fc899	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	7632a93b-0150-48a6-9639-b5f84c824690	3	3	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
52fbb000-0cea-4eaf-8cef-fb6712ba5a0f	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	48c66b25-24b9-4dcf-8454-419266423422	5	4	3	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
33d246d5-740a-47f6-8b34-112b4fe53a9b	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	3	4	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5e4b509c-83d7-47cd-a97d-57262f8b7a0e	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	c6686137-146d-43b4-8919-ed25043403c0	4	3	5	Things are going well, enjoying the current projects	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6e867389-2df6-440c-9448-07fe9f9d4b0d	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	363609f8-48c4-4e82-98c2-a2c7f42e1f46	4	4	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2ad39251-e927-49ee-9cfb-b3521b755cb8	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	4	4	5	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3621821d-d0d2-4796-8f39-ccd926b98c88	6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	e883e8c3-9f3c-4ca2-86ba-49841c392367	5	4	4	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: pulse_surveys; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.pulse_surveys (id, workspace_id, title, status, end_date, created_at, updated_at) FROM stdin;
c1d8cf85-e789-4e5b-a143-5cd1f2ef4c78	57794310-9d2b-47fd-9318-fc704a17709f	January Pulse	closed	2026-01-31	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ad6487a7-8db3-4cb6-80e8-d34d82848562	57794310-9d2b-47fd-9318-fc704a17709f	February Pulse	closed	2026-02-28	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
677efef0-56f4-4861-b1ad-3c9deec5ffe2	57794310-9d2b-47fd-9318-fc704a17709f	March Pulse	closed	2026-03-31	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6d7b64fe-b2b9-4604-bfd1-86ca0f4969ac	57794310-9d2b-47fd-9318-fc704a17709f	April Pulse	active	2026-04-30	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: review_cycles; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.review_cycles (id, workspace_id, name, period_start, period_end, status, created_at, updated_at) FROM stdin;
69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	2026 Annual Review	2026-01-01	2026-06-30	manager_review	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	2025 Annual Review	2025-01-01	2025-12-31	complete	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: review_periods; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.review_periods (id, workspace_id, name, start_date, end_date, created_at, updated_at) FROM stdin;
5acf4864-1579-4d54-a572-94b0a9225996	57794310-9d2b-47fd-9318-fc704a17709f	2026 H1	2026-01-01	2026-06-30	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
576200d2-f0e9-4273-adbe-683d29aececd	57794310-9d2b-47fd-9318-fc704a17709f	2025 H2	2025-07-01	2025-12-31	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.reviews (id, cycle_id, workspace_id, user_id, reviewer_id, self_assessment, manager_assessment, overall_rating, strengths, areas_for_improvement, status, sign_off_date, created_at, updated_at) FROM stdin;
c2099f3c-cdbe-4f01-a539-e0f00ef1ad5d	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	5	Exceptional technical leadership, drives architectural excellence	Could delegate more to develop others	finalised	2026-02-11	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1dadf69a-7a7f-4739-9b70-694f0846b5c0	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	4	Strong coding skills, reliable delivery, good mentor	Needs to improve estimation accuracy	finalised	2026-02-22	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ff8ac148-6b89-46ec-906a-026485268f8e	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Solid backend skills, improving steadily	Should take on more ownership of features	discussed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
88204169-914e-4c71-a950-3bb3d11ac85b	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	4	Outstanding design thinking, elevates team standards	Could be more assertive in stakeholder discussions	finalised	2026-03-01	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f49f5c09-8d91-4141-8a7b-50a43092fe1c	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	\N	\N	\N	manager_draft	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e7e40904-b511-46d3-9e60-1f71978f79fa	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	48c66b25-24b9-4dcf-8454-419266423422	\N	\N	4	Excellent platform engineering, strong K8s skills	Needs better documentation habits	finalised	2026-02-27	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dcc8bd65-0ceb-48d0-975b-a5663e1db5cc	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	29b50239-3ff6-44aa-b8da-d5d67ef0659f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	\N	\N	3	Good UX instincts, growing well	Should develop stronger visual design skills	discussed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1dbfb431-78cf-47ae-8352-ea9953b78e87	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	476a5fd1-f313-41b0-ae18-9ae79a17d19b	7632a93b-0150-48a6-9639-b5f84c824690	\N	\N	\N	\N	\N	self_assessment	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
52ef5c93-066c-4642-9ec2-ccc372ba668d	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	652f6dd7-4cad-4786-a938-149c19c645b4	48c66b25-24b9-4dcf-8454-419266423422	\N	\N	4	Versatile full-stack skills, fast learner	Could improve code review thoroughness	discussed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
eaa3648d-dff9-41e5-936c-4eec63728009	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	48c66b25-24b9-4dcf-8454-419266423422	\N	\N	5	Outstanding DevOps expertise, hero in production incidents	Should share knowledge more proactively	finalised	2026-02-28	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7642666e-70dd-49d7-b8f3-66aba45cc25e	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	\N	\N	\N	\N	\N	self_assessment	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5166baea-4deb-45f4-84bb-049e43cb758b	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	4	Strong product sense, good stakeholder management	Needs to develop data-driven decision making	finalised	2026-02-22	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3705ff17-743c-4196-bda1-809561bf24ba	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	48c66b25-24b9-4dcf-8454-419266423422	\N	\N	\N	\N	\N	manager_draft	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4fc5c336-a137-4753-aeb7-a0fb0caa6411	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	a2633e0c-d058-40da-a843-422fcf15adac	7632a93b-0150-48a6-9639-b5f84c824690	\N	\N	\N	\N	\N	not_started	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
24707df7-ca8d-480a-85c1-fafc758fa0c0	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	a8212044-03bd-4270-bf0a-1f407b2f9111	7a6a5744-371f-4561-90d4-d6b470339606	\N	\N	3	Improving product ownership skills	Needs to develop technical understanding	discussed	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
94b2d696-8fae-438d-8163-3131cd35fe2d	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	5	Exceptional security knowledge, keeps us safe	Could improve presentation skills for non-technical audiences	finalised	2026-02-27	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6930e386-f481-4f83-aa14-deea20870a38	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	a03cbcf7-960e-4f51-8023-b914b77ea368	7a6a5744-371f-4561-90d4-d6b470339606	\N	\N	\N	\N	\N	not_started	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9861159c-4375-47c4-a6c7-0a585280a4ae	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	a7a276c3-188c-48b6-a508-4d1e2bc24658	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	\N	\N	\N	\N	\N	self_assessment	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e5bd9c31-d110-48f5-b75d-89d166609043	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	48c66b25-24b9-4dcf-8454-419266423422	\N	\N	4	Strong data science skills, innovative approaches	Should align work more closely with business outcomes	finalised	2026-02-28	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c0b6d7c6-f1c2-4b35-bade-9100487a5593	69fb3d72-a122-4b87-8174-a81c813ac2b2	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	7632a93b-0150-48a6-9639-b5f84c824690	\N	\N	\N	\N	\N	not_started	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d7f81ce9-61f6-4c2b-8978-9f326f0dc014	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	d661e296-5b5e-4b4d-bc00-e9d393137c57	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2ee76533-336a-4b25-a2d3-2159dfc27555	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	48c66b25-24b9-4dcf-8454-419266423422	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f957aea3-97d0-4481-9444-6d9475996495	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	e883e8c3-9f3c-4ca2-86ba-49841c392367	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f577b4a1-5e94-4d6b-b811-d65e9bd3ecbb	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5ac2da22-8a5e-45f8-8788-1599aca5aad8	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	7632a93b-0150-48a6-9639-b5f84c824690	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6b10d884-6fb8-4081-a6f1-d92e5966997b	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	c6686137-146d-43b4-8919-ed25043403c0	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e45816c1-1a9b-477a-820f-3f63f87c6f39	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	29b50239-3ff6-44aa-b8da-d5d67ef0659f	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3b2f83b6-432f-4220-88f7-c56a09a34e5d	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	476a5fd1-f313-41b0-ae18-9ae79a17d19b	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f4b76d91-d5da-42f5-a71a-769374fb0f7e	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	652f6dd7-4cad-4786-a938-149c19c645b4	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
19e07a4f-40e5-4545-a180-aae5cf793c73	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	363609f8-48c4-4e82-98c2-a2c7f42e1f46	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
16ba01bf-912a-491c-86ec-45abdfedd080	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3b1b3f6c-6088-470d-8d7d-4126d35c854b	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	7a6a5744-371f-4561-90d4-d6b470339606	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
b85c0e88-0e6e-4ede-a05f-850ac888006f	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e1aba094-37f0-486f-a1d6-b76439d288e6	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	a2633e0c-d058-40da-a843-422fcf15adac	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
02297458-6fb8-4475-a62b-36f8e830bd16	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	a8212044-03bd-4270-bf0a-1f407b2f9111	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a6e76f52-adc5-45a7-be61-c9ebb18dd528	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	5	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
96f1b323-ea74-4226-824e-7b37df1e76b0	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	a03cbcf7-960e-4f51-8023-b914b77ea368	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
72e3fcf6-7c44-49b7-a8fb-245c9827f868	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	a7a276c3-188c-48b6-a508-4d1e2bc24658	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9e115d5d-8bbc-47bf-b5ce-d4fb7788a91b	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bc90d773-775f-4a54-ba7d-4235fc0ec758	44167aad-8bba-41f0-b15c-078901accc38	57794310-9d2b-47fd-9318-fc704a17709f	622ebdf1-e160-4a28-91df-0b7089713829	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: rota_entries; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.rota_entries (id, rota_id, user_id, workspace_id, date_from, date_to, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rotas; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.rotas (id, name, rota_type, start_time, end_time, include_weekends, colour, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: segments; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.segments (id, name, sort_order, project_id, created_at, updated_at) FROM stdin;
445c9e2f-33e2-4b4d-a61e-62d2c0464c03	Homepage	0	371652ef-a083-4558-9e6a-cd5dee1b6acf	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5fc50559-c87b-4635-96bb-675156f12c3e	Product Pages	0	371652ef-a083-4558-9e6a-cd5dee1b6acf	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
eeb967cb-e08a-4dc5-b996-a614eddaeb41	Checkout Flow	0	371652ef-a083-4558-9e6a-cd5dee1b6acf	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: shared_timelines; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.shared_timelines (id, workspace_id, token, name, is_active, team_id, project_id, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.tags (id, name, colour, project_id, created_at, updated_at) FROM stdin;
0a3d3fbb-b161-4f91-8dcb-c29742db1475	Frontend	#3B82F6	371652ef-a083-4558-9e6a-cd5dee1b6acf	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d2b75a39-0945-4112-82f5-b14befe06d7c	Backend	#10B981	371652ef-a083-4558-9e6a-cd5dee1b6acf	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
276b63a6-bc6b-4ab2-bda3-23202f145109	Design	#8B5CF6	371652ef-a083-4558-9e6a-cd5dee1b6acf	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
59f1ccfc-927a-4853-961a-9ec7cc19edd8	Bug	#EF4444	371652ef-a083-4558-9e6a-cd5dee1b6acf	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e1bee07a-312c-4f3a-abca-3e30f2d40743	Enhancement	#F59E0B	371652ef-a083-4558-9e6a-cd5dee1b6acf	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
720b20c2-c2a3-453a-9374-9802d04fd665	Documentation	#6B7280	371652ef-a083-4558-9e6a-cd5dee1b6acf	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: task_assignees; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.task_assignees (task_id, user_id) FROM stdin;
413df965-4a6c-4e6e-9096-042830383305	03eb5bd7-dfa2-43c8-b467-38df8133c6f4
51c4d428-333f-4d02-9718-9a3622937432	48c66b25-24b9-4dcf-8454-419266423422
5846e378-e43a-4e9f-9499-8b2071f8dc73	e883e8c3-9f3c-4ca2-86ba-49841c392367
d94d73fc-71b9-458b-bc2c-98e2c8d5c524	c6686137-146d-43b4-8919-ed25043403c0
1f0fdaf2-2cac-45b3-8ad4-c1e4d338b157	652f6dd7-4cad-4786-a938-149c19c645b4
98db9934-5ed2-48cc-9750-4cb3b30d67ab	48c66b25-24b9-4dcf-8454-419266423422
2d0825a1-a297-4009-b5f3-8b9b900dc330	03eb5bd7-dfa2-43c8-b467-38df8133c6f4
a92214a0-38ca-4534-a017-9eab96ede323	363609f8-48c4-4e82-98c2-a2c7f42e1f46
a9ab9f9f-73cd-4c04-b00e-26516d305833	e883e8c3-9f3c-4ca2-86ba-49841c392367
36c27f9a-80b6-4753-9aae-6299ffe9372f	c6686137-146d-43b4-8919-ed25043403c0
f20dd29e-842a-485d-8459-36186bd42f03	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4
dc64e398-0d0d-4b96-b8be-71be29ec1b76	7632a93b-0150-48a6-9639-b5f84c824690
f3b7a637-2702-414d-a14d-ca59bc7fb80a	476a5fd1-f313-41b0-ae18-9ae79a17d19b
075e9831-070b-4872-aa37-fce41beb8429	a2633e0c-d058-40da-a843-422fcf15adac
c28be621-0a94-40de-bc52-36926c96615e	8306db3d-d65b-42d6-8b42-f7f67f7ca7db
8ac81401-9364-4ddc-aa87-1aa8bfc0b9a8	10b1331f-8b66-4fce-a5c2-9d7cfde3678e
1b26398d-15eb-4ca9-9e3f-e75cbf04fa44	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9
19ab3b3c-13e1-4412-8869-528e6e1bfb2c	29b50239-3ff6-44aa-b8da-d5d67ef0659f
\.


--
-- Data for Name: task_dependencies; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.task_dependencies (id, blocker_id, blocked_id, dependency_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_tags; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.task_tags (task_id, tag_id) FROM stdin;
\.


--
-- Data for Name: task_templates; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.task_templates (id, name, description, colour, status, time_estimate_minutes, checklist_items, tag_names, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.tasks (id, name, description, colour, status, status_emoji, date_from, date_to, start_time, end_time, time_estimate_minutes, time_estimate_mode, is_recurring, recurrence_rule, sort_order, project_id, segment_id, workspace_id, created_at, updated_at, parent_id, time_logged_minutes) FROM stdin;
413df965-4a6c-4e6e-9096-042830383305	Design homepage mockup	\N	\N	done	\N	2026-03-02	2026-03-05	\N	\N	\N	total	f	\N	0	371652ef-a083-4558-9e6a-cd5dee1b6acf	445c9e2f-33e2-4b4d-a61e-62d2c0464c03	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
51c4d428-333f-4d02-9718-9a3622937432	Implement responsive header	\N	\N	in_progress	\N	2026-03-04	2026-03-07	\N	\N	\N	total	f	\N	1	371652ef-a083-4558-9e6a-cd5dee1b6acf	445c9e2f-33e2-4b4d-a61e-62d2c0464c03	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
5846e378-e43a-4e9f-9499-8b2071f8dc73	Build product card component	\N	\N	planned	\N	2026-03-06	2026-03-10	\N	\N	\N	total	f	\N	2	371652ef-a083-4558-9e6a-cd5dee1b6acf	5fc50559-c87b-4635-96bb-675156f12c3e	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
d94d73fc-71b9-458b-bc2c-98e2c8d5c524	Checkout form validation	\N	\N	planned	\N	2026-03-09	2026-03-12	\N	\N	\N	total	f	\N	3	371652ef-a083-4558-9e6a-cd5dee1b6acf	eeb967cb-e08a-4dc5-b996-a614eddaeb41	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
1f0fdaf2-2cac-45b3-8ad4-c1e4d338b157	Payment gateway integration	\N	\N	planned	\N	2026-03-12	2026-03-16	\N	\N	\N	total	f	\N	4	371652ef-a083-4558-9e6a-cd5dee1b6acf	eeb967cb-e08a-4dc5-b996-a614eddaeb41	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
98db9934-5ed2-48cc-9750-4cb3b30d67ab	Setup React Native project	\N	\N	done	\N	2026-03-02	2026-03-04	\N	\N	\N	total	f	\N	5	6effa62a-7e17-4c33-b749-4a69ad341e35	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
2d0825a1-a297-4009-b5f3-8b9b900dc330	Auth flow screens	\N	\N	in_progress	\N	2026-03-04	2026-03-08	\N	\N	\N	total	f	\N	6	6effa62a-7e17-4c33-b749-4a69ad341e35	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
a92214a0-38ca-4534-a017-9eab96ede323	Push notification setup	\N	\N	planned	\N	2026-03-07	2026-03-10	\N	\N	\N	total	f	\N	7	6effa62a-7e17-4c33-b749-4a69ad341e35	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
a9ab9f9f-73cd-4c04-b00e-26516d305833	API authentication middleware	\N	\N	done	\N	2026-03-02	2026-03-05	\N	\N	\N	total	f	\N	8	0d645a1e-2e1c-4410-b3bc-5a2e88fe2c33	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
36c27f9a-80b6-4753-9aae-6299ffe9372f	Rate limiting implementation	\N	\N	in_progress	\N	2026-03-05	2026-03-07	\N	\N	\N	total	f	\N	9	0d645a1e-2e1c-4410-b3bc-5a2e88fe2c33	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
f20dd29e-842a-485d-8459-36186bd42f03	OpenAPI documentation	\N	\N	planned	\N	2026-03-07	2026-03-09	\N	\N	\N	total	f	\N	10	0d645a1e-2e1c-4410-b3bc-5a2e88fe2c33	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
dc64e398-0d0d-4b96-b8be-71be29ec1b76	Social media calendar	\N	\N	in_progress	\N	2026-03-03	2026-03-10	\N	\N	\N	total	f	\N	11	c561ac35-916a-4299-92f3-1f3fb4cca3b0	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
f3b7a637-2702-414d-a14d-ca59bc7fb80a	Blog post drafts	\N	\N	planned	\N	2026-03-05	2026-03-12	\N	\N	\N	total	f	\N	12	c561ac35-916a-4299-92f3-1f3fb4cca3b0	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
075e9831-070b-4872-aa37-fce41beb8429	Email campaign setup	\N	\N	planned	\N	2026-03-10	2026-03-16	\N	\N	\N	total	f	\N	13	c561ac35-916a-4299-92f3-1f3fb4cca3b0	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
c28be621-0a94-40de-bc52-36926c96615e	ETL pipeline for analytics	\N	\N	in_progress	\N	2026-03-02	2026-03-09	\N	\N	\N	total	f	\N	14	bf8bc581-8926-4df6-80ce-9b018d7a3499	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
8ac81401-9364-4ddc-aa87-1aa8bfc0b9a8	Dashboard visualisations	\N	\N	planned	\N	2026-03-09	2026-03-16	\N	\N	\N	total	f	\N	15	bf8bc581-8926-4df6-80ce-9b018d7a3499	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
1b26398d-15eb-4ca9-9e3f-e75cbf04fa44	Portal login and SSO	\N	\N	in_progress	\N	2026-03-02	2026-03-07	\N	\N	\N	total	f	\N	16	5bc7deb4-9bca-4203-9dda-247f13eafe5f	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
19ab3b3c-13e1-4412-8869-528e6e1bfb2c	Customer profile page	\N	\N	planned	\N	2026-03-07	2026-03-12	\N	\N	\N	total	f	\N	17	5bc7deb4-9bca-4203-9dda-247f13eafe5f	\N	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	0
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.team_members (team_id, user_id, sort_order) FROM stdin;
b495ec25-cb10-4c85-97a3-9d3f92346c8e	d661e296-5b5e-4b4d-bc00-e9d393137c57	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	48c66b25-24b9-4dcf-8454-419266423422	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	e883e8c3-9f3c-4ca2-86ba-49841c392367	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	7632a93b-0150-48a6-9639-b5f84c824690	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	c6686137-146d-43b4-8919-ed25043403c0	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	29b50239-3ff6-44aa-b8da-d5d67ef0659f	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	476a5fd1-f313-41b0-ae18-9ae79a17d19b	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	652f6dd7-4cad-4786-a938-149c19c645b4	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	363609f8-48c4-4e82-98c2-a2c7f42e1f46	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	7a6a5744-371f-4561-90d4-d6b470339606	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	a2633e0c-d058-40da-a843-422fcf15adac	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	a8212044-03bd-4270-bf0a-1f407b2f9111	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	a03cbcf7-960e-4f51-8023-b914b77ea368	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	a7a276c3-188c-48b6-a508-4d1e2bc24658	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	0
b495ec25-cb10-4c85-97a3-9d3f92346c8e	622ebdf1-e160-4a28-91df-0b7089713829	0
6e4ed861-75c8-4895-968a-6a24fda76ab9	d661e296-5b5e-4b4d-bc00-e9d393137c57	0
6e4ed861-75c8-4895-968a-6a24fda76ab9	48c66b25-24b9-4dcf-8454-419266423422	0
6e4ed861-75c8-4895-968a-6a24fda76ab9	e883e8c3-9f3c-4ca2-86ba-49841c392367	0
6e4ed861-75c8-4895-968a-6a24fda76ab9	c6686137-146d-43b4-8919-ed25043403c0	0
6e4ed861-75c8-4895-968a-6a24fda76ab9	652f6dd7-4cad-4786-a938-149c19c645b4	0
6e4ed861-75c8-4895-968a-6a24fda76ab9	363609f8-48c4-4e82-98c2-a2c7f42e1f46	0
6e4ed861-75c8-4895-968a-6a24fda76ab9	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	0
6e4ed861-75c8-4895-968a-6a24fda76ab9	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	0
a49651cf-d249-49d7-a0f0-91f4b25b2a67	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	0
a49651cf-d249-49d7-a0f0-91f4b25b2a67	29b50239-3ff6-44aa-b8da-d5d67ef0659f	0
a49651cf-d249-49d7-a0f0-91f4b25b2a67	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	0
a49651cf-d249-49d7-a0f0-91f4b25b2a67	a7a276c3-188c-48b6-a508-4d1e2bc24658	0
92951cc0-6793-40ea-81a1-8ec072a89609	7632a93b-0150-48a6-9639-b5f84c824690	0
92951cc0-6793-40ea-81a1-8ec072a89609	476a5fd1-f313-41b0-ae18-9ae79a17d19b	0
92951cc0-6793-40ea-81a1-8ec072a89609	a2633e0c-d058-40da-a843-422fcf15adac	0
92951cc0-6793-40ea-81a1-8ec072a89609	622ebdf1-e160-4a28-91df-0b7089713829	0
cb241b94-c1c2-4ccd-9ef3-8caa7811bf0a	7a6a5744-371f-4561-90d4-d6b470339606	0
cb241b94-c1c2-4ccd-9ef3-8caa7811bf0a	a8212044-03bd-4270-bf0a-1f407b2f9111	0
cb241b94-c1c2-4ccd-9ef3-8caa7811bf0a	a03cbcf7-960e-4f51-8023-b914b77ea368	0
49975af9-8e86-48c0-821b-3c33c9274ae9	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	0
49975af9-8e86-48c0-821b-3c33c9274ae9	363609f8-48c4-4e82-98c2-a2c7f42e1f46	0
49975af9-8e86-48c0-821b-3c33c9274ae9	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	0
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.teams (id, name, is_favourite, workspace_id, created_at, updated_at) FROM stdin;
b495ec25-cb10-4c85-97a3-9d3f92346c8e	Everyone	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6e4ed861-75c8-4895-968a-6a24fda76ab9	Engineering	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a49651cf-d249-49d7-a0f0-91f4b25b2a67	Design	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
92951cc0-6793-40ea-81a1-8ec072a89609	Marketing	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
cb241b94-c1c2-4ccd-9ef3-8caa7811bf0a	Product	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
49975af9-8e86-48c0-821b-3c33c9274ae9	Data & Analytics	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.time_entries (id, workspace_id, task_id, user_id, minutes, description, logged_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: time_off; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.time_off (id, user_id, workspace_id, date_from, date_to, reason, colour, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_competencies; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.user_competencies (id, user_id, competency_id, workspace_id, level, assessed_date, assessed_by, expiry_date, notes, created_at, updated_at) FROM stdin;
40d58f8c-299d-46de-b5a7-87277390396e	d661e296-5b5e-4b4d-bc00-e9d393137c57	955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	expert	2026-01-03	d661e296-5b5e-4b4d-bc00-e9d393137c57	2027-02-22	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f43b4264-5f13-4134-b869-510d769eab97	d661e296-5b5e-4b4d-bc00-e9d393137c57	34e2cc75-dc22-472a-bc69-879c76e3f8c1	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-11-22	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-04-13	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d593c79e-eef3-46ce-a78c-8b73b61c008d	d661e296-5b5e-4b4d-bc00-e9d393137c57	9950caf2-1044-4bb6-885a-25dda4121ff8	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-12-05	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-08-04	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6b65182b-f08c-4ded-891c-aac4679d5bac	d661e296-5b5e-4b4d-bc00-e9d393137c57	b8ec73a3-6fd5-474f-be7d-31f63ec9c136	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-12-27	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3ad3133a-1dca-4fd3-8127-86d18b19552d	d661e296-5b5e-4b4d-bc00-e9d393137c57	ced3643f-06d3-4538-a1f7-3e21f4f27e9e	57794310-9d2b-47fd-9318-fc704a17709f	expert	2026-01-05	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6fd24731-c12f-48e9-a689-384c443a28cf	d661e296-5b5e-4b4d-bc00-e9d393137c57	d77b6743-8cc3-45ad-9a78-e4ff57e95936	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-09-14	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3d01c03f-e914-4018-b3da-481fe821444f	48c66b25-24b9-4dcf-8454-419266423422	955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-10-15	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-05-15	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5f0ccd56-fe85-47f6-841d-a9f29d7c895f	48c66b25-24b9-4dcf-8454-419266423422	20d3d549-692c-4824-b426-ceacf105d2e9	57794310-9d2b-47fd-9318-fc704a17709f	expert	2026-01-23	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c32d106b-0b0b-41a1-be84-fcc3547638a7	48c66b25-24b9-4dcf-8454-419266423422	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2026-01-24	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
17125da0-440f-4a5a-9873-4811d256e88e	48c66b25-24b9-4dcf-8454-419266423422	7ba7e885-2a7d-4736-a32d-640c88390cfd	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2026-01-08	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
eedd3775-9349-48fe-8e5c-d3d7e5ab786d	48c66b25-24b9-4dcf-8454-419266423422	ced3643f-06d3-4538-a1f7-3e21f4f27e9e	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-07	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
052a6ca7-117b-42e2-9033-524664cd3a11	48c66b25-24b9-4dcf-8454-419266423422	911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-03	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
78742494-7797-4963-9a78-614d23fc6ba9	e883e8c3-9f3c-4ca2-86ba-49841c392367	955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	expert	2026-01-25	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-12-15	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
735d547c-7890-4b5f-b9dc-f24f4813d6ef	e883e8c3-9f3c-4ca2-86ba-49841c392367	34e2cc75-dc22-472a-bc69-879c76e3f8c1	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-12	d661e296-5b5e-4b4d-bc00-e9d393137c57	2027-01-13	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f99c220d-2dd2-48e5-9a51-5e22b98a541c	e883e8c3-9f3c-4ca2-86ba-49841c392367	74a0d2c3-bb19-4292-97ed-f58e684151ab	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-09-14	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0677074b-ba9f-4ea2-91ef-16a9ef629924	e883e8c3-9f3c-4ca2-86ba-49841c392367	ced3643f-06d3-4538-a1f7-3e21f4f27e9e	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-10-16	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d1907d1c-758a-47f3-b096-7a4de6d4d6c8	e883e8c3-9f3c-4ca2-86ba-49841c392367	454eb12b-74b9-45ba-ac5e-dd24b3dcc226	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-10-09	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-07-22	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d3445c29-ef34-42bd-ada8-dd8da3962cf7	c6686137-146d-43b4-8919-ed25043403c0	955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-21	d661e296-5b5e-4b4d-bc00-e9d393137c57	2027-01-27	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e15ddef9-e767-40ba-b2ce-413e7b9f57e6	c6686137-146d-43b4-8919-ed25043403c0	454eb12b-74b9-45ba-ac5e-dd24b3dcc226	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-12-22	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-04-04	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
17019094-8821-4397-ad17-0234b3d2cbce	c6686137-146d-43b4-8919-ed25043403c0	7ba7e885-2a7d-4736-a32d-640c88390cfd	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-10-15	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
0b48cc55-9cd2-4457-b13f-9abd59a2873c	c6686137-146d-43b4-8919-ed25043403c0	34e2cc75-dc22-472a-bc69-879c76e3f8c1	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-21	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-09-22	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3808b44c-3840-48d5-a32f-3ecdc5b3b730	c6686137-146d-43b4-8919-ed25043403c0	ced3643f-06d3-4538-a1f7-3e21f4f27e9e	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-23	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
59bc54d0-3bd6-43eb-8942-3e425346c2cb	652f6dd7-4cad-4786-a938-149c19c645b4	955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-06	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-07-20	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a843252b-2727-4266-9f6f-29bdb00bb432	652f6dd7-4cad-4786-a938-149c19c645b4	20d3d549-692c-4824-b426-ceacf105d2e9	57794310-9d2b-47fd-9318-fc704a17709f	expert	2026-01-05	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1cf12245-65af-446f-a90f-1be29c7cb472	652f6dd7-4cad-4786-a938-149c19c645b4	34e2cc75-dc22-472a-bc69-879c76e3f8c1	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-10-26	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-05-18	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
19017c54-1949-4cf8-a9e6-4e05476029b7	652f6dd7-4cad-4786-a938-149c19c645b4	7ba7e885-2a7d-4736-a32d-640c88390cfd	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2026-01-07	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3b72973c-413a-4e98-88ec-04b3523ed656	652f6dd7-4cad-4786-a938-149c19c645b4	ced3643f-06d3-4538-a1f7-3e21f4f27e9e	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-01	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
274b8efc-e667-4406-bcf0-2476d6e8a59a	363609f8-48c4-4e82-98c2-a2c7f42e1f46	955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-11-25	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-09-24	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
60f5e128-1a09-444e-ad1c-f34cf2885e13	363609f8-48c4-4e82-98c2-a2c7f42e1f46	34e2cc75-dc22-472a-bc69-879c76e3f8c1	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-10-06	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-04-23	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
3eff82a3-8082-4841-b684-a320410fcd97	363609f8-48c4-4e82-98c2-a2c7f42e1f46	454eb12b-74b9-45ba-ac5e-dd24b3dcc226	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-12-31	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-12-31	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1eb0ba1f-b068-4d2b-bea2-63d657bb53c0	363609f8-48c4-4e82-98c2-a2c7f42e1f46	7ba7e885-2a7d-4736-a32d-640c88390cfd	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-10-27	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
2e068bb8-4ad5-4ca9-b1b3-0459ab2ab8d0	363609f8-48c4-4e82-98c2-a2c7f42e1f46	ced3643f-06d3-4538-a1f7-3e21f4f27e9e	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2026-01-11	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a43a8657-36ab-4ce5-a7aa-9f47e6b5f95e	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-11-17	d661e296-5b5e-4b4d-bc00-e9d393137c57	2027-01-08	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
65303421-8333-45be-a3dd-3ae635063b36	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	74a0d2c3-bb19-4292-97ed-f58e684151ab	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-10-31	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
406d6e04-0a8a-4779-9cd6-4ae189c434fd	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	ced3643f-06d3-4538-a1f7-3e21f4f27e9e	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-09-06	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
35b53234-37f8-4cb9-a4da-62e6ef1a9b63	f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	74a1af7c-309d-4893-979c-f6429036e961	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2026-01-14	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-07-08	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
21c20942-cc5d-4190-8860-741cc49c9178	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-04	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-04-24	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e57e6ff0-3bbb-4dfc-a957-964d70952ae7	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	9950caf2-1044-4bb6-885a-25dda4121ff8	57794310-9d2b-47fd-9318-fc704a17709f	expert	2026-01-11	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-08-27	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c17043fa-0e3f-427e-9ca1-38f90156f8e5	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	34e2cc75-dc22-472a-bc69-879c76e3f8c1	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2026-01-06	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-07-29	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
ed0c68a1-cd41-48c1-ba65-23586264905c	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	454eb12b-74b9-45ba-ac5e-dd24b3dcc226	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-21	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-10-12	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
36a01def-85b9-4f54-961c-88f59a53a2ac	c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	7ba7e885-2a7d-4736-a32d-640c88390cfd	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-10-07	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
752fb864-ec30-4fc9-9370-858399836452	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	955c4f33-9637-4424-b719-b50d256f9256	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-10-30	d661e296-5b5e-4b4d-bc00-e9d393137c57	2027-02-20	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
36a28142-f4a3-415f-99c7-88b2521738f9	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	74a0d2c3-bb19-4292-97ed-f58e684151ab	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-12-21	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6fbd8cda-ab80-47ca-ba49-da8ba1d5f46e	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	74a1af7c-309d-4893-979c-f6429036e961	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-11-02	d661e296-5b5e-4b4d-bc00-e9d393137c57	2026-10-07	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
edc908ff-a080-4d78-b0bc-eaed30fd18e5	8306db3d-d65b-42d6-8b42-f7f67f7ca7db	ced3643f-06d3-4538-a1f7-3e21f4f27e9e	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-09	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
221e44fd-d3c9-4eb8-a283-548338d04d69	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	20d3d549-692c-4824-b426-ceacf105d2e9	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-11-24	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
7e77f622-f18a-4689-bdb9-2187e94fc037	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	5d22b22c-a0b8-498d-9749-a43e00f6911b	57794310-9d2b-47fd-9318-fc704a17709f	expert	2026-01-13	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
12a59576-303d-4a1e-8316-75c05c3aefbf	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-12-19	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
26b81f5d-77dc-4008-93b0-e12693d3332f	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	d77b6743-8cc3-45ad-9a78-e4ff57e95936	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-09-17	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
765d09e0-1745-4810-ab30-192bf98acf4c	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	edd58325-3641-4b5b-b87b-1daff314eafe	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-30	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d4f84aea-d7d4-4c6e-b9be-e5e1eea449a3	03eb5bd7-dfa2-43c8-b467-38df8133c6f4	b8ec73a3-6fd5-474f-be7d-31f63ec9c136	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-21	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e9fd098e-46cf-4660-b309-cce40113724c	29b50239-3ff6-44aa-b8da-d5d67ef0659f	20d3d549-692c-4824-b426-ceacf105d2e9	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-10-05	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
32d52ae7-9ba7-4d97-902d-142636106296	29b50239-3ff6-44aa-b8da-d5d67ef0659f	5d22b22c-a0b8-498d-9749-a43e00f6911b	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-10-26	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
503d224f-dae3-41d3-a3d2-78109fa0fc66	29b50239-3ff6-44aa-b8da-d5d67ef0659f	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-23	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d8badbf5-15a6-494f-b038-2c8dd3f61fd2	29b50239-3ff6-44aa-b8da-d5d67ef0659f	911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-09-11	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f6c2de66-17e2-4dc3-bcd3-40a31bb76ca7	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	20d3d549-692c-4824-b426-ceacf105d2e9	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-06	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dfa31b2a-55b0-4bf0-a4a8-15e52f93c80c	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	5d22b22c-a0b8-498d-9749-a43e00f6911b	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-09	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
c18551d2-ee67-407f-8de2-38ee88439531	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2026-01-17	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
bb249e2d-ce54-42e6-9f8c-7cb4a9b76ecc	10b1331f-8b66-4fce-a5c2-9d7cfde3678e	911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-04	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a29bc2b2-a74c-4af7-9bf1-14e748ccc4b3	a7a276c3-188c-48b6-a508-4d1e2bc24658	20d3d549-692c-4824-b426-ceacf105d2e9	57794310-9d2b-47fd-9318-fc704a17709f	expert	2026-01-23	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
fdcb3e00-eb21-4e7d-b075-1c2f7c939616	a7a276c3-188c-48b6-a508-4d1e2bc24658	5d22b22c-a0b8-498d-9749-a43e00f6911b	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-12	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
dc29457f-32e4-4e0c-9b76-8006cd1601de	a7a276c3-188c-48b6-a508-4d1e2bc24658	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-10-21	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d8bfb10e-b121-4dd8-bad2-13a208cfed3a	7632a93b-0150-48a6-9639-b5f84c824690	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-11-24	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8c89601c-ca6a-44aa-92db-a9940b97ba8c	7632a93b-0150-48a6-9639-b5f84c824690	edd58325-3641-4b5b-b87b-1daff314eafe	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2026-01-15	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e31a1b87-c0d9-43a0-a74a-a428dd827012	7632a93b-0150-48a6-9639-b5f84c824690	74a0d2c3-bb19-4292-97ed-f58e684151ab	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-08	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
546ceb9c-ca58-45d9-8394-8ba221a0bbec	7632a93b-0150-48a6-9639-b5f84c824690	d77b6743-8cc3-45ad-9a78-e4ff57e95936	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-09-08	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9bba0ecf-bd82-492b-882d-18b4243a1506	7632a93b-0150-48a6-9639-b5f84c824690	b8ec73a3-6fd5-474f-be7d-31f63ec9c136	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-11-12	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
f11010ca-8d78-4ef8-b963-51db7e6334bc	476a5fd1-f313-41b0-ae18-9ae79a17d19b	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-12-08	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
e47a38fa-9291-410f-b697-3f22f4d6b3bc	476a5fd1-f313-41b0-ae18-9ae79a17d19b	d77b6743-8cc3-45ad-9a78-e4ff57e95936	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-09-26	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
4d511914-f70a-46ee-9056-e703134e5246	476a5fd1-f313-41b0-ae18-9ae79a17d19b	911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-10-22	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
db65d17f-ba7d-412b-b370-362b9116f845	a2633e0c-d058-40da-a843-422fcf15adac	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-10-06	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
66674d95-1cbc-4f8f-b781-48b02d229ca8	a2633e0c-d058-40da-a843-422fcf15adac	74a0d2c3-bb19-4292-97ed-f58e684151ab	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-12-26	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
95e2b130-8c73-4d60-91ca-29aa24cb6a6d	a2633e0c-d058-40da-a843-422fcf15adac	911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-11-25	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1e508a13-84cb-42eb-9f76-f815a903b02a	622ebdf1-e160-4a28-91df-0b7089713829	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-12-27	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
8c634021-82a4-4e25-8dbe-92c35f3b84b3	622ebdf1-e160-4a28-91df-0b7089713829	911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-11-29	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
aaef624c-2e96-443c-b325-aa46eff51fee	7a6a5744-371f-4561-90d4-d6b470339606	edd58325-3641-4b5b-b87b-1daff314eafe	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-09-10	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
d67a5249-afdc-437f-a35b-885548bfbbfa	7a6a5744-371f-4561-90d4-d6b470339606	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-09-16	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
407fa584-397d-4bb8-9ac9-366907eea3f4	7a6a5744-371f-4561-90d4-d6b470339606	911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-11-25	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9936f6f6-3871-4b9b-becc-51ca13a9a886	7a6a5744-371f-4561-90d4-d6b470339606	d77b6743-8cc3-45ad-9a78-e4ff57e95936	57794310-9d2b-47fd-9318-fc704a17709f	expert	2025-09-04	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
a1146fa1-946f-4be0-9068-e36c05eca149	7a6a5744-371f-4561-90d4-d6b470339606	b8ec73a3-6fd5-474f-be7d-31f63ec9c136	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-10-14	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
6c6a9e51-f29b-4c13-b5b5-e13b2e04d35f	a8212044-03bd-4270-bf0a-1f407b2f9111	edd58325-3641-4b5b-b87b-1daff314eafe	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-09-04	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9e2964eb-fb03-49c3-aa0f-7242451ddc69	a8212044-03bd-4270-bf0a-1f407b2f9111	911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-10-21	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
adda7bae-b913-4bec-9f82-e0d053d7712f	a8212044-03bd-4270-bf0a-1f407b2f9111	d77b6743-8cc3-45ad-9a78-e4ff57e95936	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-10-31	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
5fb211da-0800-4a92-8113-7cba73a99e64	a8212044-03bd-4270-bf0a-1f407b2f9111	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	practitioner	2025-12-06	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
9869d4bd-6824-4857-8d7f-089e6787ddb5	a03cbcf7-960e-4f51-8023-b914b77ea368	74a0d2c3-bb19-4292-97ed-f58e684151ab	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-12-27	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
aeaaa8fd-1723-4dfd-9c8e-658d0e178fd4	a03cbcf7-960e-4f51-8023-b914b77ea368	911061d9-3138-4cc4-bf41-9f550aa69506	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-09-23	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
1fd9883d-241b-4a53-aaf5-3e2579350f0b	a03cbcf7-960e-4f51-8023-b914b77ea368	95eb7438-ae8d-4dd2-8f9f-882548f3f700	57794310-9d2b-47fd-9318-fc704a17709f	awareness	2025-09-27	d661e296-5b5e-4b4d-bc00-e9d393137c57	\N	\N	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.users (id, name, email, password_hash, initials, colour, avatar_url, role, pin_on_top, workspace_id, created_at, updated_at, notification_prefs, totp_secret, totp_enabled, oidc_sub, oidc_issuer, auth_provider) FROM stdin;
d661e296-5b5e-4b4d-bc00-e9d393137c57	Bill Sherwood	billforrestuk@gmail.com	$2b$12$ls5XHAfx2maSArjegRosXOyDukIFa0wO9odxR9/BdOz/2d4EsvkEi	BS	#4186E0	\N	owner	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
48c66b25-24b9-4dcf-8454-419266423422	Bob Smith	bob@acme.com	$2b$12$JutbvmRaDSUwpS5KTHSWNuD0x4F/S6zXHYK7nW1Zx2GDAD6voroPe	BS	#E44332	\N	admin	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
e883e8c3-9f3c-4ca2-86ba-49841c392367	Charlie Brown	charlie@acme.com	$2b$12$0/ng9Gn7Rbt7XK5LmIW8Quy2UOf6s9bO6D7K/HeTAfmfNoNAU8CEW	CB	#5CBF4D	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
03eb5bd7-dfa2-43c8-b467-38df8133c6f4	Diana Prince	diana@acme.com	$2b$12$oN6j1cdn6GUuJb.0dh29xekQ9bybpNIJKgttx0/hDSepEE/R5KXay	DP	#9B59B6	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
7632a93b-0150-48a6-9639-b5f84c824690	Eve Davis	eve@acme.com	$2b$12$poA/r/QBtKtR4lgoxluXsO.LvcCLDrRhHESNQpKGYT69/I8EZ93Eu	ED	#F0C239	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
c6686137-146d-43b4-8919-ed25043403c0	Frank Wilson	frank@acme.com	$2b$12$TQre3d45u0s7x4NgSfAnnuVFSlct1R4uE8IKy7duNsRKcR73jyCeS	FW	#1ABC9C	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
29b50239-3ff6-44aa-b8da-d5d67ef0659f	Grace Lee	grace@acme.com	$2b$12$/htwrvPV88V15edOA/AO3.vIcPjFQZpTELUa4JVjx.kwi59bxLWOG	GL	#E67E22	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
476a5fd1-f313-41b0-ae18-9ae79a17d19b	Henry Taylor	henry@acme.com	$2b$12$75xISvjy9/d6ZfPUHk1XTukvo0/YDtinu.l1v3D46gLhm.mOVWy8a	HT	#3498DB	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
652f6dd7-4cad-4786-a938-149c19c645b4	Ivy Chen	ivy@acme.com	$2b$12$fT4HyojO4bMJ5ejLhIXHAOn0plxo29dodIqBauiabC6YbVW6LnrBS	IC	#E74C3C	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
363609f8-48c4-4e82-98c2-a2c7f42e1f46	Jack Morgan	jack@acme.com	$2b$12$SuRseJCf0sXFfSzUt1wthuz.dfFEaMrDkhCJRNhzkDAsgCo70SC7e	JM	#2ECC71	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
10b1331f-8b66-4fce-a5c2-9d7cfde3678e	Karen Patel	karen@acme.com	$2b$12$yWHf158OKuvfcEeg33xY4.UZIZps3ze/2H8RIj9VhZ3TWa.SP8cMG	KP	#F39C12	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
7a6a5744-371f-4561-90d4-d6b470339606	Liam O'Brien	liam@acme.com	$2b$12$vRNzfDf2UtSfzyf7sk0Xve.NfApb89kQG8YW4RWkopVvqGP39Ikbq	LO	#8E44AD	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
f98546a7-e1c4-44d1-8c61-e207b7a8a7d4	Mia Thompson	mia@acme.com	$2b$12$etJk8NeINIJ07glyeujAxumXaqXIKLrA7GycXL3WJuDtstZjZa7N2	MT	#16A085	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
a2633e0c-d058-40da-a843-422fcf15adac	Noah Garcia	noah@acme.com	$2b$12$qEZD3wMy5XG/rRKCyspcU.vn2wyJ4WXIyh0MIWxg3KeSFyWjnLzPW	NG	#D35400	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
a8212044-03bd-4270-bf0a-1f407b2f9111	Olivia Hughes	olivia@acme.com	$2b$12$ojJT1i6Pb6o9fgAXtBuGTOb65/93.un6VWiMQNruo6Uu5ONZyo7Ae	OH	#2980B9	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
c61e05c1-5fcc-4f3d-a883-ceadb5b981e9	Pete Robinson	pete@acme.com	$2b$12$bs2JhR2Xl9zsvp20Ez3Vf.dtwF3hpRRMYSZcX0PfoHiOrTLsMN2.u	PR	#27AE60	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
a03cbcf7-960e-4f51-8023-b914b77ea368	Quinn Foster	quinn@acme.com	$2b$12$0b6GK1D/eom1Rbg/1pRQlO6OCfGaDRqaAHnOiC4eXDogID.OpGJ3m	QF	#C0392B	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
a7a276c3-188c-48b6-a508-4d1e2bc24658	Rachel Kim	rachel@acme.com	$2b$12$rI1rendri.ZxvQUEkU6AY.Jh4jYz6NOq3kxIvjsWk34PBmdReTAT.	RK	#7D3C98	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
8306db3d-d65b-42d6-8b42-f7f67f7ca7db	Sam Martinez	sam@acme.com	$2b$12$lncmG6hOF7FQrRhikMuhXuR2pxMMxO1l6AY4STLkN1gRKhseQnpxO	SM	#148F77	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
622ebdf1-e160-4a28-91df-0b7089713829	Tanya Novak	tanya@acme.com	$2b$12$i604bhgIxgoQghNbO.jJjOE426JkhP8.h2Djtd2N/Q5z7EyZlaKY6	TN	#D68910	\N	regular	f	57794310-9d2b-47fd-9318-fc704a17709f	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	\N	\N	f	\N	\N	password
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.webhook_logs (id, event, payload, response_status, response_body, success, webhook_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.webhooks (id, name, url, secret, events, is_active, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.workspaces (id, name, created_at, updated_at, enabled_modules) FROM stdin;
57794310-9d2b-47fd-9318-fc704a17709f	Acme Corp	2026-03-02 10:12:09.430964+00	2026-03-02 10:12:09.430964+00	{}
\.


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_messages ai_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_sessions ai_chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: analysis_reports analysis_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.analysis_reports
    ADD CONSTRAINT analysis_reports_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: candidate_events candidate_events_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidate_events
    ADD CONSTRAINT candidate_events_pkey PRIMARY KEY (id);


--
-- Name: candidates candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidates
    ADD CONSTRAINT candidates_pkey PRIMARY KEY (id);


--
-- Name: career_pathways career_pathways_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.career_pathways
    ADD CONSTRAINT career_pathways_pkey PRIMARY KEY (id);


--
-- Name: checklists checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.checklists
    ADD CONSTRAINT checklists_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: competencies competencies_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.competencies
    ADD CONSTRAINT competencies_pkey PRIMARY KEY (id);


--
-- Name: compliance_items compliance_items_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.compliance_items
    ADD CONSTRAINT compliance_items_pkey PRIMARY KEY (id);


--
-- Name: custom_field_values custom_field_values_field_id_task_id_key; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_field_id_task_id_key UNIQUE (field_id, task_id);


--
-- Name: custom_field_values custom_field_values_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: development_checkpoints development_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_checkpoints
    ADD CONSTRAINT development_checkpoints_pkey PRIMARY KEY (id);


--
-- Name: development_goals development_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_goals
    ADD CONSTRAINT development_goals_pkey PRIMARY KEY (id);


--
-- Name: development_milestones development_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_milestones
    ADD CONSTRAINT development_milestones_pkey PRIMARY KEY (id);


--
-- Name: development_plans development_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_plans
    ADD CONSTRAINT development_plans_pkey PRIMARY KEY (id);


--
-- Name: early_talent_cohorts early_talent_cohorts_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_cohorts
    ADD CONSTRAINT early_talent_cohorts_pkey PRIMARY KEY (id);


--
-- Name: early_talent_milestones early_talent_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_milestones
    ADD CONSTRAINT early_talent_milestones_pkey PRIMARY KEY (id);


--
-- Name: early_talent_participants early_talent_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_participants
    ADD CONSTRAINT early_talent_participants_pkey PRIMARY KEY (id);


--
-- Name: early_talent_programmes early_talent_programmes_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_programmes
    ADD CONSTRAINT early_talent_programmes_pkey PRIMARY KEY (id);


--
-- Name: early_talent_rotation_assignments early_talent_rotation_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_rotation_assignments
    ADD CONSTRAINT early_talent_rotation_assignments_pkey PRIMARY KEY (id);


--
-- Name: early_talent_rotations early_talent_rotations_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_rotations
    ADD CONSTRAINT early_talent_rotations_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: key_results key_results_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.key_results
    ADD CONSTRAINT key_results_pkey PRIMARY KEY (id);


--
-- Name: kudos kudos_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.kudos
    ADD CONSTRAINT kudos_pkey PRIMARY KEY (id);


--
-- Name: leave_allowances leave_allowances_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_allowances
    ADD CONSTRAINT leave_allowances_pkey PRIMARY KEY (id);


--
-- Name: leave_requests leave_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_pkey PRIMARY KEY (id);


--
-- Name: lookup_values lookup_values_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.lookup_values
    ADD CONSTRAINT lookup_values_pkey PRIMARY KEY (id);


--
-- Name: meeting_actions meeting_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_pkey PRIMARY KEY (id);


--
-- Name: meetings meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: objectives objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_pkey PRIMARY KEY (id);


--
-- Name: onboarding_checklist_items onboarding_checklist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklist_items
    ADD CONSTRAINT onboarding_checklist_items_pkey PRIMARY KEY (id);


--
-- Name: onboarding_checklists onboarding_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_pkey PRIMARY KEY (id);


--
-- Name: onboarding_template_items onboarding_template_items_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_template_items
    ADD CONSTRAINT onboarding_template_items_pkey PRIMARY KEY (id);


--
-- Name: onboarding_templates onboarding_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_templates
    ADD CONSTRAINT onboarding_templates_pkey PRIMARY KEY (id);


--
-- Name: person_documents person_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_documents
    ADD CONSTRAINT person_documents_pkey PRIMARY KEY (id);


--
-- Name: person_profiles person_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_pkey PRIMARY KEY (id);


--
-- Name: person_profiles person_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_user_id_key UNIQUE (user_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: pulse_responses pulse_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_responses
    ADD CONSTRAINT pulse_responses_pkey PRIMARY KEY (id);


--
-- Name: pulse_surveys pulse_surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_surveys
    ADD CONSTRAINT pulse_surveys_pkey PRIMARY KEY (id);


--
-- Name: review_cycles review_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.review_cycles
    ADD CONSTRAINT review_cycles_pkey PRIMARY KEY (id);


--
-- Name: review_periods review_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.review_periods
    ADD CONSTRAINT review_periods_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: rota_entries rota_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rota_entries
    ADD CONSTRAINT rota_entries_pkey PRIMARY KEY (id);


--
-- Name: rotas rotas_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rotas
    ADD CONSTRAINT rotas_pkey PRIMARY KEY (id);


--
-- Name: segments segments_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.segments
    ADD CONSTRAINT segments_pkey PRIMARY KEY (id);


--
-- Name: shared_timelines shared_timelines_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.shared_timelines
    ADD CONSTRAINT shared_timelines_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: task_assignees task_assignees_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_assignees
    ADD CONSTRAINT task_assignees_pkey PRIMARY KEY (task_id, user_id);


--
-- Name: task_dependencies task_dependencies_blocker_id_blocked_id_key; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_blocker_id_blocked_id_key UNIQUE (blocker_id, blocked_id);


--
-- Name: task_dependencies task_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_pkey PRIMARY KEY (id);


--
-- Name: task_tags task_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_pkey PRIMARY KEY (task_id, tag_id);


--
-- Name: task_templates task_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_templates
    ADD CONSTRAINT task_templates_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (team_id, user_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: time_off time_off_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_off
    ADD CONSTRAINT time_off_pkey PRIMARY KEY (id);


--
-- Name: lookup_values uq_lookup_ws_cat_val; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.lookup_values
    ADD CONSTRAINT uq_lookup_ws_cat_val UNIQUE (workspace_id, category, value);


--
-- Name: user_competencies user_competencies_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: ix_activity_workspace_created; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_activity_workspace_created ON public.activities USING btree (workspace_id, created_at);


--
-- Name: ix_ai_chat_messages_session_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_ai_chat_messages_session_id ON public.ai_chat_messages USING btree (session_id);


--
-- Name: ix_ai_chat_sessions_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_ai_chat_sessions_user_id ON public.ai_chat_sessions USING btree (user_id);


--
-- Name: ix_ai_chat_sessions_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_ai_chat_sessions_workspace_id ON public.ai_chat_sessions USING btree (workspace_id);


--
-- Name: ix_analysis_reports_report_type; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_analysis_reports_report_type ON public.analysis_reports USING btree (report_type);


--
-- Name: ix_analysis_reports_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_analysis_reports_user_id ON public.analysis_reports USING btree (user_id);


--
-- Name: ix_analysis_reports_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_analysis_reports_workspace_id ON public.analysis_reports USING btree (workspace_id);


--
-- Name: ix_attachment_task; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_attachment_task ON public.attachments USING btree (task_id);


--
-- Name: ix_candidates_status; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_candidates_status ON public.candidates USING btree (status);


--
-- Name: ix_candidates_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_candidates_workspace_id ON public.candidates USING btree (workspace_id);


--
-- Name: ix_career_pathways_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_career_pathways_workspace_id ON public.career_pathways USING btree (workspace_id);


--
-- Name: ix_checklist_task_sort; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_checklist_task_sort ON public.checklists USING btree (task_id, sort_order);


--
-- Name: ix_comment_task_created; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_comment_task_created ON public.comments USING btree (task_id, created_at);


--
-- Name: ix_compliance_items_expiry; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_compliance_items_expiry ON public.compliance_items USING btree (expiry_date);


--
-- Name: ix_compliance_items_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_compliance_items_user_id ON public.compliance_items USING btree (user_id);


--
-- Name: ix_development_checkpoints_plan_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_development_checkpoints_plan_id ON public.development_checkpoints USING btree (plan_id);


--
-- Name: ix_development_milestones_plan_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_development_milestones_plan_id ON public.development_milestones USING btree (plan_id);


--
-- Name: ix_early_talent_cohorts_programme_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_early_talent_cohorts_programme_id ON public.early_talent_cohorts USING btree (programme_id);


--
-- Name: ix_early_talent_milestones_participant_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_early_talent_milestones_participant_id ON public.early_talent_milestones USING btree (participant_id);


--
-- Name: ix_early_talent_participants_programme_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_early_talent_participants_programme_id ON public.early_talent_participants USING btree (programme_id);


--
-- Name: ix_early_talent_participants_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_early_talent_participants_workspace_id ON public.early_talent_participants USING btree (workspace_id);


--
-- Name: ix_early_talent_programmes_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_early_talent_programmes_workspace_id ON public.early_talent_programmes USING btree (workspace_id);


--
-- Name: ix_early_talent_rotation_assignments_participant_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_early_talent_rotation_assignments_participant_id ON public.early_talent_rotation_assignments USING btree (participant_id);


--
-- Name: ix_early_talent_rotations_programme_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_early_talent_rotations_programme_id ON public.early_talent_rotations USING btree (programme_id);


--
-- Name: ix_feedback_ws_status; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_feedback_ws_status ON public.feedback USING btree (workspace_id, status);


--
-- Name: ix_feedback_ws_type; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_feedback_ws_type ON public.feedback USING btree (workspace_id, type);


--
-- Name: ix_leave_allowances_user_year; Type: INDEX; Schema: public; Owner: planview
--

CREATE UNIQUE INDEX ix_leave_allowances_user_year ON public.leave_allowances USING btree (user_id, year);


--
-- Name: ix_leave_requests_dates; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_leave_requests_dates ON public.leave_requests USING btree (start_date, end_date);


--
-- Name: ix_leave_requests_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_leave_requests_user_id ON public.leave_requests USING btree (user_id);


--
-- Name: ix_lookup_values_ws_cat; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_lookup_values_ws_cat ON public.lookup_values USING btree (workspace_id, category);


--
-- Name: ix_meeting_actions_meeting_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_meeting_actions_meeting_id ON public.meeting_actions USING btree (meeting_id);


--
-- Name: ix_meetings_manager_report; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_meetings_manager_report ON public.meetings USING btree (manager_id, report_id);


--
-- Name: ix_meetings_scheduled_date; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_meetings_scheduled_date ON public.meetings USING btree (scheduled_date);


--
-- Name: ix_meetings_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_meetings_workspace_id ON public.meetings USING btree (workspace_id);


--
-- Name: ix_notification_user_unread; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_notification_user_unread ON public.notifications USING btree (user_id, workspace_id, is_read, created_at);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_notifications_workspace_user; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_notifications_workspace_user ON public.notifications USING btree (workspace_id, user_id, is_read);


--
-- Name: ix_objectives_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_objectives_user_id ON public.objectives USING btree (user_id);


--
-- Name: ix_objectives_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_objectives_workspace_id ON public.objectives USING btree (workspace_id);


--
-- Name: ix_person_documents_document_type; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_documents_document_type ON public.person_documents USING btree (document_type);


--
-- Name: ix_person_documents_expiry_date; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_documents_expiry_date ON public.person_documents USING btree (expiry_date);


--
-- Name: ix_person_documents_profile_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_documents_profile_id ON public.person_documents USING btree (profile_id);


--
-- Name: ix_person_documents_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_documents_workspace_id ON public.person_documents USING btree (workspace_id);


--
-- Name: ix_person_profiles_department; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_profiles_department ON public.person_profiles USING btree (department);


--
-- Name: ix_person_profiles_manager_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_profiles_manager_id ON public.person_profiles USING btree (manager_id);


--
-- Name: ix_person_profiles_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_profiles_workspace_id ON public.person_profiles USING btree (workspace_id);


--
-- Name: ix_project_workspace; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_project_workspace ON public.projects USING btree (workspace_id);


--
-- Name: ix_rota_entries_dates; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_rota_entries_dates ON public.rota_entries USING btree (date_from, date_to);


--
-- Name: ix_rota_entries_rota_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_rota_entries_rota_id ON public.rota_entries USING btree (rota_id);


--
-- Name: ix_rota_entries_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_rota_entries_user_id ON public.rota_entries USING btree (user_id);


--
-- Name: ix_rotas_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_rotas_workspace_id ON public.rotas USING btree (workspace_id);


--
-- Name: ix_segment_project; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_segment_project ON public.segments USING btree (project_id);


--
-- Name: ix_shared_timelines_token; Type: INDEX; Schema: public; Owner: planview
--

CREATE UNIQUE INDEX ix_shared_timelines_token ON public.shared_timelines USING btree (token);


--
-- Name: ix_tag_project; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_tag_project ON public.tags USING btree (project_id);


--
-- Name: ix_task_assignees_user_task; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_assignees_user_task ON public.task_assignees USING btree (user_id, task_id);


--
-- Name: ix_task_parent_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_parent_id ON public.tasks USING btree (parent_id);


--
-- Name: ix_task_project_status; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_project_status ON public.tasks USING btree (project_id, status);


--
-- Name: ix_task_recurring; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_recurring ON public.tasks USING btree (workspace_id) WHERE (is_recurring = true);


--
-- Name: ix_task_sort_order; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_sort_order ON public.tasks USING btree (project_id, sort_order);


--
-- Name: ix_task_workspace_dates; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_workspace_dates ON public.tasks USING btree (workspace_id, date_from, date_to);


--
-- Name: ix_task_workspace_status; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_workspace_status ON public.tasks USING btree (workspace_id, status);


--
-- Name: ix_taskdep_blocked; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_taskdep_blocked ON public.task_dependencies USING btree (blocked_id);


--
-- Name: ix_taskdep_blocker; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_taskdep_blocker ON public.task_dependencies USING btree (blocker_id);


--
-- Name: ix_team_members_team_user; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_team_members_team_user ON public.team_members USING btree (team_id, user_id);


--
-- Name: ix_time_entries_logged_at; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_time_entries_logged_at ON public.time_entries USING btree (workspace_id, logged_at);


--
-- Name: ix_time_entries_task; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_time_entries_task ON public.time_entries USING btree (task_id);


--
-- Name: ix_time_entries_user; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_time_entries_user ON public.time_entries USING btree (user_id);


--
-- Name: ix_time_entries_workspace; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_time_entries_workspace ON public.time_entries USING btree (workspace_id);


--
-- Name: ix_time_off_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_time_off_user_id ON public.time_off USING btree (user_id);


--
-- Name: ix_user_competencies_competency_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_user_competencies_competency_id ON public.user_competencies USING btree (competency_id);


--
-- Name: ix_user_competencies_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_user_competencies_user_id ON public.user_competencies USING btree (user_id);


--
-- Name: ix_user_email; Type: INDEX; Schema: public; Owner: planview
--

CREATE UNIQUE INDEX ix_user_email ON public.users USING btree (email);


--
-- Name: ix_user_workspace; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_user_workspace ON public.users USING btree (workspace_id);


--
-- Name: ix_users_oidc_sub; Type: INDEX; Schema: public; Owner: planview
--

CREATE UNIQUE INDEX ix_users_oidc_sub ON public.users USING btree (oidc_sub) WHERE (oidc_sub IS NOT NULL);


--
-- Name: activities activities_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: activities activities_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: ai_chat_messages ai_chat_messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.ai_chat_sessions(id) ON DELETE CASCADE;


--
-- Name: ai_chat_sessions ai_chat_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_chat_sessions ai_chat_sessions_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: analysis_reports analysis_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.analysis_reports
    ADD CONSTRAINT analysis_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: analysis_reports analysis_reports_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.analysis_reports
    ADD CONSTRAINT analysis_reports_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: candidate_events candidate_events_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidate_events
    ADD CONSTRAINT candidate_events_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON DELETE CASCADE;


--
-- Name: candidate_events candidate_events_interviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidate_events
    ADD CONSTRAINT candidate_events_interviewer_id_fkey FOREIGN KEY (interviewer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: candidates candidates_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidates
    ADD CONSTRAINT candidates_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: career_pathways career_pathways_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.career_pathways
    ADD CONSTRAINT career_pathways_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: checklists checklists_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.checklists
    ADD CONSTRAINT checklists_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: clients clients_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: comments comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: comments comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: competencies competencies_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.competencies
    ADD CONSTRAINT competencies_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: compliance_items compliance_items_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.compliance_items
    ADD CONSTRAINT compliance_items_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.person_documents(id) ON DELETE SET NULL;


--
-- Name: compliance_items compliance_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.compliance_items
    ADD CONSTRAINT compliance_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: compliance_items compliance_items_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.compliance_items
    ADD CONSTRAINT compliance_items_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: custom_field_values custom_field_values_field_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_field_id_fkey FOREIGN KEY (field_id) REFERENCES public.custom_fields(id) ON DELETE CASCADE;


--
-- Name: custom_field_values custom_field_values_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: custom_fields custom_fields_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: development_checkpoints development_checkpoints_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_checkpoints
    ADD CONSTRAINT development_checkpoints_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.development_plans(id) ON DELETE CASCADE;


--
-- Name: development_checkpoints development_checkpoints_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_checkpoints
    ADD CONSTRAINT development_checkpoints_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: development_goals development_goals_linked_competency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_goals
    ADD CONSTRAINT development_goals_linked_competency_id_fkey FOREIGN KEY (linked_competency_id) REFERENCES public.competencies(id) ON DELETE SET NULL;


--
-- Name: development_goals development_goals_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_goals
    ADD CONSTRAINT development_goals_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.development_plans(id) ON DELETE CASCADE;


--
-- Name: development_milestones development_milestones_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_milestones
    ADD CONSTRAINT development_milestones_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.development_plans(id) ON DELETE CASCADE;


--
-- Name: development_plans development_plans_review_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_plans
    ADD CONSTRAINT development_plans_review_period_id_fkey FOREIGN KEY (review_period_id) REFERENCES public.review_periods(id) ON DELETE SET NULL;


--
-- Name: development_plans development_plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_plans
    ADD CONSTRAINT development_plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: development_plans development_plans_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_plans
    ADD CONSTRAINT development_plans_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: early_talent_cohorts early_talent_cohorts_programme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_cohorts
    ADD CONSTRAINT early_talent_cohorts_programme_id_fkey FOREIGN KEY (programme_id) REFERENCES public.early_talent_programmes(id) ON DELETE CASCADE;


--
-- Name: early_talent_milestones early_talent_milestones_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_milestones
    ADD CONSTRAINT early_talent_milestones_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.early_talent_participants(id) ON DELETE CASCADE;


--
-- Name: early_talent_participants early_talent_participants_buddy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_participants
    ADD CONSTRAINT early_talent_participants_buddy_id_fkey FOREIGN KEY (buddy_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: early_talent_participants early_talent_participants_cohort_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_participants
    ADD CONSTRAINT early_talent_participants_cohort_id_fkey FOREIGN KEY (cohort_id) REFERENCES public.early_talent_cohorts(id) ON DELETE SET NULL;


--
-- Name: early_talent_participants early_talent_participants_development_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_participants
    ADD CONSTRAINT early_talent_participants_development_plan_id_fkey FOREIGN KEY (development_plan_id) REFERENCES public.development_plans(id) ON DELETE SET NULL;


--
-- Name: early_talent_participants early_talent_participants_mentor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_participants
    ADD CONSTRAINT early_talent_participants_mentor_id_fkey FOREIGN KEY (mentor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: early_talent_participants early_talent_participants_programme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_participants
    ADD CONSTRAINT early_talent_participants_programme_id_fkey FOREIGN KEY (programme_id) REFERENCES public.early_talent_programmes(id) ON DELETE CASCADE;


--
-- Name: early_talent_participants early_talent_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_participants
    ADD CONSTRAINT early_talent_participants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: early_talent_participants early_talent_participants_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_participants
    ADD CONSTRAINT early_talent_participants_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: early_talent_programmes early_talent_programmes_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_programmes
    ADD CONSTRAINT early_talent_programmes_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: early_talent_rotation_assignments early_talent_rotation_assignments_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_rotation_assignments
    ADD CONSTRAINT early_talent_rotation_assignments_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.early_talent_participants(id) ON DELETE CASCADE;


--
-- Name: early_talent_rotation_assignments early_talent_rotation_assignments_rotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_rotation_assignments
    ADD CONSTRAINT early_talent_rotation_assignments_rotation_id_fkey FOREIGN KEY (rotation_id) REFERENCES public.early_talent_rotations(id) ON DELETE CASCADE;


--
-- Name: early_talent_rotation_assignments early_talent_rotation_assignments_supervisor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_rotation_assignments
    ADD CONSTRAINT early_talent_rotation_assignments_supervisor_id_fkey FOREIGN KEY (supervisor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: early_talent_rotations early_talent_rotations_programme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.early_talent_rotations
    ADD CONSTRAINT early_talent_rotations_programme_id_fkey FOREIGN KEY (programme_id) REFERENCES public.early_talent_programmes(id) ON DELETE CASCADE;


--
-- Name: feedback feedback_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: feedback feedback_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: development_goals fk_development_goals_linked_objective_id; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_goals
    ADD CONSTRAINT fk_development_goals_linked_objective_id FOREIGN KEY (linked_objective_id) REFERENCES public.objectives(id) ON DELETE SET NULL;


--
-- Name: development_plans fk_development_plans_career_pathway_id; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_plans
    ADD CONSTRAINT fk_development_plans_career_pathway_id FOREIGN KEY (career_pathway_id) REFERENCES public.career_pathways(id) ON DELETE SET NULL;


--
-- Name: tasks fk_task_parent; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_task_parent FOREIGN KEY (parent_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: key_results key_results_objective_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.key_results
    ADD CONSTRAINT key_results_objective_id_fkey FOREIGN KEY (objective_id) REFERENCES public.objectives(id) ON DELETE CASCADE;


--
-- Name: kudos kudos_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.kudos
    ADD CONSTRAINT kudos_from_user_id_fkey FOREIGN KEY (from_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kudos kudos_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.kudos
    ADD CONSTRAINT kudos_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kudos kudos_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.kudos
    ADD CONSTRAINT kudos_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: leave_allowances leave_allowances_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_allowances
    ADD CONSTRAINT leave_allowances_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: leave_allowances leave_allowances_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_allowances
    ADD CONSTRAINT leave_allowances_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: leave_requests leave_requests_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: leave_requests leave_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: leave_requests leave_requests_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: lookup_values lookup_values_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.lookup_values
    ADD CONSTRAINT lookup_values_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: meeting_actions meeting_actions_carried_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_carried_from_id_fkey FOREIGN KEY (carried_from_id) REFERENCES public.meeting_actions(id) ON DELETE SET NULL;


--
-- Name: meeting_actions meeting_actions_meeting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_meeting_id_fkey FOREIGN KEY (meeting_id) REFERENCES public.meetings(id) ON DELETE CASCADE;


--
-- Name: meeting_actions meeting_actions_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: meetings meetings_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: meetings meetings_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: meetings meetings_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: milestones milestones_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: milestones milestones_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: objectives objectives_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.objectives(id) ON DELETE SET NULL;


--
-- Name: objectives objectives_review_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_review_period_id_fkey FOREIGN KEY (review_period_id) REFERENCES public.review_periods(id) ON DELETE SET NULL;


--
-- Name: objectives objectives_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: objectives objectives_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: onboarding_checklist_items onboarding_checklist_items_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklist_items
    ADD CONSTRAINT onboarding_checklist_items_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: onboarding_checklist_items onboarding_checklist_items_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklist_items
    ADD CONSTRAINT onboarding_checklist_items_checklist_id_fkey FOREIGN KEY (checklist_id) REFERENCES public.onboarding_checklists(id) ON DELETE CASCADE;


--
-- Name: onboarding_checklists onboarding_checklists_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.onboarding_templates(id) ON DELETE SET NULL;


--
-- Name: onboarding_checklists onboarding_checklists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: onboarding_checklists onboarding_checklists_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: onboarding_template_items onboarding_template_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_template_items
    ADD CONSTRAINT onboarding_template_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.onboarding_templates(id) ON DELETE CASCADE;


--
-- Name: onboarding_templates onboarding_templates_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_templates
    ADD CONSTRAINT onboarding_templates_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: person_documents person_documents_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_documents
    ADD CONSTRAINT person_documents_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.person_profiles(id) ON DELETE CASCADE;


--
-- Name: person_documents person_documents_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_documents
    ADD CONSTRAINT person_documents_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: person_documents person_documents_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_documents
    ADD CONSTRAINT person_documents_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: person_profiles person_profiles_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: person_profiles person_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: person_profiles person_profiles_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: projects projects_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: projects projects_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: pulse_responses pulse_responses_survey_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_responses
    ADD CONSTRAINT pulse_responses_survey_id_fkey FOREIGN KEY (survey_id) REFERENCES public.pulse_surveys(id) ON DELETE CASCADE;


--
-- Name: pulse_responses pulse_responses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_responses
    ADD CONSTRAINT pulse_responses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: pulse_surveys pulse_surveys_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_surveys
    ADD CONSTRAINT pulse_surveys_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: review_cycles review_cycles_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.review_cycles
    ADD CONSTRAINT review_cycles_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: review_periods review_periods_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.review_periods
    ADD CONSTRAINT review_periods_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_cycle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES public.review_cycles(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: rota_entries rota_entries_rota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rota_entries
    ADD CONSTRAINT rota_entries_rota_id_fkey FOREIGN KEY (rota_id) REFERENCES public.rotas(id) ON DELETE CASCADE;


--
-- Name: rota_entries rota_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rota_entries
    ADD CONSTRAINT rota_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rota_entries rota_entries_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rota_entries
    ADD CONSTRAINT rota_entries_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: rotas rotas_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rotas
    ADD CONSTRAINT rotas_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: segments segments_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.segments
    ADD CONSTRAINT segments_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: shared_timelines shared_timelines_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.shared_timelines
    ADD CONSTRAINT shared_timelines_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: shared_timelines shared_timelines_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.shared_timelines
    ADD CONSTRAINT shared_timelines_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: shared_timelines shared_timelines_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.shared_timelines
    ADD CONSTRAINT shared_timelines_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: tags tags_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: task_assignees task_assignees_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_assignees
    ADD CONSTRAINT task_assignees_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_assignees task_assignees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_assignees
    ADD CONSTRAINT task_assignees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_dependencies task_dependencies_blocked_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_blocked_id_fkey FOREIGN KEY (blocked_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_dependencies task_dependencies_blocker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_blocker_id_fkey FOREIGN KEY (blocker_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_templates task_templates_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_templates
    ADD CONSTRAINT task_templates_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: teams teams_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: time_entries time_entries_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: time_entries time_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: time_entries time_entries_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: time_off time_off_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_off
    ADD CONSTRAINT time_off_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: time_off time_off_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_off
    ADD CONSTRAINT time_off_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: user_competencies user_competencies_assessed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_assessed_by_fkey FOREIGN KEY (assessed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_competencies user_competencies_competency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_competency_id_fkey FOREIGN KEY (competency_id) REFERENCES public.competencies(id) ON DELETE CASCADE;


--
-- Name: user_competencies user_competencies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_competencies user_competencies_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: users users_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: webhook_logs webhook_logs_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

