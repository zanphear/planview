--
-- PostgreSQL database dump
--

\restrict UUQJG5iwpLXxlYaAcVgfAYXvwn0eTA6zkeymztynsIZxIg6ME41pmaee0Z9mFyS

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: planview
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO planview;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: planview
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.activities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid,
    entity_name character varying(500),
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.activities OWNER TO planview;

--
-- Name: ai_chat_messages; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.ai_chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    tool_calls jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_chat_messages OWNER TO planview;

--
-- Name: ai_chat_sessions; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.ai_chat_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) DEFAULT 'New Chat'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_chat_sessions OWNER TO planview;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO planview;

--
-- Name: analysis_reports; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.analysis_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    report_type character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    content text,
    parameters jsonb,
    status character varying(20) DEFAULT 'generating'::character varying NOT NULL,
    generation_time_seconds double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.analysis_reports OWNER TO planview;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    filename character varying(500) NOT NULL,
    file_path character varying(1000) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(255) NOT NULL,
    task_id uuid NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.attachments OWNER TO planview;

--
-- Name: candidate_events; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.candidate_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    candidate_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    event_date date,
    interviewer_id uuid,
    outcome character varying(20),
    notes text,
    rejection_reason character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.candidate_events OWNER TO planview;

--
-- Name: candidates; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.candidates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    phone character varying(50),
    position_applied character varying(255),
    source character varying(50),
    status character varying(20) DEFAULT 'applied'::character varying NOT NULL,
    applied_date date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.candidates OWNER TO planview;

--
-- Name: checklists; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.checklists (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(500) NOT NULL,
    is_completed boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    task_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.checklists OWNER TO planview;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.clients OWNER TO planview;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    body text NOT NULL,
    task_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.comments OWNER TO planview;

--
-- Name: competencies; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.competencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(50),
    description text,
    requires_certification boolean DEFAULT false NOT NULL,
    certification_validity_months integer,
    levels jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.competencies OWNER TO planview;

--
-- Name: compliance_items; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.compliance_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    item_type character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    reference_number character varying(255),
    issue_date date,
    expiry_date date,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    alert_days jsonb,
    document_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_items OWNER TO planview;

--
-- Name: custom_field_values; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.custom_field_values (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    value text,
    field_id uuid NOT NULL,
    task_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.custom_field_values OWNER TO planview;

--
-- Name: custom_fields; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.custom_fields (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    field_type character varying(20) DEFAULT 'text'::character varying NOT NULL,
    options text,
    sort_order integer DEFAULT 0 NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.custom_fields OWNER TO planview;

--
-- Name: development_goals; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.development_goals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    goal_type character varying(50),
    linked_competency_id uuid,
    target_date date,
    status character varying(20) DEFAULT 'not_started'::character varying NOT NULL,
    evidence text,
    cost_estimate double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.development_goals OWNER TO planview;

--
-- Name: development_plans; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.development_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    review_period_id uuid,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    career_aspiration text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.development_plans OWNER TO planview;

--
-- Name: key_results; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.key_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    objective_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    target_value double precision,
    current_value double precision,
    unit character varying(50),
    measurement_type character varying(20) DEFAULT 'numeric'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.key_results OWNER TO planview;

--
-- Name: kudos; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.kudos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    from_user_id uuid NOT NULL,
    to_user_id uuid NOT NULL,
    message character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.kudos OWNER TO planview;

--
-- Name: leave_allowances; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.leave_allowances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    year integer NOT NULL,
    entitlement_days integer DEFAULT 25 NOT NULL,
    carried_forward integer DEFAULT 0 NOT NULL,
    used_days integer DEFAULT 0 NOT NULL,
    booked_days integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.leave_allowances OWNER TO planview;

--
-- Name: leave_requests; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.leave_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    leave_type character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    days integer NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    approved_by uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.leave_requests OWNER TO planview;

--
-- Name: meeting_actions; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.meeting_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    meeting_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    owner_id uuid,
    carried_from_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meeting_actions OWNER TO planview;

--
-- Name: meetings; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.meetings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    manager_id uuid NOT NULL,
    report_id uuid NOT NULL,
    scheduled_date date NOT NULL,
    actual_date date,
    notes text,
    mood character varying(20),
    status character varying(20) DEFAULT 'scheduled'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meetings OWNER TO planview;

--
-- Name: milestones; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.milestones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    date date NOT NULL,
    colour character varying(7) DEFAULT '#E44332'::character varying NOT NULL,
    project_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.milestones OWNER TO planview;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    event_type character varying(64) NOT NULL,
    title character varying(255) NOT NULL,
    body text,
    is_read boolean DEFAULT false NOT NULL,
    link character varying(512),
    actor_id uuid,
    task_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO planview;

--
-- Name: objectives; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.objectives (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    review_period_id uuid,
    parent_id uuid,
    title character varying(500) NOT NULL,
    description text,
    category character varying(50),
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    weight double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.objectives OWNER TO planview;

--
-- Name: onboarding_checklist_items; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.onboarding_checklist_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    checklist_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    assigned_to uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_checklist_items OWNER TO planview;

--
-- Name: onboarding_checklists; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.onboarding_checklists (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    template_id uuid,
    checklist_type character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'in_progress'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_checklists OWNER TO planview;

--
-- Name: onboarding_template_items; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.onboarding_template_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    template_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    default_assignee_role character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_template_items OWNER TO planview;

--
-- Name: onboarding_templates; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.onboarding_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    template_type character varying(20) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_templates OWNER TO planview;

--
-- Name: person_documents; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.person_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    document_type character varying(50) NOT NULL,
    filename character varying(500) NOT NULL,
    file_path character varying(1000) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(255) NOT NULL,
    expiry_date date,
    uploaded_by uuid NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.person_documents OWNER TO planview;

--
-- Name: person_profiles; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.person_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    job_title character varying(255),
    department character varying(255),
    manager_id uuid,
    contract_type character varying(50),
    contract_start date,
    contract_end date,
    probation_end date,
    location character varying(255),
    phone character varying(50),
    employee_id character varying(100),
    notes text,
    date_of_birth date,
    partner_name character varying(255),
    number_of_kids integer,
    kids_details text,
    interests text,
    dietary_requirements character varying(255),
    emergency_contact character varying(500),
    personal_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.person_profiles OWNER TO planview;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    colour character varying(7) DEFAULT '#4186E0'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    is_favourite boolean DEFAULT false NOT NULL,
    custom_statuses json,
    client_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_project_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'archived'::character varying])::text[])))
);


ALTER TABLE public.projects OWNER TO planview;

--
-- Name: pulse_responses; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.pulse_responses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    survey_id uuid NOT NULL,
    user_id uuid,
    morale integer,
    workload integer,
    support integer,
    comments text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pulse_responses OWNER TO planview;

--
-- Name: pulse_surveys; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.pulse_surveys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    end_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pulse_surveys OWNER TO planview;

--
-- Name: review_cycles; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.review_cycles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    status character varying(20) DEFAULT 'setup'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.review_cycles OWNER TO planview;

--
-- Name: review_periods; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.review_periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.review_periods OWNER TO planview;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cycle_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid NOT NULL,
    reviewer_id uuid NOT NULL,
    self_assessment jsonb,
    manager_assessment jsonb,
    overall_rating integer,
    strengths text,
    areas_for_improvement text,
    status character varying(20) DEFAULT 'not_started'::character varying NOT NULL,
    sign_off_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reviews OWNER TO planview;

--
-- Name: rota_entries; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.rota_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rota_id uuid NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    date_from date NOT NULL,
    date_to date NOT NULL,
    notes character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rota_entries OWNER TO planview;

--
-- Name: rotas; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.rotas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    rota_type character varying(20) DEFAULT 'callout'::character varying NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    include_weekends boolean DEFAULT false NOT NULL,
    colour character varying(7) DEFAULT '#8A00E5'::character varying NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rotas OWNER TO planview;

--
-- Name: segments; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.segments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    project_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.segments OWNER TO planview;

--
-- Name: shared_timelines; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.shared_timelines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    token character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    team_id uuid,
    project_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.shared_timelines OWNER TO planview;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.tags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    colour character varying(7) DEFAULT '#8E8E8E'::character varying NOT NULL,
    project_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tags OWNER TO planview;

--
-- Name: task_assignees; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.task_assignees (
    task_id uuid NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.task_assignees OWNER TO planview;

--
-- Name: task_dependencies; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.task_dependencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    blocker_id uuid NOT NULL,
    blocked_id uuid NOT NULL,
    dependency_type character varying(20) DEFAULT 'finish_to_start'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.task_dependencies OWNER TO planview;

--
-- Name: task_tags; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.task_tags (
    task_id uuid NOT NULL,
    tag_id uuid NOT NULL
);


ALTER TABLE public.task_tags OWNER TO planview;

--
-- Name: task_templates; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.task_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    colour character varying(7),
    status character varying(50) DEFAULT 'todo'::character varying NOT NULL,
    time_estimate_minutes integer,
    checklist_items jsonb,
    tag_names jsonb,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.task_templates OWNER TO planview;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    colour character varying(7),
    status character varying(50) DEFAULT 'todo'::character varying NOT NULL,
    status_emoji character varying(10),
    date_from date,
    date_to date,
    start_time time without time zone,
    end_time time without time zone,
    time_estimate_minutes integer,
    time_estimate_mode character varying(10) DEFAULT 'total'::character varying NOT NULL,
    is_recurring boolean DEFAULT false NOT NULL,
    recurrence_rule character varying(500),
    sort_order integer DEFAULT 0 NOT NULL,
    project_id uuid,
    segment_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    parent_id uuid,
    time_logged_minutes integer DEFAULT 0 NOT NULL,
    CONSTRAINT ck_task_time_estimate_mode CHECK (((time_estimate_mode)::text = ANY ((ARRAY['total'::character varying, 'per_day'::character varying])::text[])))
);


ALTER TABLE public.tasks OWNER TO planview;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.team_members (
    team_id uuid NOT NULL,
    user_id uuid NOT NULL,
    sort_order integer DEFAULT 0
);


ALTER TABLE public.team_members OWNER TO planview;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.teams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    is_favourite boolean DEFAULT false NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.teams OWNER TO planview;

--
-- Name: time_off; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.time_off (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    date_from date NOT NULL,
    date_to date NOT NULL,
    reason character varying(255) DEFAULT 'Time Off'::character varying NOT NULL,
    colour character varying(7) DEFAULT '#94A3B8'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.time_off OWNER TO planview;

--
-- Name: user_competencies; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.user_competencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    competency_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    level character varying(50),
    assessed_date date,
    assessed_by uuid,
    expiry_date date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_competencies OWNER TO planview;

--
-- Name: users; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    password_hash character varying(255),
    initials character varying(2),
    colour character varying(7) DEFAULT '#4186E0'::character varying NOT NULL,
    avatar_url character varying(500),
    role character varying(20) DEFAULT 'regular'::character varying NOT NULL,
    pin_on_top boolean DEFAULT false NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    notification_prefs jsonb,
    totp_secret character varying(255),
    totp_enabled boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_user_role CHECK (((role)::text = ANY ((ARRAY['owner'::character varying, 'admin'::character varying, 'regular'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO planview;

--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.webhook_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event character varying(100) NOT NULL,
    payload jsonb,
    response_status integer,
    response_body text,
    success boolean DEFAULT false NOT NULL,
    webhook_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.webhook_logs OWNER TO planview;

--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(2000) NOT NULL,
    secret character varying(255),
    events jsonb,
    is_active boolean DEFAULT true NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.webhooks OWNER TO planview;

--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: planview
--

CREATE TABLE public.workspaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    enabled_modules jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.workspaces OWNER TO planview;

--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.activities (id, workspace_id, actor_id, action, entity_type, entity_id, entity_name, details, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_chat_messages; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.ai_chat_messages (id, session_id, role, content, tool_calls, created_at, updated_at) FROM stdin;
0be2c01b-0278-4a41-936b-c26c9a807c88	62c4b796-cb1b-42ab-a1f6-0588270b8ef6	user	Give me a summary of my team's status	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
52143c1a-2ca5-459e-ac9b-7ddf28323e65	62c4b796-cb1b-42ab-a1f6-0588270b8ef6	assistant	Here's a quick overview of your team at Acme Corp:\n\n**Team Size:** 20 members across Engineering, Design, Marketing, Product, and Data\n\n**Key Highlights:**\n- 30 objectives tracked, averaging ~50% progress across the board\n- 12 compliance items expiring within 90 days — several need urgent attention\n- 8 pending leave requests awaiting approval\n- Team morale trending upward at 3.8/5 in the latest pulse survey\n- 10 active candidates in the recruitment pipeline\n- 3 team members currently onboarding\n\nWould you like me to dig deeper into any of these areas?	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: ai_chat_sessions; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.ai_chat_sessions (id, workspace_id, user_id, title, created_at, updated_at) FROM stdin;
62c4b796-cb1b-42ab-a1f6-0588270b8ef6	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	Team Overview	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4be1c0d2-85bb-4aa9-a71c-7dfecae8e01d	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	Report: team_health	2026-02-28 09:34:48.720504+00	2026-02-28 09:34:48.720504+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.alembic_version (version_num) FROM stdin;
013
\.


--
-- Data for Name: analysis_reports; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.analysis_reports (id, workspace_id, user_id, report_type, title, content, parameters, status, generation_time_seconds, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.attachments (id, filename, file_path, file_size, mime_type, task_id, uploaded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: candidate_events; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.candidate_events (id, candidate_id, event_type, event_date, interviewer_id, outcome, notes, rejection_reason, created_at, updated_at) FROM stdin;
9eba49da-9f89-492c-82e1-9783c077af86	ec08ce11-419e-4155-8aef-12405e099140	cv_review	2026-02-06	549dd47f-510d-4315-aa26-8dc131f272b2	maybe	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8f0a630e-9635-41fb-bbbb-9144b70b86aa	f4c148f4-3867-4576-910d-1c7aa71f5a5c	cv_review	2026-02-01	4ac83d84-43e6-4389-bf01-f0c0251affb9	pass	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
911b6c93-5ace-4119-8555-13169c866d42	f4c148f4-3867-4576-910d-1c7aa71f5a5c	phone_screen	2026-02-05	4ac83d84-43e6-4389-bf01-f0c0251affb9	pass	Phone Screen completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
63a8f04d-cd0b-4e1f-849f-a6fa6510648b	f4c148f4-3867-4576-910d-1c7aa71f5a5c	interview	2026-02-09	a13df553-f991-456a-9401-7c90bc033e88	maybe	Interview completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c61a490c-a197-4f9f-8b85-051fefaed31e	e55bac3b-ad54-4dbb-91d2-13985b7aa81f	cv_review	2026-02-11	4ac83d84-43e6-4389-bf01-f0c0251affb9	pass	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6edfa4da-16c8-40bc-85f3-d68e1f8cfb77	e55bac3b-ad54-4dbb-91d2-13985b7aa81f	phone_screen	2026-02-15	549dd47f-510d-4315-aa26-8dc131f272b2	pass	Phone Screen completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a3475edb-9e8f-43e1-8eb9-b6603888e22b	e55bac3b-ad54-4dbb-91d2-13985b7aa81f	interview	2026-02-19	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	maybe	Interview completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
482b161f-e276-42af-bff7-acfaa894bbd3	d249747b-68ad-4ee1-b235-daa373fa850f	cv_review	2026-01-27	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	pass	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7cd4cbfc-f75b-4504-8fe1-d0be307d49de	d249747b-68ad-4ee1-b235-daa373fa850f	phone_screen	2026-01-31	a13df553-f991-456a-9401-7c90bc033e88	pass	Phone Screen completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
80502e6d-45c8-4af2-842f-dfa7f98f3386	d249747b-68ad-4ee1-b235-daa373fa850f	interview	2026-02-04	549dd47f-510d-4315-aa26-8dc131f272b2	pass	Interview completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b41211ae-8453-4de2-a425-574c64c6309f	d249747b-68ad-4ee1-b235-daa373fa850f	technical_test	2026-02-08	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	pass	Technical Test completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
80d6a90c-6542-4129-80cb-8f07e6b94d35	fa7cacc3-2e23-4ea0-ae4c-aeda7ee71786	cv_review	2026-01-17	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	pass	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bf22e7e3-ee67-4421-93f1-ab2179405750	fa7cacc3-2e23-4ea0-ae4c-aeda7ee71786	phone_screen	2026-01-21	549dd47f-510d-4315-aa26-8dc131f272b2	pass	Phone Screen completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1ad9adf4-1700-45cf-9ba0-8e1014520285	fa7cacc3-2e23-4ea0-ae4c-aeda7ee71786	interview	2026-01-25	549dd47f-510d-4315-aa26-8dc131f272b2	pass	Interview completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9c640dde-99cd-496e-9218-6302cf61b2a3	fa7cacc3-2e23-4ea0-ae4c-aeda7ee71786	technical_test	2026-01-29	a13df553-f991-456a-9401-7c90bc033e88	pass	Technical Test completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a74fc368-9c07-4ea6-9a23-ce6ca505219e	fa7cacc3-2e23-4ea0-ae4c-aeda7ee71786	offer	2026-02-02	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	pass	Offer completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
739526bd-11e0-4cb6-9aee-4f913769600a	706b332e-90b6-4832-aa29-e85e5b6a46b0	cv_review	2026-02-19	549dd47f-510d-4315-aa26-8dc131f272b2	maybe	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ee553e0a-737f-4e71-8ca5-4d97e2a4d866	3cf532ca-2da8-4264-b80e-ff806e6319ee	cv_review	2026-02-13	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	pass	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
20b1a1c4-1fd2-40d7-b4bc-d9d5620214cf	3cf532ca-2da8-4264-b80e-ff806e6319ee	phone_screen	2026-02-17	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	pass	Phone Screen completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
02353cce-774a-46c2-b3d4-7998533a98a4	3cf532ca-2da8-4264-b80e-ff806e6319ee	interview	2026-02-21	a13df553-f991-456a-9401-7c90bc033e88	maybe	Interview completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
089a211e-18a6-4a1f-82e2-77e1a55397c0	b634355e-b155-4a64-b3e2-70bf02ad6eab	cv_review	2026-01-22	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	pass	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3207a25c-1581-4b90-8cb5-28ec7262ea43	b634355e-b155-4a64-b3e2-70bf02ad6eab	phone_screen	2026-01-26	a13df553-f991-456a-9401-7c90bc033e88	pass	Phone Screen completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
78ac2059-3923-41c2-83c0-57aa3309a718	b634355e-b155-4a64-b3e2-70bf02ad6eab	interview	2026-01-30	549dd47f-510d-4315-aa26-8dc131f272b2	pass	Interview completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
31ecedf5-2851-4c0a-b356-f908b1627d27	b634355e-b155-4a64-b3e2-70bf02ad6eab	technical_test	2026-02-03	a13df553-f991-456a-9401-7c90bc033e88	pass	Technical Test completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
18eeb2c8-0430-454b-b917-0cdd2306b806	536458ec-adbb-4c74-9f00-2c63f116806f	cv_review	2026-01-12	4ac83d84-43e6-4389-bf01-f0c0251affb9	pass	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6954dfea-910c-42b8-ab76-a3b9e9932b66	536458ec-adbb-4c74-9f00-2c63f116806f	phone_screen	2026-01-16	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	pass	Phone Screen completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f348470b-4395-402d-bf4f-bebc8576c2cb	536458ec-adbb-4c74-9f00-2c63f116806f	interview	2026-01-20	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	fail	Interview completed	Skills not aligned with role requirements	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7d7469e5-c9a1-4136-9058-582c51e69ace	a3828d24-7773-4bf5-869c-439c90bf199b	cv_review	2026-02-16	4ac83d84-43e6-4389-bf01-f0c0251affb9	maybe	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
83ee96b0-dfa5-4214-8ea6-c746af51373c	1c7641e3-3c1e-46b2-bf5c-ab6efce948be	cv_review	2026-02-09	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	pass	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2b748804-58f3-4440-b66b-4efcee10559e	1c7641e3-3c1e-46b2-bf5c-ab6efce948be	phone_screen	2026-02-13	4ac83d84-43e6-4389-bf01-f0c0251affb9	pass	Phone Screen completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4852a0c5-4eb9-4087-96e8-b08e2f2394b8	740a2a35-166d-40ea-8ce2-e3221c55b3a9	cv_review	2026-02-17	549dd47f-510d-4315-aa26-8dc131f272b2	pass	Cv Review completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c713a42b-bdd4-49da-a416-27c5ef640d2e	740a2a35-166d-40ea-8ce2-e3221c55b3a9	phone_screen	2026-02-21	549dd47f-510d-4315-aa26-8dc131f272b2	pass	Phone Screen completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
29d51bfd-68a4-42db-89fe-61942c7c8207	740a2a35-166d-40ea-8ce2-e3221c55b3a9	interview	2026-02-25	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	maybe	Interview completed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: candidates; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.candidates (id, workspace_id, name, email, phone, position_applied, source, status, applied_date, notes, created_at, updated_at) FROM stdin;
ec08ce11-419e-4155-8aef-12405e099140	db8b3402-39f2-455b-8d28-4d8279ca46c0	Alice Johnson	alice.j@mail.com	\N	Senior Developer	referral	screening	2026-02-03	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f4c148f4-3867-4576-910d-1c7aa71f5a5c	db8b3402-39f2-455b-8d28-4d8279ca46c0	Frank Wilson	frank.w@mail.com	\N	DevOps Engineer	agency	interviewing	2026-01-29	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e55bac3b-ad54-4dbb-91d2-13985b7aa81f	db8b3402-39f2-455b-8d28-4d8279ca46c0	Grace Lee	grace.l@mail.com	\N	UX Designer	direct	interviewing	2026-02-08	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d249747b-68ad-4ee1-b235-daa373fa850f	db8b3402-39f2-455b-8d28-4d8279ca46c0	Henry Taylor	henry.t@mail.com	\N	Marketing Analyst	direct	offered	2026-01-24	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fa7cacc3-2e23-4ea0-ae4c-aeda7ee71786	db8b3402-39f2-455b-8d28-4d8279ca46c0	Ivy Chen	ivy.c@mail.com	\N	Backend Developer	internal	hired	2026-01-14	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8d8b3dd5-2d8d-43d2-a025-7a4fce0ca441	db8b3402-39f2-455b-8d28-4d8279ca46c0	James Wright	james.w@mail.com	\N	Platform Engineer	agency	applied	2026-02-23	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
706b332e-90b6-4832-aa29-e85e5b6a46b0	db8b3402-39f2-455b-8d28-4d8279ca46c0	Kim Nakamura	kim.n@mail.com	\N	Data Scientist	direct	screening	2026-02-16	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3cf532ca-2da8-4264-b80e-ff806e6319ee	db8b3402-39f2-455b-8d28-4d8279ca46c0	Luca Bianchi	luca.b@mail.com	\N	Senior Developer	referral	interviewing	2026-02-10	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2f3d8e21-d027-411f-a09f-6c9e3d249b2d	db8b3402-39f2-455b-8d28-4d8279ca46c0	Maria Santos	maria.s@mail.com	\N	Product Designer	direct	applied	2026-02-25	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b634355e-b155-4a64-b3e2-70bf02ad6eab	db8b3402-39f2-455b-8d28-4d8279ca46c0	Nadia Popov	nadia.p@mail.com	\N	Security Engineer	agency	offered	2026-01-19	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
536458ec-adbb-4c74-9f00-2c63f116806f	db8b3402-39f2-455b-8d28-4d8279ca46c0	Omar Hassan	omar.h@mail.com	\N	Full Stack Developer	direct	rejected	2026-01-09	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c19e407b-ef34-4ef7-81cf-6344bc7f8fa8	db8b3402-39f2-455b-8d28-4d8279ca46c0	Priya Sharma	priya.s@mail.com	\N	QA Engineer	referral	applied	2026-02-20	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a3828d24-7773-4bf5-869c-439c90bf199b	db8b3402-39f2-455b-8d28-4d8279ca46c0	Ravi Patel	ravi.p@mail.com	\N	DevOps Engineer	agency	screening	2026-02-13	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1c7641e3-3c1e-46b2-bf5c-ab6efce948be	db8b3402-39f2-455b-8d28-4d8279ca46c0	Sofia Eriksson	sofia.e@mail.com	\N	UX Researcher	direct	withdrawn	2026-02-06	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
740a2a35-166d-40ea-8ce2-e3221c55b3a9	db8b3402-39f2-455b-8d28-4d8279ca46c0	Tom Mbeki	tom.m@mail.com	\N	Junior Developer	internal	interviewing	2026-02-14	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: checklists; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.checklists (id, title, is_completed, sort_order, task_id, created_at, updated_at) FROM stdin;
cd582971-e338-48a7-b16b-27eab824c0a7	Research	t	0	cb8c627b-56cf-4dc8-9afd-8c3e7c434528	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fd7bb36d-db05-47c2-9a05-ee6047663c28	Implement	t	1	cb8c627b-56cf-4dc8-9afd-8c3e7c434528	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
19b06277-6ad7-4779-a661-eaf637b4f2b1	Review	t	2	cb8c627b-56cf-4dc8-9afd-8c3e7c434528	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
95601852-351b-44dd-aa5d-2c7ce9cbd1db	Deploy	t	3	cb8c627b-56cf-4dc8-9afd-8c3e7c434528	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ceb16927-6eeb-46f7-b6bf-3c8d57ce2b37	Research	t	0	a8a4366e-12c1-4ef4-94d4-618228c516b2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f7c79576-2322-43c6-94cf-55518439e7ee	Implement	t	1	a8a4366e-12c1-4ef4-94d4-618228c516b2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
edeef4d7-c52e-4439-b27c-179dea5aa419	Review	f	2	a8a4366e-12c1-4ef4-94d4-618228c516b2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
733179b2-bb2c-4a6b-bd1c-f886bb2c7ee5	Deploy	f	3	a8a4366e-12c1-4ef4-94d4-618228c516b2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
608a900f-9172-4b15-b7c9-cc48497a0549	Research	f	0	4a868fe1-f372-47c3-8e72-b63f000b7bf2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
70920a85-0ceb-431e-b4f7-3cd1984b9443	Implement	f	1	4a868fe1-f372-47c3-8e72-b63f000b7bf2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f91234bb-efc8-44a2-9491-9cf3e28d95c1	Review	f	2	4a868fe1-f372-47c3-8e72-b63f000b7bf2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e7431054-84b5-4e26-9dc7-61b90a68d2cd	Deploy	f	3	4a868fe1-f372-47c3-8e72-b63f000b7bf2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.clients (id, name, workspace_id, created_at, updated_at) FROM stdin;
bb86c511-7089-4bb9-9f5c-30c2650eb8d9	Zenith Industries	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
efbe5d33-74c1-42c6-a4fe-f1d2c5280c85	Meridian Group	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
75181d68-6920-4425-af58-2d76d53fed90	Atlas Digital	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.comments (id, body, task_id, user_id, created_at, updated_at) FROM stdin;
de315c57-dbc6-4c05-b99a-ad75466f4b8b	Started working on Design homepage mockup. Looking good so far!	cb8c627b-56cf-4dc8-9afd-8c3e7c434528	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f2e51ad5-bd17-4157-b1c6-0b2837cd2188	Started working on Implement responsive header. Looking good so far!	a8a4366e-12c1-4ef4-94d4-618228c516b2	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
909ccc02-5b33-4ce3-b04e-52bc997bb2ca	Started working on Build product card component. Looking good so far!	4a868fe1-f372-47c3-8e72-b63f000b7bf2	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
42fbeaf1-e2ea-4330-a22d-ace5111d33f4	Started working on Checkout form validation. Looking good so far!	32d5e352-4836-4123-a272-5f1f48f79701	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c86a6cef-2144-42b6-b750-dda131f3be27	Started working on Payment gateway integration. Looking good so far!	975b53e5-b549-4c7c-8abf-74e0ea1a6900	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: competencies; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.competencies (id, workspace_id, name, category, description, requires_certification, certification_validity_months, levels, created_at, updated_at) FROM stdin;
b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	Python	technical	\N	t	24	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5b5e05cc-ab7d-4aea-94d9-b16f87454250	db8b3402-39f2-455b-8d28-4d8279ca46c0	TypeScript/React	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bad75b03-45a7-4206-89f6-2ca11880b7b1	db8b3402-39f2-455b-8d28-4d8279ca46c0	AWS	technical	\N	t	12	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5ddb17a6-3b39-4536-943b-14d152eb20f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	Kubernetes	technical	\N	t	24	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1977b095-dd8e-4f7c-b0ea-a3a7c8a4225f	db8b3402-39f2-455b-8d28-4d8279ca46c0	Project Management	management	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	Communication	soft_skill	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
dc0b5cce-365b-43df-bae7-b0cec4ec8b24	db8b3402-39f2-455b-8d28-4d8279ca46c0	Cyber Security	technical	\N	t	12	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c7481d48-e30d-4f04-99cc-3bb82abfdf3a	db8b3402-39f2-455b-8d28-4d8279ca46c0	Data Analysis	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4a33d04d-b931-4738-b062-736a30a506ce	db8b3402-39f2-455b-8d28-4d8279ca46c0	Leadership	management	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2ef5fc7b-4fd2-4c20-93d1-c39e5f57cda8	db8b3402-39f2-455b-8d28-4d8279ca46c0	UX Research	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
042a970e-b9cb-4267-b615-d7e25fedf857	db8b3402-39f2-455b-8d28-4d8279ca46c0	CI/CD & DevOps	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6c8d3dad-7389-40fa-b3f2-4fb9d6776e44	db8b3402-39f2-455b-8d28-4d8279ca46c0	SQL & Databases	technical	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d436ecba-b7fa-42b8-b500-16591bbadb34	db8b3402-39f2-455b-8d28-4d8279ca46c0	Machine Learning	technical	\N	t	24	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	Agile/Scrum	management	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
38bcfae5-40ce-40ca-83f3-6ec590124b00	db8b3402-39f2-455b-8d28-4d8279ca46c0	Stakeholder Mgmt	soft_skill	\N	f	\N	["awareness", "practitioner", "expert"]	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: compliance_items; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.compliance_items (id, workspace_id, user_id, item_type, title, reference_number, issue_date, expiry_date, status, alert_days, document_id, notes, created_at, updated_at) FROM stdin;
0ca0ad1f-23d7-4234-bf79-a139f7390fe1	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	certification	AWS Solutions Architect Pro	\N	\N	2027-02-28	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
89befe9a-0bee-4923-964c-720df7ef0bd1	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	dbs_check	DBS Enhanced Check	\N	\N	2027-08-22	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7b4226ff-532a-4c9c-983b-d4b9fd43716a	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	certification	ISO 27001 Lead Auditor	\N	\N	2026-04-29	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
95be5edf-e403-4f00-b3d5-660ced5f126a	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	right_to_work	UK Right to Work (Settled)	\N	\N	2031-02-02	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fa54f686-e600-4a94-808d-7019d6ca66c1	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	certification	CSCS Card	\N	\N	2026-03-25	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e18c9ca7-f0c8-4a26-87b8-0fefcf53e112	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	certification	Certified Scrum Master	\N	\N	2026-12-25	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
697414d4-2cba-4ef9-9d81-cd2994bc4f0e	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	right_to_work	UK Right to Work (Pre-Settled)	\N	\N	2026-04-14	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8998cd89-18cf-41a1-9bc0-6842c8b6e2b4	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	certification	First Aid at Work	\N	\N	2026-02-18	expired	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
722567d2-83d6-41fe-8458-364be983da03	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	certification	AWS Developer Associate	\N	\N	2026-09-16	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2aed5588-bec5-4f40-9322-a71098c44507	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	contract	Employment Contract	\N	\N	2028-11-24	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bfa65db9-cce2-4068-a0c2-66cc6013eadc	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	certification	PRINCE2 Practitioner	\N	\N	2027-04-04	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
67b9d03a-8f98-4a6c-b36d-e356c124d7a2	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	dbs_check	DBS Basic Check	\N	\N	2026-02-23	expired	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cd66070d-f971-4e9b-9f62-0f2639af59f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	certification	Google Analytics 4 Cert	\N	\N	2026-12-05	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
96de3d15-7717-4e78-b576-48fa35022b7f	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	certification	Kubernetes CKA	\N	\N	2026-08-27	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
36ef2494-1bc3-45bc-bc25-2b8ee4753860	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	certification	Terraform Associate	\N	\N	2026-03-30	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6f6a8423-5fa8-42b0-83b9-da98e727457f	db8b3402-39f2-455b-8d28-4d8279ca46c0	76d17f64-9249-46dc-aa2e-97c127c4c0b0	right_to_work	UK Right to Work	\N	\N	2028-01-29	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
36ef713f-9b73-4ef3-be18-3f0a30284835	db8b3402-39f2-455b-8d28-4d8279ca46c0	77f58837-3712-4af6-b549-4de11804561d	certification	HubSpot Content Marketing	\N	\N	2027-02-13	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
dffd7d2d-0507-4f1a-b501-2aba9055da87	db8b3402-39f2-455b-8d28-4d8279ca46c0	63e3e230-8516-4cb7-b323-440cf28fe175	right_to_work	BRP Card	\N	\N	2026-03-20	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
48d1f243-4fc6-4773-99c7-a12e2d4206a2	db8b3402-39f2-455b-8d28-4d8279ca46c0	63e3e230-8516-4cb7-b323-440cf28fe175	certification	Azure Developer Associate	\N	\N	2026-10-26	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
869f763b-f829-4ce1-8b11-1903acbbeaa2	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	certification	Docker Certified Associate	\N	\N	2026-02-13	expired	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e2f28957-e048-4815-821e-ff5b80493414	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	certification	AWS SysOps Administrator	\N	\N	2026-07-28	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bfac736c-2071-4ebc-bac9-32c4c2412695	db8b3402-39f2-455b-8d28-4d8279ca46c0	9bdd4897-c917-4304-bbc4-cf6ee4579def	contract	Employment Contract	\N	\N	2028-08-16	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b59ee387-bf13-4c6e-86d6-b416b6870edd	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	certification	Certified Product Manager	\N	\N	2027-01-14	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
62294f48-b125-4209-843e-dac375a748f1	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	certification	Snowflake Data Engineer	\N	\N	2026-04-09	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cb99d1dd-6481-4eba-96a9-7b3822d7b13a	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	right_to_work	UK Right to Work (Visa)	\N	\N	2026-04-24	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1412df82-f08f-44ed-bc72-40e139b22548	db8b3402-39f2-455b-8d28-4d8279ca46c0	5eb86614-6fc0-49ac-97e3-601d92788d24	contract	Fixed-Term Contract	\N	\N	2026-05-14	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f23fa13b-471b-473b-a684-80d545deba4d	db8b3402-39f2-455b-8d28-4d8279ca46c0	5eb86614-6fc0-49ac-97e3-601d92788d24	certification	Google Ads Certification	\N	\N	2026-11-15	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9a328d22-ffd5-4b86-be6a-24f71566cd3b	db8b3402-39f2-455b-8d28-4d8279ca46c0	86e6ea5d-5142-4c37-b94f-af48785430c9	certification	Professional Scrum PO	\N	\N	2027-04-24	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a41ca7c9-dbe1-4ee2-8502-86f20bd2e453	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	certification	CISSP	\N	\N	2027-07-13	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
240ec7cb-1360-4aaa-bf86-4fb6807307b1	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	certification	CEH v12	\N	\N	2026-04-04	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
055d6fa7-d6ac-4344-b022-a9fe6fc39a3a	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	dbs_check	DBS Enhanced Check	\N	\N	2027-06-23	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ad33315c-8a4a-4352-b1cb-4527fa9dbe54	db8b3402-39f2-455b-8d28-4d8279ca46c0	e78e0255-f170-45a0-993d-83d0655d0fff	contract	Fixed-Term Contract	\N	\N	2026-08-27	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
18e76c8c-d5fd-4617-a78f-36a210a299cc	db8b3402-39f2-455b-8d28-4d8279ca46c0	92558eff-94d2-4abb-9c7e-5e1dd0faa398	contract	Contractor Agreement	\N	\N	2026-04-19	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a3416d38-7232-427b-a257-269d403be473	db8b3402-39f2-455b-8d28-4d8279ca46c0	92558eff-94d2-4abb-9c7e-5e1dd0faa398	right_to_work	UK Right to Work	\N	\N	2027-10-21	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7f906ab5-6625-4947-8b3f-e04f0dd97ecc	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	certification	TensorFlow Developer Cert	\N	\N	2026-11-25	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ea019059-782e-4744-86ad-73063df0fb47	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	certification	GCP Professional Data Eng	\N	\N	2026-02-08	expired	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f8192e41-51e7-48ee-a63d-0a70a43eaa87	db8b3402-39f2-455b-8d28-4d8279ca46c0	351b506c-39db-4960-bd2f-ffa52ca3bc87	contract	Fixed-Term Contract	\N	\N	2026-05-04	expiring_soon	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
27c31fd2-7e94-489e-bd1c-2451904ac5e4	db8b3402-39f2-455b-8d28-4d8279ca46c0	351b506c-39db-4960-bd2f-ffa52ca3bc87	dbs_check	DBS Basic Check	\N	\N	2027-02-13	active	[90, 60, 30, 14, 7]	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: custom_field_values; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.custom_field_values (id, value, field_id, task_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.custom_fields (id, name, field_type, options, sort_order, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: development_goals; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.development_goals (id, plan_id, title, description, goal_type, linked_competency_id, target_date, status, evidence, cost_estimate, created_at, updated_at) FROM stdin;
7f907bc1-14af-4711-ac16-a2e0e2491e03	e82034b1-df23-4d42-a587-ad1f7cd60f53	Complete TOGAF certification	\N	training	\N	2026-04-29	in_progress	\N	2500	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
62c73a35-ae32-4527-9c73-a8b15b8de8e4	e82034b1-df23-4d42-a587-ad1f7cd60f53	Lead architecture review board	\N	experience	\N	2026-05-29	not_started	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5b4b573f-c1f7-4714-bdc0-5ef5be87c1af	e82034b1-df23-4d42-a587-ad1f7cd60f53	Present at QCon conference	\N	experience	\N	2026-01-29	completed	\N	1200	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4f89dd52-2078-4896-abf0-cbfe7e8b2d59	e2161477-c836-42aa-a56b-3a333be48566	Complete system design course	\N	training	\N	2026-04-14	in_progress	\N	800	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5e39719c-3191-4542-a140-702b5e1bc65f	e2161477-c836-42aa-a56b-3a333be48566	Lead cross-team feature delivery	\N	experience	\N	2026-06-28	not_started	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
653ae5d9-fd3f-4e47-8ea8-687112326577	e2161477-c836-42aa-a56b-3a333be48566	Mentor two junior developers	\N	mentoring	\N	2026-05-29	in_progress	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c20e64e5-e310-4ace-acc9-e32fc1d82d3c	49766c90-edc3-47d0-a575-5320bd78eda4	AWS Solutions Architect certification	\N	qualification	\N	2026-05-14	in_progress	\N	300	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
736e70f8-eddd-4ce4-8b45-2ca2e063ed4e	49766c90-edc3-47d0-a575-5320bd78eda4	Contribute to open-source project	\N	project	\N	2026-02-13	completed	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
529fd682-9b22-4788-949b-d2f2586d1785	f1cb61ac-e7c8-4dad-ba83-ee822f3e8ce6	Complete Nielsen Norman UX certification	\N	qualification	\N	2026-06-08	not_started	\N	4000	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0bc61ac8-73b4-4ef9-a0f9-d246cd7ff31d	f1cb61ac-e7c8-4dad-ba83-ee822f3e8ce6	Run 5 user research sessions	\N	experience	\N	2026-04-29	in_progress	\N	500	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
57ef3fee-0941-48a9-acac-ae882ad73f78	f1cb61ac-e7c8-4dad-ba83-ee822f3e8ce6	Build design system component library	\N	project	\N	2026-05-29	in_progress	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ab014be0-88a4-4333-a8ea-15dc256cacb2	6132bd9b-d763-4041-9465-11ea955e1f31	Google Ads certification	\N	training	\N	2026-02-08	completed	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
01832af2-217b-4c5c-8624-8478557c028d	6132bd9b-d763-4041-9465-11ea955e1f31	Run first A/B testing programme	\N	project	\N	2026-04-14	in_progress	\N	2000	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e811c471-9efd-40ba-9589-611f483f6e54	68214d8e-ded6-4724-aa42-8a476cea9969	CKA Kubernetes certification	\N	qualification	\N	2026-04-19	in_progress	\N	395	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
75e2929e-be38-4d1d-a2a4-f7e4e7bfdbf8	68214d8e-ded6-4724-aa42-8a476cea9969	Build internal platform tooling	\N	project	\N	2026-06-28	not_started	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7c7c15f3-8617-4e11-9e8c-1b65381818a7	c7969653-6147-45ed-baa3-0b442060c4d5	Attend Figma Config conference	\N	training	\N	2026-01-14	completed	\N	800	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
04fd28dc-19e9-4742-ab1d-9581f05acb61	c7969653-6147-45ed-baa3-0b442060c4d5	Shadow product manager for a sprint	\N	mentoring	\N	2026-03-30	in_progress	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e2f070e8-746c-4582-80bf-b2dd0e9a6c51	ec3220cf-1a27-4a18-a55b-6f622f20938e	Complete content strategy course	\N	training	\N	2026-04-29	in_progress	\N	600	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
142a6c1e-8047-4ee4-9b2f-4c318a0cad53	cb47371a-9abf-4c1c-babf-fd2ed0823bee	Full-stack project ownership end-to-end	\N	experience	\N	2026-05-29	in_progress	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b8abf148-4680-4b0d-9d7e-b225bd621527	cb47371a-9abf-4c1c-babf-fd2ed0823bee	Complete React Advanced workshop	\N	training	\N	2026-02-18	completed	\N	450	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2ec3f9b3-33c5-4ce7-a089-52bc88ce2201	516a7b7b-751c-4b1f-a149-75156622b5d3	HashiCorp Terraform Associate cert	\N	qualification	\N	2026-05-19	not_started	\N	250	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6cac4e54-9ee9-45ff-bb19-321d20af2b48	516a7b7b-751c-4b1f-a149-75156622b5d3	Lead incident response improvements	\N	experience	\N	2026-04-29	in_progress	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8aa25a3d-b43f-4032-b72c-bba51a2eb234	46194204-5e16-4446-9d76-6ac6e4be5608	Run design sprint workshops	\N	experience	\N	2026-06-08	not_started	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
774c4e1e-a0c7-4554-b253-cf4f75c0b90e	620770b9-9150-47ad-9067-164c16e84b81	Product analytics deep-dive course	\N	training	\N	2026-04-14	in_progress	\N	900	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e4b388ff-adde-4642-8d3e-bfd529cb53fe	620770b9-9150-47ad-9067-164c16e84b81	Present strategy to exec team	\N	experience	\N	2026-05-29	not_started	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
860cb911-86ad-40b5-9e67-a0265a842b6f	6150ea52-d57b-4438-9d32-6ac8dba29e9f	Databricks certified associate	\N	qualification	\N	2026-04-24	in_progress	\N	300	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1d506955-435e-4337-bb49-3e185ef1ba8b	6150ea52-d57b-4438-9d32-6ac8dba29e9f	Build automated data quality pipeline	\N	project	\N	2026-06-28	not_started	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d2ba62ff-d8bb-4153-ab13-7219ca9b9ff8	4a0b5f5f-3c65-4a03-8f31-9a1d91aa1966	SEO masterclass certification	\N	training	\N	2026-02-03	completed	\N	200	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6c610875-f46e-4faa-8845-c005142af02d	223fc369-e763-4442-a905-5549450873e7	Pragmatic Institute PMC cert	\N	qualification	\N	2026-06-08	not_started	\N	2800	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3f702cf6-ad1f-4e68-b3a8-1d744e353429	262f3d91-c2fd-439b-ba89-23856b278741	OSCP certification	\N	qualification	\N	2026-05-29	in_progress	\N	1599	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
25ca12da-84a1-4912-bdf3-eefafd021fdf	262f3d91-c2fd-439b-ba89-23856b278741	Lead red team exercise	\N	experience	\N	2026-06-28	not_started	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
02f86f7d-bb46-49ba-b3fe-43680e3ce7ce	4692bd29-b102-4cfc-97cb-45a86bc082ea	SQL and data analysis bootcamp	\N	training	\N	2026-03-30	in_progress	\N	400	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d072519d-da59-4ea8-972a-e84f19c69515	e658caca-6643-465b-b479-0dd3fade3266	Framer and prototyping masterclass	\N	training	\N	2026-04-29	not_started	\N	350	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8a2a46c9-50d1-43d0-abf8-3723b213265a	7e4c09bd-593d-443d-b1ad-40d137e8b5f3	MLOps specialisation (Coursera)	\N	training	\N	2026-05-14	in_progress	\N	500	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7189331c-d5b7-4b6c-9b99-1cdaaebbe7a2	7e4c09bd-593d-443d-b1ad-40d137e8b5f3	Publish internal ML best practices guide	\N	project	\N	2026-05-29	not_started	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3db58f2c-a10a-4656-828c-2f538bec146c	a769836b-b81f-4098-995b-9b06e5fdfb7e	Marketing automation certification	\N	training	\N	2026-05-19	not_started	\N	300	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: development_plans; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.development_plans (id, workspace_id, user_id, review_period_id, status, career_aspiration, created_at, updated_at) FROM stdin;
e82034b1-df23-4d42-a587-ad1f7cd60f53	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	269b6650-10f8-4a31-9f22-b15dc53f1456	active	CTO	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e2161477-c836-42aa-a56b-3a333be48566	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Tech Lead	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
49766c90-edc3-47d0-a575-5320bd78eda4	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Principal Engineer	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f1cb61ac-e7c8-4dad-ba83-ee822f3e8ce6	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Design Director	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6132bd9b-d763-4041-9465-11ea955e1f31	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	269b6650-10f8-4a31-9f22-b15dc53f1456	active	CMO	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
68214d8e-ded6-4724-aa42-8a476cea9969	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Staff Engineer	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c7969653-6147-45ed-baa3-0b442060c4d5	db8b3402-39f2-455b-8d28-4d8279ca46c0	76d17f64-9249-46dc-aa2e-97c127c4c0b0	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Head of Design	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ec3220cf-1a27-4a18-a55b-6f622f20938e	db8b3402-39f2-455b-8d28-4d8279ca46c0	77f58837-3712-4af6-b549-4de11804561d	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Content Director	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cb47371a-9abf-4c1c-babf-fd2ed0823bee	db8b3402-39f2-455b-8d28-4d8279ca46c0	63e3e230-8516-4cb7-b323-440cf28fe175	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Architect	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
516a7b7b-751c-4b1f-a149-75156622b5d3	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Site Reliability Lead	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
46194204-5e16-4446-9d76-6ac6e4be5608	db8b3402-39f2-455b-8d28-4d8279ca46c0	9bdd4897-c917-4304-bbc4-cf6ee4579def	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Head of Product Design	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
620770b9-9150-47ad-9067-164c16e84b81	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	269b6650-10f8-4a31-9f22-b15dc53f1456	active	VP Product	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6150ea52-d57b-4438-9d32-6ac8dba29e9f	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Data Engineering Lead	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4a0b5f5f-3c65-4a03-8f31-9a1d91aa1966	db8b3402-39f2-455b-8d28-4d8279ca46c0	5eb86614-6fc0-49ac-97e3-601d92788d24	269b6650-10f8-4a31-9f22-b15dc53f1456	active	Head of Digital	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
223fc369-e763-4442-a905-5549450873e7	db8b3402-39f2-455b-8d28-4d8279ca46c0	86e6ea5d-5142-4c37-b94f-af48785430c9	269b6650-10f8-4a31-9f22-b15dc53f1456	draft	CPO	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
262f3d91-c2fd-439b-ba89-23856b278741	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	269b6650-10f8-4a31-9f22-b15dc53f1456	draft	CISO	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4692bd29-b102-4cfc-97cb-45a86bc082ea	db8b3402-39f2-455b-8d28-4d8279ca46c0	e78e0255-f170-45a0-993d-83d0655d0fff	269b6650-10f8-4a31-9f22-b15dc53f1456	draft	Senior Analyst	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e658caca-6643-465b-b479-0dd3fade3266	db8b3402-39f2-455b-8d28-4d8279ca46c0	92558eff-94d2-4abb-9c7e-5e1dd0faa398	269b6650-10f8-4a31-9f22-b15dc53f1456	completed	Creative Director	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7e4c09bd-593d-443d-b1ad-40d137e8b5f3	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	269b6650-10f8-4a31-9f22-b15dc53f1456	completed	Chief Data Officer	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a769836b-b81f-4098-995b-9b06e5fdfb7e	db8b3402-39f2-455b-8d28-4d8279ca46c0	351b506c-39db-4960-bd2f-ffa52ca3bc87	269b6650-10f8-4a31-9f22-b15dc53f1456	archived	Marketing Director	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: key_results; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.key_results (id, objective_id, title, description, target_value, current_value, unit, measurement_type, created_at, updated_at) FROM stdin;
9bb6f919-7348-4f09-aec3-4953aa74b15b	0e072964-178b-4332-a28e-5bed4280b8f5	P95 latency < 200ms	\N	200	280	ms	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
592cfa48-ae05-48e0-a85e-131d286eae01	0e072964-178b-4332-a28e-5bed4280b8f5	P99 latency < 500ms	\N	500	620	ms	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
249c309d-7254-43b1-b65a-bc5863a58bf6	74482f2b-620c-45e0-b685-40b52c0da429	Complete App Store submission	\N	1	0	milestone	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2a5f0e5f-c973-4291-9c43-c8f11be5d26c	74482f2b-620c-45e0-b685-40b52c0da429	Pass all QA regression tests	\N	100	78	%	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
75d21fb1-a41f-44ab-9655-27a5981ee002	74b857f7-7b67-476f-b006-c298f75a47e8	Core module coverage >= 90%	\N	90	72	%	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
858ab4a5-ce17-4e21-96e1-3fc6607dbc4b	74b857f7-7b67-476f-b006-c298f75a47e8	Zero critical untested paths	\N	0	3	count	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bee51252-eb36-41b7-8b18-24578c5f7b75	063f1432-0b15-4bfb-b660-dfc0b74dc1a8	User testing score >= 4.5	\N	4.5	3.2	score	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
eaf38919-d839-4206-b24e-055b25961e3f	063f1432-0b15-4bfb-b660-dfc0b74dc1a8	Reduce onboarding drop-off to <10%	\N	10	22	%	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
be0bcc48-34a5-4ca1-8496-70b3f3e3675a	deae23ef-f161-4147-8c4e-f9de1eae8707	Automated a11y scan pass rate 100%	\N	100	65	%	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fb6528ee-f392-48f5-a8ff-380291d205b4	624a36cc-4fb6-453d-9a18-5cac07953f7e	Mean deploy time < 300s	\N	300	380	seconds	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
381bd9a5-c6bc-4e49-87a5-089a56c9d515	624a36cc-4fb6-453d-9a18-5cac07953f7e	Zero failed deployments per sprint	\N	0	1	count	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
274139d8-2a90-43fe-9632-fbd22d106306	9d919261-8986-4c38-84a7-2398fa6ddff4	Components documented in Storybook	\N	50	28	components	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
48e895c0-6c7c-403f-aa75-7a7d673607c3	3a766f21-47a1-4263-b5aa-b3efbb010eed	Security audit findings resolved	\N	0	4	count	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2553e0e1-5f44-475d-bf32-7380212fe115	3a766f21-47a1-4263-b5aa-b3efbb010eed	Penetration test pass rate	\N	100	85	%	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
500b4886-93a3-4086-8a7e-96e773b74ba4	0bab5d76-9a44-40cf-a6d3-71f8409b4449	Dashboard MAU > 500	\N	500	230	users	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b259fe89-2fa5-4680-818d-3c76253e7ce4	141d5de7-95e1-4164-83da-9cd8e64d2291	Discovery sessions per quarter	\N	12	3	sessions	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c0f8f274-e467-4db4-8265-8b85f4a76f2f	0f516828-2214-44a1-8033-ed359261c327	Legacy services containerised	\N	8	6	services	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cbc59205-d1af-4c39-b0ae-a24318ac161e	2c4b733e-10ee-4417-b9ad-2f007827691c	CI build time < 3 minutes	\N	180	195	seconds	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bf7e3f13-9d6c-4bb8-b39f-4f096559bd04	694319f1-d600-4739-b1e7-f06e648096f2	Slow queries eliminated	\N	0	12	count	numeric	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: kudos; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.kudos (id, workspace_id, from_user_id, to_user_id, message, created_at, updated_at) FROM stdin;
f089feb5-0ca9-4c6e-baa5-6f54901587d4	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	Outstanding work on the API migration — zero downtime!	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
613bbd52-991f-444c-abd4-157333717b9d	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	Thanks for the thorough code review, caught a nasty bug	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d02cfcb8-eb08-469d-952a-c257ebde4ece	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	76d17f64-9249-46dc-aa2e-97c127c4c0b0	The new dashboard designs are absolutely brilliant	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9c41dd59-efa2-457f-8855-34f748e89a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	a13df553-f991-456a-9401-7c90bc033e88	Love the new design system — it's transformed our velocity	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
78550e99-085d-48af-9b43-cd10fc65b8ff	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	4ac83d84-43e6-4389-bf01-f0c0251affb9	Thanks for unblocking the deployment pipeline issue	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
255d3b9a-921b-4d68-8fcf-a2d5d5d8c576	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	77f58837-3712-4af6-b549-4de11804561d	Great blog post — the engagement numbers are incredible	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1ca4602b-4af3-406b-a8e0-8f6720641bea	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	edc56289-b344-42c3-a6a3-4d3e014d5812	Your Kubernetes setup saved us hours of debugging	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
86143d97-16d3-47be-9107-570a20a98116	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	63e3e230-8516-4cb7-b323-440cf28fe175	Brilliant full-stack work on the customer portal	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2dd6bbe3-0481-491a-82b9-8fbc357d6e45	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	86e6ea5d-5142-4c37-b94f-af48785430c9	Excellent product discovery work — really insightful	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
942f9d4f-4f26-45bc-a2f1-afd463b3d891	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	9bdd4897-c917-4304-bbc4-cf6ee4579def	Beautiful component library — the team loves it	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8130f323-8223-40c3-8444-cc9a4c415721	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	dd572bbc-6f68-4046-98b8-36ebbe945667	Thanks for the quick incident response last night	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
99c85c6e-9164-4813-a0c4-e70f15d198f8	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	91e53610-e137-45b7-8dba-974c0953926f	The security audit report was exceptional work	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1a291985-dc56-4292-b0a0-cf60d5ded924	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	5eb86614-6fc0-49ac-97e3-601d92788d24	Great social media campaign — best metrics this quarter	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4c7866c9-0d19-4238-a413-23ea823c2a9e	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	Solid data pipeline work — love the monitoring you added	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c4bd781e-757f-4ff8-b432-93270779bd64	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	6b3a2241-2175-4fb2-b7c6-552996ec1cce	Impressive ML model accuracy — well researched approach	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
241b5723-7252-42ff-b4e1-6e8e666a2c3e	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	e78e0255-f170-45a0-993d-83d0655d0fff	Great analysis work — really helped shape the roadmap	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
74d714d4-7744-4431-8bad-c87d37307ff6	db8b3402-39f2-455b-8d28-4d8279ca46c0	76d17f64-9249-46dc-aa2e-97c127c4c0b0	92558eff-94d2-4abb-9c7e-5e1dd0faa398	Stunning UI work on the new feature — pixel perfect	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b4eee0d0-f842-4a60-8a1a-8bd1babaadd0	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	Excellent product strategy presentation to the board	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7dce6f6d-e2d8-4074-b6e5-dc6b9f4fa12a	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	dd572bbc-6f68-4046-98b8-36ebbe945667	Thanks for the Terraform modules — massive time saver	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6bc6ac8f-e0b8-4abb-b53b-58d023495cb0	db8b3402-39f2-455b-8d28-4d8279ca46c0	77f58837-3712-4af6-b549-4de11804561d	549dd47f-510d-4315-aa26-8dc131f272b2	Brilliant campaign strategy — exceeding all targets	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: leave_allowances; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.leave_allowances (id, workspace_id, user_id, year, entitlement_days, carried_forward, used_days, booked_days, created_at, updated_at) FROM stdin;
be253097-b817-4751-8147-d3de29484e79	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026	25	0	3	0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6f70488e-975f-4a83-af47-55ea95b1f506	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	2026	25	1	4	5	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c06e70d4-db9d-49e6-a2de-4b5f18e0f879	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	2026	25	4	12	3	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0928e306-7d36-4ded-a29a-d84776943ed5	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	2026	25	3	3	3	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4e71f9f8-ac8c-4ad3-87ed-f1191a2d3d88	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	2026	25	4	11	3	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e9e1453b-2d19-431c-8cd6-4ddf5c1ad9f7	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	2026	25	0	6	4	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c169a50d-053d-4ecd-8308-a9549e16b105	db8b3402-39f2-455b-8d28-4d8279ca46c0	76d17f64-9249-46dc-aa2e-97c127c4c0b0	2026	25	0	12	5	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e66c27f2-6a71-4166-ab50-2046cf588d86	db8b3402-39f2-455b-8d28-4d8279ca46c0	77f58837-3712-4af6-b549-4de11804561d	2026	25	2	12	4	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3e7aad91-9be1-4798-b9a6-9bd7e64d9e83	db8b3402-39f2-455b-8d28-4d8279ca46c0	63e3e230-8516-4cb7-b323-440cf28fe175	2026	25	0	12	2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cc48a303-d6de-4383-94d0-62ba621bdc46	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	2026	25	1	6	3	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
62d294bf-4435-4ca3-8761-322e05a174e1	db8b3402-39f2-455b-8d28-4d8279ca46c0	9bdd4897-c917-4304-bbc4-cf6ee4579def	2026	25	5	9	0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3abfac87-4185-4a14-947f-0146e22ecaf9	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	2026	25	1	6	4	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
87084a3b-c945-4509-85da-4070ae383108	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	2026	25	5	10	0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f855c243-ca4b-4e8d-a6fe-2e9d9b1b4c9c	db8b3402-39f2-455b-8d28-4d8279ca46c0	5eb86614-6fc0-49ac-97e3-601d92788d24	2026	25	4	6	5	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6437fdb0-3b1e-44d2-b872-441956044126	db8b3402-39f2-455b-8d28-4d8279ca46c0	86e6ea5d-5142-4c37-b94f-af48785430c9	2026	25	1	11	1	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
401518ab-40f4-4e87-b949-3ef82b6d3e9a	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	2026	20	4	7	1	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d910eb13-bb3a-4c0a-b4a2-d2a5135736e7	db8b3402-39f2-455b-8d28-4d8279ca46c0	e78e0255-f170-45a0-993d-83d0655d0fff	2026	20	4	10	0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9edf96d2-6a90-4467-81d8-04488c06d34a	db8b3402-39f2-455b-8d28-4d8279ca46c0	92558eff-94d2-4abb-9c7e-5e1dd0faa398	2026	20	0	7	3	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3d374d29-8368-4db6-b48f-a0e44bb53b17	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	2026	20	2	3	2	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
eb702f57-8df7-472c-b7e5-02d02942a528	db8b3402-39f2-455b-8d28-4d8279ca46c0	351b506c-39db-4960-bd2f-ffa52ca3bc87	2026	20	1	5	0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: leave_requests; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.leave_requests (id, workspace_id, user_id, leave_type, start_date, end_date, days, status, approved_by, notes, created_at, updated_at) FROM stdin;
d79dc391-bb8e-478c-89a2-4b0b405a29fd	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	annual	2026-03-05	2026-03-10	5	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ba7092a1-f863-49f1-a3b2-db5ffb927ff0	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	annual	2026-04-09	2026-04-11	2	pending	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
aaab763f-57ff-42f0-8815-c641ff69b258	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	sick	2026-02-25	2026-02-27	3	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
728fa6bf-4966-4131-b927-58a6e939a31d	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	annual	2026-03-14	2026-03-21	5	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
58691453-19ee-49fc-bb4b-97bc280b019e	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	training	2026-04-04	2026-04-05	2	pending	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
aa15aaa1-3fbe-4a34-9cbd-65ef4532052f	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	annual	2026-03-07	2026-03-14	5	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6800bffb-533a-4e4c-84fd-07300ca09c77	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	toil	2026-03-03	2026-03-03	1	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ac85dbae-bc73-4791-b624-70b7d9d35a46	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	annual	2026-03-20	2026-03-27	5	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c502e297-3f22-40b9-9d85-981b3cd806d5	db8b3402-39f2-455b-8d28-4d8279ca46c0	76d17f64-9249-46dc-aa2e-97c127c4c0b0	annual	2026-03-10	2026-03-12	2	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
58fb32f5-e31d-4e8a-8b01-ff692a886d4d	db8b3402-39f2-455b-8d28-4d8279ca46c0	77f58837-3712-4af6-b549-4de11804561d	sick	2026-02-23	2026-02-24	2	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
46038a32-7a5d-49d1-8e28-cc3aec72ad94	db8b3402-39f2-455b-8d28-4d8279ca46c0	63e3e230-8516-4cb7-b323-440cf28fe175	annual	2026-03-30	2026-04-04	4	pending	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
548824c1-04c6-4dac-bdea-07930f616de3	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	annual	2026-03-15	2026-03-19	4	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0f64c71e-5535-40d6-9290-2553a5eadcf4	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	compassionate	2026-04-14	2026-04-16	3	pending	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6dcbf77c-9e7d-42f4-b271-cefb539bffed	db8b3402-39f2-455b-8d28-4d8279ca46c0	9bdd4897-c917-4304-bbc4-cf6ee4579def	annual	2026-03-08	2026-03-12	4	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cebf26d3-5c90-4584-827e-39ff8828aa44	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	training	2026-03-25	2026-03-27	3	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
17b1b68b-cd18-452b-8d2a-d34bf4e6f466	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	annual	2026-03-18	2026-03-22	4	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b6176e80-fd51-46a2-bf46-08a2dac8397e	db8b3402-39f2-455b-8d28-4d8279ca46c0	5eb86614-6fc0-49ac-97e3-601d92788d24	annual	2026-03-05	2026-03-09	4	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
92eeca18-1e9f-4a4a-b0db-33863e48490a	db8b3402-39f2-455b-8d28-4d8279ca46c0	86e6ea5d-5142-4c37-b94f-af48785430c9	sick	2026-02-26	2026-02-27	2	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c2627846-d007-4e80-b88a-106a53b34b23	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	annual	2026-04-19	2026-04-24	4	pending	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e7224c21-19b2-4a93-ae56-1c6fbce7c8ed	db8b3402-39f2-455b-8d28-4d8279ca46c0	e78e0255-f170-45a0-993d-83d0655d0fff	annual	2026-03-12	2026-03-14	2	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4a16dcc2-20b9-4089-9726-8d5120f535e8	db8b3402-39f2-455b-8d28-4d8279ca46c0	92558eff-94d2-4abb-9c7e-5e1dd0faa398	unpaid	2026-03-30	2026-04-03	5	pending	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
60b5ddab-8ace-4c92-9c99-08eede97fb02	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	annual	2026-03-22	2026-03-26	4	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
eab530c2-0407-4c81-a040-87fa798b2612	db8b3402-39f2-455b-8d28-4d8279ca46c0	351b506c-39db-4960-bd2f-ffa52ca3bc87	annual	2026-03-06	2026-03-08	2	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
21d6a1f2-03fe-4c7c-ba29-72b6deb44a3e	db8b3402-39f2-455b-8d28-4d8279ca46c0	351b506c-39db-4960-bd2f-ffa52ca3bc87	sick	2026-02-21	2026-02-23	3	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2bf06b78-f7ba-4b6d-ad3f-9817612c696b	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	compassionate	2026-04-24	2026-04-26	3	pending	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8cb1fff8-d64a-46d0-b69b-aefbadec7937	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	training	2026-04-29	2026-05-01	3	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c8cf605e-fa5b-4973-adf2-bf46ed6022b4	db8b3402-39f2-455b-8d28-4d8279ca46c0	63e3e230-8516-4cb7-b323-440cf28fe175	annual	2026-05-04	2026-05-11	5	pending	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
dc843cf7-bdf0-4231-9bfa-1d8c234d193c	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	sick	2026-02-27	2026-02-27	1	approved	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: meeting_actions; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.meeting_actions (id, meeting_id, title, status, owner_id, carried_from_id, created_at, updated_at) FROM stdin;
d77cf8b6-cf26-46e6-b059-632d8b77aeae	39ba61b9-69c3-40ba-860b-f406cdb03495	Follow up on deployment pipeline	done	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d3eaf623-a3bc-4783-abf7-7e44fe4eaee9	39ba61b9-69c3-40ba-860b-f406cdb03495	Review PR backlog	done	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
86241c16-31fa-4644-9aad-9122b63fc65c	59c2040f-2278-4a09-a1f4-dc46f8212874	Schedule design review	done	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1f1df057-ed04-4b16-8fe4-82d996de8768	59c2040f-2278-4a09-a1f4-dc46f8212874	Update project timeline	done	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
05cbc048-cc0d-421a-9ac6-93b87479dd74	aedb7016-9202-4688-98b2-569a2cd673f1	Prepare training materials	done	a13df553-f991-456a-9401-7c90bc033e88	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
13a489fd-12c6-415b-abb6-199a18c68103	aedb7016-9202-4688-98b2-569a2cd673f1	Set up monitoring dashboards	done	a13df553-f991-456a-9401-7c90bc033e88	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d51cbe07-407b-47c0-b881-59ae025da976	64b60df7-21a3-4266-ba1e-7ca5140288af	Review code coverage targets	done	549dd47f-510d-4315-aa26-8dc131f272b2	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b0f2858e-c487-4580-8912-a098eae0e09e	64b60df7-21a3-4266-ba1e-7ca5140288af	Investigate CI failures	done	549dd47f-510d-4315-aa26-8dc131f272b2	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ff906e83-b398-44a1-ae95-13d5e6bdc6d7	8e0593e2-a94d-45fd-8861-37b636d49fd6	Draft career development plan	done	edc56289-b344-42c3-a6a3-4d3e014d5812	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b52c91a7-5738-41be-a92a-1881b8e3870f	8e0593e2-a94d-45fd-8861-37b636d49fd6	Book team retrospective	done	edc56289-b344-42c3-a6a3-4d3e014d5812	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7152e676-b6c7-475a-811a-55f56ac74ea4	147b9a2a-acbc-42d7-8ffe-9ce736fdad4e	Chase vendor for licence renewal	done	edc56289-b344-42c3-a6a3-4d3e014d5812	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c95fff29-249d-49ec-a94e-79b39e22c365	147b9a2a-acbc-42d7-8ffe-9ce736fdad4e	Prepare sprint demo	done	edc56289-b344-42c3-a6a3-4d3e014d5812	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
12044304-4bff-43d1-a6a3-a0bd1c0276e0	6699a7fe-269f-4f6c-9599-dcc1fd7f8eb9	Update risk register	done	63e3e230-8516-4cb7-b323-440cf28fe175	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1a8f38f7-bc62-4cf0-bc84-e1a2e3004385	6699a7fe-269f-4f6c-9599-dcc1fd7f8eb9	Arrange knowledge-sharing session	done	63e3e230-8516-4cb7-b323-440cf28fe175	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e412fe88-9644-4c2c-ae9c-ea2b01d894b7	918de184-c853-4d3e-b796-94532666ac74	Write onboarding docs for new starters	done	dd572bbc-6f68-4046-98b8-36ebbe945667	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a026c23d-a3c8-4ba6-9286-ccdd8c9ab926	918de184-c853-4d3e-b796-94532666ac74	Review budget forecast	done	dd572bbc-6f68-4046-98b8-36ebbe945667	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a04545a9-d4b7-4ea1-b2cc-fe31124dc93c	216be0ea-7e2b-492c-8890-cebf7b1db86f	Follow up on deployment pipeline	done	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d5f059e4-db20-43bd-bc4f-e6ee532e06fd	216be0ea-7e2b-492c-8890-cebf7b1db86f	Review PR backlog	done	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9c191289-11b0-4124-b5f5-eb94130535b6	ff1b5c4c-cb5e-4cc1-864f-c0dd93980987	Schedule design review	done	6b3a2241-2175-4fb2-b7c6-552996ec1cce	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a1781d1c-2a1b-4c66-97de-ba2a7a20f106	ff1b5c4c-cb5e-4cc1-864f-c0dd93980987	Update project timeline	done	6b3a2241-2175-4fb2-b7c6-552996ec1cce	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
11b2f79f-4d41-40d1-a83e-ea8e707fa618	f3d51b2e-648d-4801-b74b-8fd94d486031	Prepare training materials	open	76d17f64-9249-46dc-aa2e-97c127c4c0b0	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5ae6e56a-951c-4dcb-8ff2-76a5e41d16ba	f3d51b2e-648d-4801-b74b-8fd94d486031	Set up monitoring dashboards	open	76d17f64-9249-46dc-aa2e-97c127c4c0b0	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0b9c26e2-7a07-472e-b458-2e9b2e944afe	8211ba93-a0c2-4d67-a9d1-c770f4354013	Review code coverage targets	open	9bdd4897-c917-4304-bbc4-cf6ee4579def	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e554e1c1-d09c-4f7f-b59b-4b6e7b586dff	8211ba93-a0c2-4d67-a9d1-c770f4354013	Investigate CI failures	open	9bdd4897-c917-4304-bbc4-cf6ee4579def	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
70462904-c725-45ae-b35c-b8a92d621b49	5f7dbd62-4df5-4bf2-8870-0c8766d1744f	Draft career development plan	open	92558eff-94d2-4abb-9c7e-5e1dd0faa398	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
15a05e2a-8d6b-4f07-820a-b546bd1e6f39	5f7dbd62-4df5-4bf2-8870-0c8766d1744f	Book team retrospective	open	92558eff-94d2-4abb-9c7e-5e1dd0faa398	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0018b1dc-b2e5-45af-a089-3d0b60e87328	4e1ef401-1059-411c-8fc1-aa533067b6d3	Chase vendor for licence renewal	open	77f58837-3712-4af6-b549-4de11804561d	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3ce2d667-a0bf-44e9-bd8e-c17e57ebaabc	4e1ef401-1059-411c-8fc1-aa533067b6d3	Prepare sprint demo	open	77f58837-3712-4af6-b549-4de11804561d	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: meetings; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.meetings (id, workspace_id, manager_id, report_id, scheduled_date, actual_date, notes, mood, status, created_at, updated_at) FROM stdin;
39ba61b9-69c3-40ba-860b-f406cdb03495	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	2025-12-20	2025-12-20	Regular 1:1 — discussed progress and blockers	good	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
59c2040f-2278-4a09-a1f4-dc46f8212874	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	2025-12-27	2025-12-27	Regular 1:1 — discussed progress and blockers	neutral	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
aedb7016-9202-4688-98b2-569a2cd673f1	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	a13df553-f991-456a-9401-7c90bc033e88	2026-01-03	2026-01-03	Regular 1:1 — discussed progress and blockers	good	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
64b60df7-21a3-4266-ba1e-7ca5140288af	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	549dd47f-510d-4315-aa26-8dc131f272b2	2026-01-10	2026-01-10	Regular 1:1 — discussed progress and blockers	concern	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8e0593e2-a94d-45fd-8861-37b636d49fd6	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	edc56289-b344-42c3-a6a3-4d3e014d5812	2026-01-17	2026-01-17	Regular 1:1 — discussed progress and blockers	good	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
147b9a2a-acbc-42d7-8ffe-9ce736fdad4e	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	edc56289-b344-42c3-a6a3-4d3e014d5812	2026-01-24	2026-01-24	Regular 1:1 — discussed progress and blockers	good	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6699a7fe-269f-4f6c-9599-dcc1fd7f8eb9	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	63e3e230-8516-4cb7-b323-440cf28fe175	2026-01-31	2026-01-31	Regular 1:1 — discussed progress and blockers	neutral	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
918de184-c853-4d3e-b796-94532666ac74	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	dd572bbc-6f68-4046-98b8-36ebbe945667	2026-02-07	2026-02-07	Regular 1:1 — discussed progress and blockers	good	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
216be0ea-7e2b-492c-8890-cebf7b1db86f	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	2026-02-14	2026-02-14	Regular 1:1 — discussed progress and blockers	good	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ff1b5c4c-cb5e-4cc1-864f-c0dd93980987	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	6b3a2241-2175-4fb2-b7c6-552996ec1cce	2026-02-21	2026-02-21	Regular 1:1 — discussed progress and blockers	neutral	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f3d51b2e-648d-4801-b74b-8fd94d486031	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	76d17f64-9249-46dc-aa2e-97c127c4c0b0	2026-02-28	2026-02-28	Regular 1:1 — discussed progress and blockers	good	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8211ba93-a0c2-4d67-a9d1-c770f4354013	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	9bdd4897-c917-4304-bbc4-cf6ee4579def	2026-03-07	2026-03-07	Regular 1:1 — discussed progress and blockers	concern	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5f7dbd62-4df5-4bf2-8870-0c8766d1744f	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	92558eff-94d2-4abb-9c7e-5e1dd0faa398	2026-03-14	2026-03-14	Regular 1:1 — discussed progress and blockers	good	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4e1ef401-1059-411c-8fc1-aa533067b6d3	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	77f58837-3712-4af6-b549-4de11804561d	2026-03-21	2026-03-21	Regular 1:1 — discussed progress and blockers	good	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c77de6d2-2335-4fc8-be82-721c1b2c0da5	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	5eb86614-6fc0-49ac-97e3-601d92788d24	2026-03-07	\N	\N	\N	scheduled	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
afd68183-2126-43c4-91d1-160e08095a3a	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	351b506c-39db-4960-bd2f-ffa52ca3bc87	2026-03-14	\N	\N	\N	scheduled	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
40323735-3fa0-4f25-9257-5440f19f0db3	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	86e6ea5d-5142-4c37-b94f-af48785430c9	2026-03-21	\N	\N	\N	scheduled	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
48419263-2766-496e-97a5-f0218b1e7ee2	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	e78e0255-f170-45a0-993d-83d0655d0fff	2026-03-28	\N	\N	\N	scheduled	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
497c0ce4-dcd3-4636-8ee1-ea3e9b076bec	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	2026-04-04	\N	\N	\N	scheduled	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cec6fc4a-ddb3-438c-ad6b-3a72a3771035	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	91e53610-e137-45b7-8dba-974c0953926f	2026-04-11	\N	\N	\N	scheduled	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.milestones (id, name, date, colour, project_id, workspace_id, created_at, updated_at) FROM stdin;
a9ce05e1-82ea-4a03-9bda-c504c2d04a9c	Sprint 1 Complete	2026-03-07	#E44332	1d608927-ac67-4709-8a0b-6a223c6664f7	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e27f2cd3-94f9-4677-a15c-4c03d3ed5495	Beta Release	2026-03-14	#4186E0	fb66b6be-22c3-4a61-9430-c4dc7b8b2f3d	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
72c92539-d127-4cf5-8c80-f4bb053d6599	Launch Day	2026-03-21	#5CBF4D	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.notifications (id, user_id, workspace_id, event_type, title, body, is_read, link, actor_id, task_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: objectives; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.objectives (id, workspace_id, user_id, review_period_id, parent_id, title, description, category, status, progress, weight, created_at, updated_at) FROM stdin;
0e072964-178b-4332-a28e-5bed4280b8f5	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Reduce API P95 latency below 200ms	\N	performance	active	65	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
74482f2b-620c-45e0-b685-40b52c0da429	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Ship mobile app v3.0 to App Store	\N	business	active	45	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
74b857f7-7b67-476f-b006-c298f75a47e8	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Achieve 90% test coverage on core modules	\N	performance	active	70	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
063f1432-0b15-4bfb-b660-dfc0b74dc1a8	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Redesign onboarding user flow	\N	business	active	30	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
40b3b7e0-aafb-4966-ab16-d92e0ad1cf02	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Launch Q1 multi-channel marketing campaign	\N	business	completed	100	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
deae23ef-f161-4147-8c4e-f9de1eae8707	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Implement WCAG 2.1 AA accessibility across portal	\N	development	active	20	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
624a36cc-4fb6-453d-9a18-5cac07953f7e	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Reduce deployment time to under 5 minutes	\N	performance	active	80	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9d919261-8986-4c38-84a7-2398fa6ddff4	db8b3402-39f2-455b-8d28-4d8279ca46c0	76d17f64-9249-46dc-aa2e-97c127c4c0b0	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Create comprehensive design system documentation	\N	development	active	55	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0e9cc542-f4e1-4401-b5df-5010ade97b1b	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Migrate entire data layer to async	\N	performance	completed	100	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
58383219-bb55-4f1a-ac07-ae3c359db961	db8b3402-39f2-455b-8d28-4d8279ca46c0	77f58837-3712-4af6-b549-4de11804561d	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Increase social media engagement by 25%	\N	business	active	40	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3a766f21-47a1-4263-b5aa-b3efbb010eed	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Implement zero-trust security architecture	\N	performance	active	35	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0bab5d76-9a44-40cf-a6d3-71f8409b4449	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Build real-time analytics dashboard	\N	business	active	50	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
141d5de7-95e1-4164-83da-9cd8e64d2291	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Establish product discovery framework	\N	development	active	25	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bd389226-95b6-4e23-9b27-f23ac283e181	db8b3402-39f2-455b-8d28-4d8279ca46c0	86e6ea5d-5142-4c37-b94f-af48785430c9	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Reduce customer support tickets by 30%	\N	business	active	15	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e6eccc61-3763-4de9-9d40-1982d5290203	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Launch employee referral programme	\N	business	active	60	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0f516828-2214-44a1-8033-ed359261c327	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Containerise all legacy services	\N	performance	active	75	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1bd61e42-ebed-4684-a526-5f8c0500920c	db8b3402-39f2-455b-8d28-4d8279ca46c0	9bdd4897-c917-4304-bbc4-cf6ee4579def	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Design component library v2	\N	development	active	40	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
beb3d6b0-41a6-46ea-aec1-0965670b5837	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Implement automated compliance reporting	\N	performance	active	10	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
323c9460-e7fc-4a88-bc49-575943688824	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Build ML model for churn prediction	\N	business	draft	0	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2c4b733e-10ee-4417-b9ad-2f007827691c	db8b3402-39f2-455b-8d28-4d8279ca46c0	63e3e230-8516-4cb7-b323-440cf28fe175	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Migrate CI/CD to GitHub Actions	\N	performance	active	90	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0499735b-6234-4c32-8853-847e37e7b908	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Create customer feedback loop process	\N	business	active	35	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
40bfb0d9-9f4e-4aad-af07-14781abc36a2	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Develop brand guidelines v3	\N	development	active	70	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
694319f1-d600-4739-b1e7-f06e648096f2	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Optimise database query performance	\N	performance	active	55	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cf5b497f-4f53-4556-9745-e9fd9cbc4990	db8b3402-39f2-455b-8d28-4d8279ca46c0	86e6ea5d-5142-4c37-b94f-af48785430c9	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Improve NPS score from 42 to 55	\N	business	active	20	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ece0a9ff-a2bd-4df2-9e9d-81fd3ab6b7ab	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	269b6650-10f8-4a31-9f22-b15dc53f1456	\N	Reduce infrastructure costs by 20%	\N	performance	cancelled	30	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bde633c3-363a-4192-abb6-b926c1972912	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	b7e5999b-3840-4677-b972-71cc7061c5d1	\N	Launch website redesign	\N	business	completed	100	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fedaf240-a490-432d-9c40-428e69c04e00	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	b7e5999b-3840-4677-b972-71cc7061c5d1	\N	Hire 5 engineers	\N	business	completed	100	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
63e99277-1fd3-4d9b-a1ba-c8a75c395443	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	b7e5999b-3840-4677-b972-71cc7061c5d1	\N	Set up design system foundations	\N	development	completed	100	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
512fc02e-3fad-4f98-a4c0-e59f7d07d3ce	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	b7e5999b-3840-4677-b972-71cc7061c5d1	\N	Implement SSO across all products	\N	performance	completed	100	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c5f8fcc1-bdde-47c7-b808-31e09360c05d	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	b7e5999b-3840-4677-b972-71cc7061c5d1	\N	Run first pulse survey	\N	business	completed	100	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: onboarding_checklist_items; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.onboarding_checklist_items (id, checklist_id, title, description, sort_order, completed, assigned_to, created_at, updated_at) FROM stdin;
828919e3-5812-4bda-983b-9d85432077c9	89f00c6c-66da-4e0b-81bb-4a7714434b85	IT setup — laptop, monitors, peripherals	\N	0	t	e78e0255-f170-45a0-993d-83d0655d0fff	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c624a679-5d10-4658-93f4-976d449ab102	89f00c6c-66da-4e0b-81bb-4a7714434b85	Create accounts — GitHub, Jira, Slack, AWS	\N	1	t	e78e0255-f170-45a0-993d-83d0655d0fff	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
35fc7fbc-9e74-4619-92a7-f8ebc2a0220a	89f00c6c-66da-4e0b-81bb-4a7714434b85	HR induction session	\N	2	t	e78e0255-f170-45a0-993d-83d0655d0fff	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
92d7cf2c-4ea7-48cc-8546-ca19c1f7b861	89f00c6c-66da-4e0b-81bb-4a7714434b85	Meet the team lunch	\N	3	t	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
475073ba-11f7-4d38-9438-df359aa5b972	89f00c6c-66da-4e0b-81bb-4a7714434b85	Dev environment setup walkthrough	\N	4	t	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7b472b3e-fe84-4179-a78d-8e8a9ea2658a	89f00c6c-66da-4e0b-81bb-4a7714434b85	Complete security awareness training	\N	5	t	e78e0255-f170-45a0-993d-83d0655d0fff	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
04bdf7b5-11c1-464f-a407-ef25a9455176	89f00c6c-66da-4e0b-81bb-4a7714434b85	Review architecture documentation	\N	6	t	e78e0255-f170-45a0-993d-83d0655d0fff	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e5a4b45b-ff2f-4c64-a3a2-07c2d0238e26	89f00c6c-66da-4e0b-81bb-4a7714434b85	First week 1:1 with manager	\N	7	t	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f060de55-cb29-496c-af11-e030c43fbf4c	89f00c6c-66da-4e0b-81bb-4a7714434b85	Pair programming session with buddy	\N	8	f	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9ff8e306-3aed-4284-a1e0-a94540ab5b72	89f00c6c-66da-4e0b-81bb-4a7714434b85	Set initial 90-day objectives	\N	9	f	e78e0255-f170-45a0-993d-83d0655d0fff	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2fa98082-0664-4060-969c-d32e9d1d9e0b	89f00c6c-66da-4e0b-81bb-4a7714434b85	Building access and security badge	\N	10	f	e78e0255-f170-45a0-993d-83d0655d0fff	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
95c96569-6ea7-4896-910a-27a342edec4f	89f00c6c-66da-4e0b-81bb-4a7714434b85	Complete code review training	\N	11	f	e78e0255-f170-45a0-993d-83d0655d0fff	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b1723a00-8f29-478f-a1c8-7271a852ddeb	b91a5f1c-666a-411b-a18a-c8f75f722c84	IT setup — laptop and accounts	\N	0	t	351b506c-39db-4960-bd2f-ffa52ca3bc87	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e3af58e5-0dfa-41af-8270-fcfa8cc269c7	b91a5f1c-666a-411b-a18a-c8f75f722c84	HR induction session	\N	1	t	351b506c-39db-4960-bd2f-ffa52ca3bc87	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e73d48b3-de5f-466a-a0a4-306ae19d937e	b91a5f1c-666a-411b-a18a-c8f75f722c84	Meet the team lunch	\N	2	t	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
abd0501b-e7e4-4da1-b14b-34f023fc3e0c	b91a5f1c-666a-411b-a18a-c8f75f722c84	Complete compliance training	\N	3	t	351b506c-39db-4960-bd2f-ffa52ca3bc87	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
048c9556-8ac6-406a-a420-ba3a53c111df	b91a5f1c-666a-411b-a18a-c8f75f722c84	First week check-in with manager	\N	4	f	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
dbd76736-90b9-40c6-94df-2da9682ed19c	b91a5f1c-666a-411b-a18a-c8f75f722c84	Set initial objectives	\N	5	f	351b506c-39db-4960-bd2f-ffa52ca3bc87	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
528ed25e-1a54-486a-a9aa-a705e93ae761	b91a5f1c-666a-411b-a18a-c8f75f722c84	Building access and security badge	\N	6	f	351b506c-39db-4960-bd2f-ffa52ca3bc87	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
65788e95-072d-415c-9cb2-358793473c46	0670eb19-37f9-49c6-9eee-125609120844	IT setup — laptop and accounts	\N	0	t	92558eff-94d2-4abb-9c7e-5e1dd0faa398	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
87124bdf-9ba3-4257-9674-855f36af2f47	0670eb19-37f9-49c6-9eee-125609120844	HR induction session	\N	1	t	92558eff-94d2-4abb-9c7e-5e1dd0faa398	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9cccf98f-f8b7-4371-83ff-81414b1a2ee5	0670eb19-37f9-49c6-9eee-125609120844	Meet the team lunch	\N	2	t	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4a1cc500-0f99-4765-9b20-e2b1580ce7ca	0670eb19-37f9-49c6-9eee-125609120844	Complete compliance training	\N	3	t	92558eff-94d2-4abb-9c7e-5e1dd0faa398	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f5f5bb43-a9b3-4ef3-9701-2304db2e7e8c	0670eb19-37f9-49c6-9eee-125609120844	First week check-in with manager	\N	4	t	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
33bda55a-637d-43fb-a59d-787a1275bacd	0670eb19-37f9-49c6-9eee-125609120844	Set initial objectives	\N	5	t	92558eff-94d2-4abb-9c7e-5e1dd0faa398	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2ede1021-ee2f-4784-9b6c-0c56dd790f6f	0670eb19-37f9-49c6-9eee-125609120844	Building access and security badge	\N	6	f	92558eff-94d2-4abb-9c7e-5e1dd0faa398	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c228f501-20e2-40be-9927-dc91a35d3a96	e8904bc5-0369-40fe-9a7f-824e88b6d268	IT setup — laptop and accounts	\N	0	t	5eb86614-6fc0-49ac-97e3-601d92788d24	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e247d9ed-2903-4557-adac-29cf95fc0e17	e8904bc5-0369-40fe-9a7f-824e88b6d268	HR induction session	\N	1	t	5eb86614-6fc0-49ac-97e3-601d92788d24	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4f3c3c54-5728-4fc8-8269-afebade4de9c	e8904bc5-0369-40fe-9a7f-824e88b6d268	Meet the team lunch	\N	2	t	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
39e0d550-e476-468b-958d-2c74b6321b66	e8904bc5-0369-40fe-9a7f-824e88b6d268	Complete compliance training	\N	3	t	5eb86614-6fc0-49ac-97e3-601d92788d24	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d38094a0-f9b5-4b75-8ce0-80ff4fc8bd22	e8904bc5-0369-40fe-9a7f-824e88b6d268	First week check-in with manager	\N	4	t	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
83587e57-d14f-4664-99c3-90a48c479554	e8904bc5-0369-40fe-9a7f-824e88b6d268	Set initial objectives	\N	5	t	5eb86614-6fc0-49ac-97e3-601d92788d24	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a3cd99f4-d09a-4e54-8866-1b3df6380c78	e8904bc5-0369-40fe-9a7f-824e88b6d268	Building access and security badge	\N	6	t	5eb86614-6fc0-49ac-97e3-601d92788d24	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: onboarding_checklists; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.onboarding_checklists (id, workspace_id, user_id, template_id, checklist_type, status, created_at, updated_at) FROM stdin;
89f00c6c-66da-4e0b-81bb-4a7714434b85	db8b3402-39f2-455b-8d28-4d8279ca46c0	e78e0255-f170-45a0-993d-83d0655d0fff	0b33e26b-a219-4ba7-864a-db8e0178f7e6	onboarding	in_progress	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b91a5f1c-666a-411b-a18a-c8f75f722c84	db8b3402-39f2-455b-8d28-4d8279ca46c0	351b506c-39db-4960-bd2f-ffa52ca3bc87	a025bf1d-4cda-46f2-8514-b98c86925c3b	onboarding	in_progress	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0670eb19-37f9-49c6-9eee-125609120844	db8b3402-39f2-455b-8d28-4d8279ca46c0	92558eff-94d2-4abb-9c7e-5e1dd0faa398	a025bf1d-4cda-46f2-8514-b98c86925c3b	onboarding	in_progress	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e8904bc5-0369-40fe-9a7f-824e88b6d268	db8b3402-39f2-455b-8d28-4d8279ca46c0	5eb86614-6fc0-49ac-97e3-601d92788d24	a025bf1d-4cda-46f2-8514-b98c86925c3b	onboarding	completed	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: onboarding_template_items; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.onboarding_template_items (id, template_id, title, description, sort_order, default_assignee_role, created_at, updated_at) FROM stdin;
8c7c7d26-f0b8-4aa7-99df-7384da0479da	0b33e26b-a219-4ba7-864a-db8e0178f7e6	IT setup — laptop, monitors, peripherals	\N	0	it	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fc7a01a1-1f8e-4510-89f8-f56ff970fd36	0b33e26b-a219-4ba7-864a-db8e0178f7e6	Create accounts — GitHub, Jira, Slack, AWS	\N	1	it	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2fab84e9-b154-4a58-835f-270e69e9e0e6	0b33e26b-a219-4ba7-864a-db8e0178f7e6	HR induction session	\N	2	hr	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
78b32f1c-8cfd-4e1e-bb32-b39a98233de3	0b33e26b-a219-4ba7-864a-db8e0178f7e6	Meet the team lunch	\N	3	manager	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a6806993-cff0-4c15-8e8b-4bd0a2230de5	0b33e26b-a219-4ba7-864a-db8e0178f7e6	Dev environment setup walkthrough	\N	4	manager	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4841d7f4-b091-4907-9663-4d3d9d8a74d1	0b33e26b-a219-4ba7-864a-db8e0178f7e6	Complete security awareness training	\N	5	new_starter	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
95ade71a-820c-45fc-90f2-eeade09c253c	0b33e26b-a219-4ba7-864a-db8e0178f7e6	Review architecture documentation	\N	6	new_starter	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3dd835a1-5ad3-4179-ba15-00341bac93c2	0b33e26b-a219-4ba7-864a-db8e0178f7e6	First week 1:1 with manager	\N	7	manager	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d8030090-f221-4bc0-be32-167f7245b324	0b33e26b-a219-4ba7-864a-db8e0178f7e6	Pair programming session with buddy	\N	8	manager	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
32c04938-a76a-4f86-afd7-6dc3b077180b	0b33e26b-a219-4ba7-864a-db8e0178f7e6	Set initial 90-day objectives	\N	9	new_starter	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7386fd9c-05d0-4b37-ae12-628e2184cba0	0b33e26b-a219-4ba7-864a-db8e0178f7e6	Building access and security badge	\N	10	it	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8bd29859-c191-4c65-acce-7a6ebb5f5976	0b33e26b-a219-4ba7-864a-db8e0178f7e6	Complete code review training	\N	11	new_starter	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
add55e16-00f3-4ef9-bb84-c1fe948d0c98	a025bf1d-4cda-46f2-8514-b98c86925c3b	IT setup — laptop and accounts	\N	0	it	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
57cb5dfb-66fa-41eb-bb0a-f67766a2ce06	a025bf1d-4cda-46f2-8514-b98c86925c3b	HR induction session	\N	1	hr	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
852b7c5b-705c-4ea7-8aad-26d72558f263	a025bf1d-4cda-46f2-8514-b98c86925c3b	Meet the team lunch	\N	2	manager	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2eaab1e4-f372-4f9b-9a09-651597e44230	a025bf1d-4cda-46f2-8514-b98c86925c3b	Complete compliance training	\N	3	new_starter	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fe3fdbae-9300-44b5-bf8f-5f59070528a5	a025bf1d-4cda-46f2-8514-b98c86925c3b	First week check-in with manager	\N	4	manager	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
19d73565-8446-4bec-a2b2-3e387b8fb5c4	a025bf1d-4cda-46f2-8514-b98c86925c3b	Set initial objectives	\N	5	new_starter	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0222a70d-1bdf-43db-b3a6-cc253ca3c20f	a025bf1d-4cda-46f2-8514-b98c86925c3b	Building access and security badge	\N	6	it	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: onboarding_templates; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.onboarding_templates (id, workspace_id, name, template_type, description, created_at, updated_at) FROM stdin;
0b33e26b-a219-4ba7-864a-db8e0178f7e6	db8b3402-39f2-455b-8d28-4d8279ca46c0	Engineering Onboarding	onboarding	Full onboarding for engineering hires	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a025bf1d-4cda-46f2-8514-b98c86925c3b	db8b3402-39f2-455b-8d28-4d8279ca46c0	General Onboarding	onboarding	Standard onboarding for all departments	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
63f063ac-0d51-40a3-9c65-63b85e2bfa0c	db8b3402-39f2-455b-8d28-4d8279ca46c0	Offboarding Process	offboarding	Standard offboarding checklist	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: person_documents; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.person_documents (id, profile_id, workspace_id, document_type, filename, file_path, file_size, mime_type, expiry_date, uploaded_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: person_profiles; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.person_profiles (id, user_id, workspace_id, job_title, department, manager_id, contract_type, contract_start, contract_end, probation_end, location, phone, employee_id, notes, date_of_birth, partner_name, number_of_kids, kids_details, interests, dietary_requirements, emergency_contact, personal_notes, created_at, updated_at) FROM stdin;
0bbf9a2b-4121-4467-ae4b-c91c5d60b6f9	4ac83d84-43e6-4389-bf01-f0c0251affb9	db8b3402-39f2-455b-8d28-4d8279ca46c0	VP of Engineering	Engineering	\N	permanent	2021-03-01	\N	\N	London	+44 7700 900000	EMP100	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
da57d4f7-81ce-4866-a316-925a9714225a	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	db8b3402-39f2-455b-8d28-4d8279ca46c0	Senior Developer	Engineering	4ac83d84-43e6-4389-bf01-f0c0251affb9	permanent	2022-03-01	\N	\N	London	+44 7700 900001	EMP101	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c48c530c-99f3-4a45-9670-9b2be3992957	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	db8b3402-39f2-455b-8d28-4d8279ca46c0	Backend Developer	Engineering	4ac83d84-43e6-4389-bf01-f0c0251affb9	permanent	2023-03-01	\N	\N	London	+44 7700 900002	EMP102	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
feb76282-e557-401e-a111-8ed7e160d736	a13df553-f991-456a-9401-7c90bc033e88	db8b3402-39f2-455b-8d28-4d8279ca46c0	Lead Designer	Design	4ac83d84-43e6-4389-bf01-f0c0251affb9	permanent	2022-03-01	\N	\N	Manchester	+44 7700 900003	EMP103	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
11162ed3-3834-4f00-91e4-905e1644f131	549dd47f-510d-4315-aa26-8dc131f272b2	db8b3402-39f2-455b-8d28-4d8279ca46c0	Marketing Manager	Marketing	4ac83d84-43e6-4389-bf01-f0c0251affb9	permanent	2024-02-29	\N	\N	Manchester	+44 7700 900004	EMP104	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7cc07eee-e346-40fc-9b15-3f77ff1fa648	edc56289-b344-42c3-a6a3-4d3e014d5812	db8b3402-39f2-455b-8d28-4d8279ca46c0	Platform Engineer	Engineering	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	permanent	2023-03-01	\N	\N	London	+44 7700 900005	EMP105	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
05cff0ee-43ec-4bb5-8756-b40d6c3d4877	76d17f64-9249-46dc-aa2e-97c127c4c0b0	db8b3402-39f2-455b-8d28-4d8279ca46c0	UX Designer	Design	a13df553-f991-456a-9401-7c90bc033e88	permanent	2024-02-29	\N	\N	Manchester	+44 7700 900006	EMP106	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f03922ae-1c7e-4875-b9f3-2182e1420abd	77f58837-3712-4af6-b549-4de11804561d	db8b3402-39f2-455b-8d28-4d8279ca46c0	Content Strategist	Marketing	549dd47f-510d-4315-aa26-8dc131f272b2	permanent	2025-02-28	\N	\N	London	+44 7700 900007	EMP107	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d881897d-df87-4e6f-9c08-1d3cce44c56f	63e3e230-8516-4cb7-b323-440cf28fe175	db8b3402-39f2-455b-8d28-4d8279ca46c0	Full Stack Developer	Engineering	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	permanent	2024-02-29	\N	\N	Bristol	+44 7700 900008	EMP108	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a41d800a-f59a-43da-b96f-5cd2ac4e9100	dd572bbc-6f68-4046-98b8-36ebbe945667	db8b3402-39f2-455b-8d28-4d8279ca46c0	DevOps Engineer	Engineering	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	permanent	2023-03-01	\N	\N	London	+44 7700 900009	EMP109	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
dd69d7ca-d3ba-496c-8c23-5b48fb2f98ba	9bdd4897-c917-4304-bbc4-cf6ee4579def	db8b3402-39f2-455b-8d28-4d8279ca46c0	Product Designer	Design	a13df553-f991-456a-9401-7c90bc033e88	permanent	2025-02-28	\N	\N	Edinburgh	+44 7700 900010	EMP110	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0596f2f6-553d-4aea-85a9-88ee74970a30	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	db8b3402-39f2-455b-8d28-4d8279ca46c0	Product Manager	Product	4ac83d84-43e6-4389-bf01-f0c0251affb9	permanent	2023-03-01	\N	\N	London	+44 7700 900011	EMP111	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ff8d59a9-21bc-4368-87a8-66e72468ee30	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	db8b3402-39f2-455b-8d28-4d8279ca46c0	Data Engineer	Engineering	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	permanent	2024-02-29	\N	\N	London	+44 7700 900012	EMP112	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
312625d1-5dcd-4b82-aace-945fc4fef6a8	5eb86614-6fc0-49ac-97e3-601d92788d24	db8b3402-39f2-455b-8d28-4d8279ca46c0	Digital Marketing Exec	Marketing	549dd47f-510d-4315-aa26-8dc131f272b2	fixed_term	2025-02-28	2026-08-27	\N	Manchester	+44 7700 900013	EMP113	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2e7ab651-4790-4946-8377-26885236c2ec	86e6ea5d-5142-4c37-b94f-af48785430c9	db8b3402-39f2-455b-8d28-4d8279ca46c0	Product Owner	Product	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	permanent	2024-02-29	\N	\N	London	+44 7700 900014	EMP114	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5db14b50-d0f3-47f4-babc-25b33fa41437	91e53610-e137-45b7-8dba-974c0953926f	db8b3402-39f2-455b-8d28-4d8279ca46c0	Security Engineer	Engineering	4ac83d84-43e6-4389-bf01-f0c0251affb9	permanent	2022-03-01	\N	\N	London	+44 7700 900015	EMP115	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9192bbc3-ce1c-4d7f-a2bd-b3dfc2a6f3d7	e78e0255-f170-45a0-993d-83d0655d0fff	db8b3402-39f2-455b-8d28-4d8279ca46c0	Junior Product Analyst	Product	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	fixed_term	2026-02-28	2026-08-27	2026-05-29	Bristol	+44 7700 900016	EMP116	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5f980695-397d-4881-8081-a7572424a419	92558eff-94d2-4abb-9c7e-5e1dd0faa398	db8b3402-39f2-455b-8d28-4d8279ca46c0	UI Designer	Design	a13df553-f991-456a-9401-7c90bc033e88	contractor	2025-02-28	2026-08-27	\N	Remote	+44 7700 900017	EMP117	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7c94772a-7079-45d3-aab2-ecf27be3ef3d	6b3a2241-2175-4fb2-b7c6-552996ec1cce	db8b3402-39f2-455b-8d28-4d8279ca46c0	Data Scientist	Engineering	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	permanent	2024-02-29	\N	\N	Edinburgh	+44 7700 900018	EMP118	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cecf835f-e359-4ebc-9576-1933b8d90c8b	351b506c-39db-4960-bd2f-ffa52ca3bc87	db8b3402-39f2-455b-8d28-4d8279ca46c0	Marketing Coordinator	Marketing	549dd47f-510d-4315-aa26-8dc131f272b2	fixed_term	2026-02-28	2026-08-27	2026-05-29	Manchester	+44 7700 900019	EMP119	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.projects (id, name, colour, status, is_favourite, custom_statuses, client_id, workspace_id, created_at, updated_at) FROM stdin;
1d608927-ac67-4709-8a0b-6a223c6664f7	Website Redesign	#4186E0	active	f	\N	bb86c511-7089-4bb9-9f5c-30c2650eb8d9	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fb66b6be-22c3-4a61-9430-c4dc7b8b2f3d	Mobile App v3	#E44332	active	f	\N	bb86c511-7089-4bb9-9f5c-30c2650eb8d9	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
09b0b570-ac3c-4593-9ed2-707d6051d26a	API Platform	#5CBF4D	active	f	\N	efbe5d33-74c1-42c6-a4fe-f1d2c5280c85	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9d840afa-6514-44bd-aaec-ec9ee09bd74c	Marketing Campaign Q1	#F0C239	active	f	\N	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6b27fa29-a3ea-4469-9134-7eae1ba166f4	Data Pipeline	#9B59B6	active	f	\N	75181d68-6920-4425-af58-2d76d53fed90	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d769e030-8903-4ff9-b731-e082a579629f	Customer Portal	#1ABC9C	active	f	\N	efbe5d33-74c1-42c6-a4fe-f1d2c5280c85	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: pulse_responses; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.pulse_responses (id, survey_id, user_id, morale, workload, support, comments, created_at, updated_at) FROM stdin;
ca0d16de-8947-4af3-99c5-4beeb492655d	b910e7a6-ac8b-422f-b182-1c5d2cd74483	549dd47f-510d-4315-aa26-8dc131f272b2	3	3	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
603d88f1-8739-432a-967d-06599483df16	b910e7a6-ac8b-422f-b182-1c5d2cd74483	86e6ea5d-5142-4c37-b94f-af48785430c9	2	3	4	Feeling a bit overwhelmed with workload recently	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
53121ea1-5cfa-4760-b36b-964a247f174f	b910e7a6-ac8b-422f-b182-1c5d2cd74483	4ac83d84-43e6-4389-bf01-f0c0251affb9	3	3	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
91eb5e0e-c166-4a90-a4e5-aefdf015e3fe	b910e7a6-ac8b-422f-b182-1c5d2cd74483	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	3	2	4	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
565aa9bb-a8dc-47cb-88ff-812967658223	b910e7a6-ac8b-422f-b182-1c5d2cd74483	edc56289-b344-42c3-a6a3-4d3e014d5812	3	2	3	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3539e933-bfea-4a44-aec3-001e850461ce	b910e7a6-ac8b-422f-b182-1c5d2cd74483	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	5	3	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2860c4ae-00f4-4370-9211-01c702210391	b910e7a6-ac8b-422f-b182-1c5d2cd74483	76d17f64-9249-46dc-aa2e-97c127c4c0b0	2	3	4	Feeling a bit overwhelmed with workload recently	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
330d05ae-bc40-4b3d-9a91-906ca1883b2a	b910e7a6-ac8b-422f-b182-1c5d2cd74483	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	5	4	5	Great team atmosphere lately	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
eb0f5f17-6ad3-4071-b6c7-870c87c0cbd0	b910e7a6-ac8b-422f-b182-1c5d2cd74483	5eb86614-6fc0-49ac-97e3-601d92788d24	3	3	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
39094992-6391-4131-89ef-59f2bc749978	b910e7a6-ac8b-422f-b182-1c5d2cd74483	dd572bbc-6f68-4046-98b8-36ebbe945667	5	2	2	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
56fee0e4-2a11-44d9-9bdb-97143cc73050	b910e7a6-ac8b-422f-b182-1c5d2cd74483	6b3a2241-2175-4fb2-b7c6-552996ec1cce	3	4	4	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4a45f548-6ac4-40fb-a99f-e51625699b53	b910e7a6-ac8b-422f-b182-1c5d2cd74483	91e53610-e137-45b7-8dba-974c0953926f	3	4	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2250cf4a-5889-45b8-8ae7-6591e396ab26	b910e7a6-ac8b-422f-b182-1c5d2cd74483	a13df553-f991-456a-9401-7c90bc033e88	4	4	3	Feeling productive and supported	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8447b5f9-0c8c-4d89-bfeb-0ba157e51dec	b910e7a6-ac8b-422f-b182-1c5d2cd74483	92558eff-94d2-4abb-9c7e-5e1dd0faa398	3	2	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d0abfddc-1c1e-4570-b358-6d8ff0cabe68	b910e7a6-ac8b-422f-b182-1c5d2cd74483	351b506c-39db-4960-bd2f-ffa52ca3bc87	2	2	2	Would appreciate more clarity on team priorities	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
43b6abe9-6a24-4597-9961-3176123079a9	b910e7a6-ac8b-422f-b182-1c5d2cd74483	63e3e230-8516-4cb7-b323-440cf28fe175	4	4	3	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0a0f6bc3-7c22-4b2e-90b0-85554ede1348	b910e7a6-ac8b-422f-b182-1c5d2cd74483	77f58837-3712-4af6-b549-4de11804561d	2	2	4	Struggling to maintain work-life balance	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f1a85859-d2fd-4d94-ae8f-5a6f8bf12cd6	3a135143-e8d1-41d4-a61e-0f4a34111dc1	4ac83d84-43e6-4389-bf01-f0c0251affb9	4	3	3	Things are going well, enjoying the current projects	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bdc4f0bb-b5dd-4d26-a315-1e5348d08731	3a135143-e8d1-41d4-a61e-0f4a34111dc1	549dd47f-510d-4315-aa26-8dc131f272b2	2	4	4	Feeling a bit overwhelmed with workload recently	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
188c8d0f-cb1a-4bf7-a7b5-f4a32827abaa	3a135143-e8d1-41d4-a61e-0f4a34111dc1	92558eff-94d2-4abb-9c7e-5e1dd0faa398	2	3	3	Would appreciate more clarity on team priorities	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
457737b8-5e03-4d95-8500-0ee7d05c3d5c	3a135143-e8d1-41d4-a61e-0f4a34111dc1	e78e0255-f170-45a0-993d-83d0655d0fff	4	5	3	Great team atmosphere lately	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ab262d9b-3680-4d0c-a491-62f42ee22af0	3a135143-e8d1-41d4-a61e-0f4a34111dc1	6b3a2241-2175-4fb2-b7c6-552996ec1cce	3	4	3	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
27617ca9-af51-4d1d-928a-5193d6d6fe9c	3a135143-e8d1-41d4-a61e-0f4a34111dc1	5eb86614-6fc0-49ac-97e3-601d92788d24	5	4	4	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3ac41cfa-3658-452c-b4cf-23f0305dc195	3a135143-e8d1-41d4-a61e-0f4a34111dc1	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	3	4	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5a6016e1-822e-4cdc-8ab3-8bce9553111d	3a135143-e8d1-41d4-a61e-0f4a34111dc1	edc56289-b344-42c3-a6a3-4d3e014d5812	2	2	2	Struggling to maintain work-life balance	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
df80abce-4702-4dd8-a952-63d34ac5cd24	3a135143-e8d1-41d4-a61e-0f4a34111dc1	63e3e230-8516-4cb7-b323-440cf28fe175	2	3	3	Would appreciate more clarity on team priorities	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e9a2251a-7f2f-4c84-a86c-4eadb7007051	3a135143-e8d1-41d4-a61e-0f4a34111dc1	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	2	4	3	Would appreciate more clarity on team priorities	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4d603ab6-e202-40d7-ba21-621517f2121e	3a135143-e8d1-41d4-a61e-0f4a34111dc1	86e6ea5d-5142-4c37-b94f-af48785430c9	2	5	2	Struggling to maintain work-life balance	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
523c6b89-8235-403e-b2c2-9240f2fe6274	3a135143-e8d1-41d4-a61e-0f4a34111dc1	9bdd4897-c917-4304-bbc4-cf6ee4579def	3	3	2	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b44f4b81-f52e-4f56-86bb-ec8fc521d7bb	3a135143-e8d1-41d4-a61e-0f4a34111dc1	76d17f64-9249-46dc-aa2e-97c127c4c0b0	4	4	3	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9bbcef81-972c-4694-b602-d6f0112a82ff	3a135143-e8d1-41d4-a61e-0f4a34111dc1	91e53610-e137-45b7-8dba-974c0953926f	3	3	2	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cc40c1dc-e322-4363-afd6-39f127c99421	3a135143-e8d1-41d4-a61e-0f4a34111dc1	dd572bbc-6f68-4046-98b8-36ebbe945667	2	5	5	Struggling to maintain work-life balance	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
501eb9a8-5194-4c9b-bef8-eebd770ca176	2661f4f6-c145-467b-92d5-4086cb9060cc	351b506c-39db-4960-bd2f-ffa52ca3bc87	5	5	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
91ddbf7b-f7f6-4956-affd-b38e3f0772e7	2661f4f6-c145-467b-92d5-4086cb9060cc	76d17f64-9249-46dc-aa2e-97c127c4c0b0	2	4	3	Would appreciate more clarity on team priorities	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a175c78b-fb86-4156-9b5a-7a0926d45dda	2661f4f6-c145-467b-92d5-4086cb9060cc	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	5	4	5	Feeling productive and supported	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a510b274-6f87-4b39-b3a3-deb448974a79	2661f4f6-c145-467b-92d5-4086cb9060cc	77f58837-3712-4af6-b549-4de11804561d	3	4	4	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bb4cdf79-bc51-4e5f-9c36-ba7b5ce5f09c	2661f4f6-c145-467b-92d5-4086cb9060cc	86e6ea5d-5142-4c37-b94f-af48785430c9	2	3	3	Would appreciate more clarity on team priorities	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6ea2613c-be69-4459-a5e2-c0f183e4fdfa	2661f4f6-c145-467b-92d5-4086cb9060cc	9bdd4897-c917-4304-bbc4-cf6ee4579def	3	4	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1a844285-9779-4455-b1e5-ec9e8c99c06f	2661f4f6-c145-467b-92d5-4086cb9060cc	dd572bbc-6f68-4046-98b8-36ebbe945667	3	4	4	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e6c2b638-70e1-47d3-be41-9574c589e5ac	2661f4f6-c145-467b-92d5-4086cb9060cc	63e3e230-8516-4cb7-b323-440cf28fe175	3	2	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cce2b9e3-20ae-465d-8079-3378e18f1254	2661f4f6-c145-467b-92d5-4086cb9060cc	a13df553-f991-456a-9401-7c90bc033e88	3	3	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2f6afb65-5df4-45e1-bd63-f1dea90f6eb2	2661f4f6-c145-467b-92d5-4086cb9060cc	6b3a2241-2175-4fb2-b7c6-552996ec1cce	5	3	3	Feeling productive and supported	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
eb50cdbc-d40b-4c98-8d0d-75718df4101a	2661f4f6-c145-467b-92d5-4086cb9060cc	91e53610-e137-45b7-8dba-974c0953926f	3	5	3	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8e1c2f36-2baf-4c0e-b1ee-84488833bdec	2661f4f6-c145-467b-92d5-4086cb9060cc	edc56289-b344-42c3-a6a3-4d3e014d5812	3	3	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
113b8ee8-9c5a-4acd-a818-c051575d50da	2661f4f6-c145-467b-92d5-4086cb9060cc	e78e0255-f170-45a0-993d-83d0655d0fff	3	4	4	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
846becc4-4390-4e84-a6d1-8b457c7ac8e4	2661f4f6-c145-467b-92d5-4086cb9060cc	4ac83d84-43e6-4389-bf01-f0c0251affb9	3	3	3	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1db71622-732b-41df-a7a3-14dcc2b75fc8	2661f4f6-c145-467b-92d5-4086cb9060cc	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	4	2	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
92ba8c90-4c45-4da3-8a2d-490c59048e99	fcb84202-d913-40e9-bef8-0fccfab34c16	86e6ea5d-5142-4c37-b94f-af48785430c9	5	4	5	Feeling productive and supported	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d3735635-df2b-425b-9f50-1ec6e71dae5e	fcb84202-d913-40e9-bef8-0fccfab34c16	92558eff-94d2-4abb-9c7e-5e1dd0faa398	4	4	4	Great team atmosphere lately	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f903d2ad-bfb4-47bd-8b60-178fae195ff0	fcb84202-d913-40e9-bef8-0fccfab34c16	4ac83d84-43e6-4389-bf01-f0c0251affb9	4	3	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9add46df-439b-4862-b59e-a092b26571bd	fcb84202-d913-40e9-bef8-0fccfab34c16	6b3a2241-2175-4fb2-b7c6-552996ec1cce	4	3	4	Great team atmosphere lately	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
af0c7d86-8f22-4e9c-a236-d3cbae40151e	fcb84202-d913-40e9-bef8-0fccfab34c16	77f58837-3712-4af6-b549-4de11804561d	4	2	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6f8d9869-d3e7-45a1-acb8-a3da7b07de95	fcb84202-d913-40e9-bef8-0fccfab34c16	a13df553-f991-456a-9401-7c90bc033e88	4	4	5	Feeling productive and supported	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6a7d9979-3257-4baa-9798-0098dcfb2ecf	fcb84202-d913-40e9-bef8-0fccfab34c16	e78e0255-f170-45a0-993d-83d0655d0fff	3	2	3	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7f9b8c15-4138-4b94-8d33-a51b798d301f	fcb84202-d913-40e9-bef8-0fccfab34c16	351b506c-39db-4960-bd2f-ffa52ca3bc87	3	3	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5ce8e02b-7f54-4c91-9d68-3f1c5a914b06	fcb84202-d913-40e9-bef8-0fccfab34c16	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	3	3	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a1f09af2-083b-45a0-876d-8c389e62177d	fcb84202-d913-40e9-bef8-0fccfab34c16	63e3e230-8516-4cb7-b323-440cf28fe175	3	3	4	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cef363c3-3b54-49d3-bdcb-9d6f2c435073	fcb84202-d913-40e9-bef8-0fccfab34c16	549dd47f-510d-4315-aa26-8dc131f272b2	3	3	3	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d8f08bf2-da35-4cdb-b542-f2370ad8b181	fcb84202-d913-40e9-bef8-0fccfab34c16	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	5	4	3	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
daa7ff5c-b49a-4e85-a018-0c575347cbd8	fcb84202-d913-40e9-bef8-0fccfab34c16	91e53610-e137-45b7-8dba-974c0953926f	3	4	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c07ef877-26b6-4187-88d8-1d29ff9a7678	fcb84202-d913-40e9-bef8-0fccfab34c16	edc56289-b344-42c3-a6a3-4d3e014d5812	4	3	5	Things are going well, enjoying the current projects	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f3c045bd-44a2-4925-891d-55fc6924e153	fcb84202-d913-40e9-bef8-0fccfab34c16	dd572bbc-6f68-4046-98b8-36ebbe945667	4	4	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0afe5750-3623-43f8-b71d-7b53ad731dd2	fcb84202-d913-40e9-bef8-0fccfab34c16	9bdd4897-c917-4304-bbc4-cf6ee4579def	4	4	5	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b0edd7d2-f665-4c03-93b3-bfcf5a2faf17	fcb84202-d913-40e9-bef8-0fccfab34c16	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	5	4	4	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: pulse_surveys; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.pulse_surveys (id, workspace_id, title, status, end_date, created_at, updated_at) FROM stdin;
b910e7a6-ac8b-422f-b182-1c5d2cd74483	db8b3402-39f2-455b-8d28-4d8279ca46c0	January Pulse	closed	2026-01-31	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3a135143-e8d1-41d4-a61e-0f4a34111dc1	db8b3402-39f2-455b-8d28-4d8279ca46c0	February Pulse	closed	2026-02-28	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2661f4f6-c145-467b-92d5-4086cb9060cc	db8b3402-39f2-455b-8d28-4d8279ca46c0	March Pulse	closed	2026-03-31	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fcb84202-d913-40e9-bef8-0fccfab34c16	db8b3402-39f2-455b-8d28-4d8279ca46c0	April Pulse	active	2026-04-30	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: review_cycles; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.review_cycles (id, workspace_id, name, period_start, period_end, status, created_at, updated_at) FROM stdin;
9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026 Annual Review	2026-01-01	2026-06-30	manager_review	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	2025 Annual Review	2025-01-01	2025-12-31	complete	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: review_periods; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.review_periods (id, workspace_id, name, start_date, end_date, created_at, updated_at) FROM stdin;
269b6650-10f8-4a31-9f22-b15dc53f1456	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026 H1	2026-01-01	2026-06-30	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b7e5999b-3840-4677-b972-71cc7061c5d1	db8b3402-39f2-455b-8d28-4d8279ca46c0	2025 H2	2025-07-01	2025-12-31	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.reviews (id, cycle_id, workspace_id, user_id, reviewer_id, self_assessment, manager_assessment, overall_rating, strengths, areas_for_improvement, status, sign_off_date, created_at, updated_at) FROM stdin;
3186fbc0-ad64-458e-8f01-e20fa8bdd7ef	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	5	Exceptional technical leadership, drives architectural excellence	Could delegate more to develop others	finalised	2026-02-09	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4f2dccd8-1350-4cc3-ad39-3ca1f565b94c	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	4	Strong coding skills, reliable delivery, good mentor	Needs to improve estimation accuracy	finalised	2026-02-20	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
970d9e83-2386-488c-98ca-35f20e32a625	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Solid backend skills, improving steadily	Should take on more ownership of features	discussed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9ba5deec-9a1c-4ddf-af55-e31d4444cd93	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	4	Outstanding design thinking, elevates team standards	Could be more assertive in stakeholder discussions	finalised	2026-02-27	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d0870d3e-65df-41da-a497-4f56fc679d64	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	\N	\N	\N	manager_draft	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4ee1b5a9-6347-4df3-9f59-7d221986b60f	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	\N	\N	4	Excellent platform engineering, strong K8s skills	Needs better documentation habits	finalised	2026-02-25	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
70e32c57-1eda-464e-9047-ad2864982216	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	76d17f64-9249-46dc-aa2e-97c127c4c0b0	a13df553-f991-456a-9401-7c90bc033e88	\N	\N	3	Good UX instincts, growing well	Should develop stronger visual design skills	discussed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
81e87c79-cb32-4131-b467-f6bd877f88a1	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	77f58837-3712-4af6-b549-4de11804561d	549dd47f-510d-4315-aa26-8dc131f272b2	\N	\N	\N	\N	\N	self_assessment	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
30c6201a-90a8-4167-bf57-36fa3fc34e99	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	63e3e230-8516-4cb7-b323-440cf28fe175	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	\N	\N	4	Versatile full-stack skills, fast learner	Could improve code review thoroughness	discussed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
51750aaa-c51a-43b4-934f-0b7f563bf822	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	\N	\N	5	Outstanding DevOps expertise, hero in production incidents	Should share knowledge more proactively	finalised	2026-02-26	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c9dd23b2-8342-4da2-9158-02a8039f2edd	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	9bdd4897-c917-4304-bbc4-cf6ee4579def	a13df553-f991-456a-9401-7c90bc033e88	\N	\N	\N	\N	\N	self_assessment	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
728feb47-6b7c-4b93-b486-83c0d97a4c2e	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	4	Strong product sense, good stakeholder management	Needs to develop data-driven decision making	finalised	2026-02-20	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1c94e63f-1b1c-4000-8b18-44524163e89a	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	\N	\N	\N	\N	\N	manager_draft	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
76918521-1788-43bf-9b6d-913b74c815c7	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	5eb86614-6fc0-49ac-97e3-601d92788d24	549dd47f-510d-4315-aa26-8dc131f272b2	\N	\N	\N	\N	\N	not_started	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ec475027-5ecf-4fbc-b4dd-dad9ac503562	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	86e6ea5d-5142-4c37-b94f-af48785430c9	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	\N	\N	3	Improving product ownership skills	Needs to develop technical understanding	discussed	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
33f5b2b0-5d58-4241-a916-6ec6e3109cee	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	5	Exceptional security knowledge, keeps us safe	Could improve presentation skills for non-technical audiences	finalised	2026-02-25	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
abf54326-fa09-471a-bb37-025e53aa1295	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	e78e0255-f170-45a0-993d-83d0655d0fff	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	\N	\N	\N	\N	\N	not_started	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
acbc0ee7-afe1-47f0-aa39-2f9eb8a74407	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	92558eff-94d2-4abb-9c7e-5e1dd0faa398	a13df553-f991-456a-9401-7c90bc033e88	\N	\N	\N	\N	\N	self_assessment	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4929fa4b-8851-46f2-ac84-12107a84638f	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	\N	\N	4	Strong data science skills, innovative approaches	Should align work more closely with business outcomes	finalised	2026-02-26	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
427ee080-32a3-4fb5-897a-cd61e0498f8e	9da5f104-52b7-4f84-865b-e0657a24f8e5	db8b3402-39f2-455b-8d28-4d8279ca46c0	351b506c-39db-4960-bd2f-ffa52ca3bc87	549dd47f-510d-4315-aa26-8dc131f272b2	\N	\N	\N	\N	\N	not_started	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a26d755f-4333-4d0b-94b2-3987c71ed622	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	4ac83d84-43e6-4389-bf01-f0c0251affb9	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d7bfa254-7ed5-4029-9abf-f6aadb273a35	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e282455d-b4ea-4a21-bf16-b8432a0c806e	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
07aa53f3-12f3-4ee3-8698-6cabd951020e	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	a13df553-f991-456a-9401-7c90bc033e88	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9891091d-dfba-47f3-8510-ab9ead89ffd9	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	549dd47f-510d-4315-aa26-8dc131f272b2	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
82983729-1189-45ee-95ef-e941d82bd06f	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	edc56289-b344-42c3-a6a3-4d3e014d5812	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
22ec6a09-b3e0-475f-8029-8351f5553e04	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	76d17f64-9249-46dc-aa2e-97c127c4c0b0	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c46fea17-0795-4b98-a388-d20dbbd6e40d	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	77f58837-3712-4af6-b549-4de11804561d	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0eb66ee6-3597-4c40-b836-85bb6db5544d	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	63e3e230-8516-4cb7-b323-440cf28fe175	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c2a7a43b-9333-4e2e-916f-e4fb3ee05479	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	dd572bbc-6f68-4046-98b8-36ebbe945667	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c195e505-acab-4ae3-81b6-c9500ffb77a8	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	9bdd4897-c917-4304-bbc4-cf6ee4579def	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d4cfe402-e8af-4bbc-ae3e-ec61ea06857a	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
baac5798-eb0d-4f06-bc5c-9b246d48247c	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fb5de892-3eb3-4cca-b06f-4d88f7222d9c	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	5eb86614-6fc0-49ac-97e3-601d92788d24	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
04e2de2d-d71b-4898-9c41-a88988f0b4c2	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	86e6ea5d-5142-4c37-b94f-af48785430c9	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b14c6f34-abbe-4f1f-82e1-37869a25518e	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	91e53610-e137-45b7-8dba-974c0953926f	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	5	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3d2dc2b2-a1ef-425e-8271-3d753fc46e16	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	e78e0255-f170-45a0-993d-83d0655d0fff	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
da03905a-75b3-4387-b7d3-333148f86c02	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	92558eff-94d2-4abb-9c7e-5e1dd0faa398	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0ac3c710-3cfc-4513-913a-2adfd3e9605c	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	6b3a2241-2175-4fb2-b7c6-552996ec1cce	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	4	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
17044296-c30a-4cf7-bc3f-8335781b9b7d	7d38b6e0-8018-4315-8eff-96cf65af7a90	db8b3402-39f2-455b-8d28-4d8279ca46c0	351b506c-39db-4960-bd2f-ffa52ca3bc87	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	3	Good performance during the period	Continue developing in current role	finalised	2025-12-15	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: rota_entries; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.rota_entries (id, rota_id, user_id, workspace_id, date_from, date_to, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rotas; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.rotas (id, name, rota_type, start_time, end_time, include_weekends, colour, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: segments; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.segments (id, name, sort_order, project_id, created_at, updated_at) FROM stdin;
a0038221-e726-43b5-a6cd-4b51685175d9	Homepage	0	1d608927-ac67-4709-8a0b-6a223c6664f7	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
95c63903-653e-45c6-8b37-95648bf5f060	Product Pages	0	1d608927-ac67-4709-8a0b-6a223c6664f7	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d0fed7b4-c5ad-4860-b8b6-a6b7d2ecfc16	Checkout Flow	0	1d608927-ac67-4709-8a0b-6a223c6664f7	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: shared_timelines; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.shared_timelines (id, workspace_id, token, name, is_active, team_id, project_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.tags (id, name, colour, project_id, created_at, updated_at) FROM stdin;
5f42f86d-e6b6-4e6b-804e-e7bd4a3623a5	Frontend	#3B82F6	1d608927-ac67-4709-8a0b-6a223c6664f7	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
878aaad4-56ab-40da-a80f-bbc978529ff6	Backend	#10B981	1d608927-ac67-4709-8a0b-6a223c6664f7	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4994cdcb-d49c-4633-a7d4-2799ada25077	Design	#8B5CF6	1d608927-ac67-4709-8a0b-6a223c6664f7	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fdbca1e8-2979-4dba-a4d5-5aabe946c14d	Bug	#EF4444	1d608927-ac67-4709-8a0b-6a223c6664f7	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e683ea9a-473e-413e-9231-db63b9db5ffa	Enhancement	#F59E0B	1d608927-ac67-4709-8a0b-6a223c6664f7	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
12e5f111-5605-4337-8a8b-d2ba3296cf59	Documentation	#6B7280	1d608927-ac67-4709-8a0b-6a223c6664f7	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: task_assignees; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.task_assignees (task_id, user_id) FROM stdin;
cb8c627b-56cf-4dc8-9afd-8c3e7c434528	a13df553-f991-456a-9401-7c90bc033e88
a8a4366e-12c1-4ef4-94d4-618228c516b2	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b
4a868fe1-f372-47c3-8e72-b63f000b7bf2	933be77b-5ee8-4c1c-ad5c-0c104b1d4942
32d5e352-4836-4123-a272-5f1f48f79701	edc56289-b344-42c3-a6a3-4d3e014d5812
975b53e5-b549-4c7c-8abf-74e0ea1a6900	63e3e230-8516-4cb7-b323-440cf28fe175
af69fffd-07bb-46d6-8201-c625ea4cc8a9	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b
357119e6-bd48-4d79-bd70-5a7eb1ac22ac	a13df553-f991-456a-9401-7c90bc033e88
2fe01f7c-1811-4461-817b-a28dd1e0d3cc	dd572bbc-6f68-4046-98b8-36ebbe945667
f2d2c0ea-30db-4d64-aafb-d5bf3c358024	933be77b-5ee8-4c1c-ad5c-0c104b1d4942
b0a2a18f-f350-4098-bcf0-07988b5d8b6b	edc56289-b344-42c3-a6a3-4d3e014d5812
344b763e-96cf-4194-8bfa-93f25f52d741	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8
82a6084c-2f9f-4fe4-b00b-2025edcd3e0d	549dd47f-510d-4315-aa26-8dc131f272b2
03f510ca-b430-4326-aae3-93e24929247b	77f58837-3712-4af6-b549-4de11804561d
53bf5094-f208-49a9-9970-59d3aae86ed8	5eb86614-6fc0-49ac-97e3-601d92788d24
648ec479-4d4f-4918-afe4-3eddf1354e64	6b3a2241-2175-4fb2-b7c6-552996ec1cce
e1800199-a866-4dc6-aa37-280159c6169b	9bdd4897-c917-4304-bbc4-cf6ee4579def
def17a76-1c4d-49d6-ab2b-c430ce345bf1	91e53610-e137-45b7-8dba-974c0953926f
dec066db-e8ed-4d97-912a-92e6922606e1	76d17f64-9249-46dc-aa2e-97c127c4c0b0
\.


--
-- Data for Name: task_dependencies; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.task_dependencies (id, blocker_id, blocked_id, dependency_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_tags; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.task_tags (task_id, tag_id) FROM stdin;
\.


--
-- Data for Name: task_templates; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.task_templates (id, name, description, colour, status, time_estimate_minutes, checklist_items, tag_names, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.tasks (id, name, description, colour, status, status_emoji, date_from, date_to, start_time, end_time, time_estimate_minutes, time_estimate_mode, is_recurring, recurrence_rule, sort_order, project_id, segment_id, workspace_id, created_at, updated_at, parent_id, time_logged_minutes) FROM stdin;
cb8c627b-56cf-4dc8-9afd-8c3e7c434528	Design homepage mockup	\N	\N	done	\N	2026-02-28	2026-03-03	\N	\N	\N	total	f	\N	0	1d608927-ac67-4709-8a0b-6a223c6664f7	a0038221-e726-43b5-a6cd-4b51685175d9	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
a8a4366e-12c1-4ef4-94d4-618228c516b2	Implement responsive header	\N	\N	in_progress	\N	2026-03-02	2026-03-05	\N	\N	\N	total	f	\N	1	1d608927-ac67-4709-8a0b-6a223c6664f7	a0038221-e726-43b5-a6cd-4b51685175d9	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
4a868fe1-f372-47c3-8e72-b63f000b7bf2	Build product card component	\N	\N	planned	\N	2026-03-04	2026-03-08	\N	\N	\N	total	f	\N	2	1d608927-ac67-4709-8a0b-6a223c6664f7	95c63903-653e-45c6-8b37-95648bf5f060	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
32d5e352-4836-4123-a272-5f1f48f79701	Checkout form validation	\N	\N	planned	\N	2026-03-07	2026-03-10	\N	\N	\N	total	f	\N	3	1d608927-ac67-4709-8a0b-6a223c6664f7	d0fed7b4-c5ad-4860-b8b6-a6b7d2ecfc16	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
975b53e5-b549-4c7c-8abf-74e0ea1a6900	Payment gateway integration	\N	\N	planned	\N	2026-03-10	2026-03-14	\N	\N	\N	total	f	\N	4	1d608927-ac67-4709-8a0b-6a223c6664f7	d0fed7b4-c5ad-4860-b8b6-a6b7d2ecfc16	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
af69fffd-07bb-46d6-8201-c625ea4cc8a9	Setup React Native project	\N	\N	done	\N	2026-02-28	2026-03-02	\N	\N	\N	total	f	\N	5	fb66b6be-22c3-4a61-9430-c4dc7b8b2f3d	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
357119e6-bd48-4d79-bd70-5a7eb1ac22ac	Auth flow screens	\N	\N	in_progress	\N	2026-03-02	2026-03-06	\N	\N	\N	total	f	\N	6	fb66b6be-22c3-4a61-9430-c4dc7b8b2f3d	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
2fe01f7c-1811-4461-817b-a28dd1e0d3cc	Push notification setup	\N	\N	planned	\N	2026-03-05	2026-03-08	\N	\N	\N	total	f	\N	7	fb66b6be-22c3-4a61-9430-c4dc7b8b2f3d	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
f2d2c0ea-30db-4d64-aafb-d5bf3c358024	API authentication middleware	\N	\N	done	\N	2026-02-28	2026-03-03	\N	\N	\N	total	f	\N	8	09b0b570-ac3c-4593-9ed2-707d6051d26a	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
b0a2a18f-f350-4098-bcf0-07988b5d8b6b	Rate limiting implementation	\N	\N	in_progress	\N	2026-03-03	2026-03-05	\N	\N	\N	total	f	\N	9	09b0b570-ac3c-4593-9ed2-707d6051d26a	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
344b763e-96cf-4194-8bfa-93f25f52d741	OpenAPI documentation	\N	\N	planned	\N	2026-03-05	2026-03-07	\N	\N	\N	total	f	\N	10	09b0b570-ac3c-4593-9ed2-707d6051d26a	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
82a6084c-2f9f-4fe4-b00b-2025edcd3e0d	Social media calendar	\N	\N	in_progress	\N	2026-03-01	2026-03-08	\N	\N	\N	total	f	\N	11	9d840afa-6514-44bd-aaec-ec9ee09bd74c	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
03f510ca-b430-4326-aae3-93e24929247b	Blog post drafts	\N	\N	planned	\N	2026-03-03	2026-03-10	\N	\N	\N	total	f	\N	12	9d840afa-6514-44bd-aaec-ec9ee09bd74c	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
53bf5094-f208-49a9-9970-59d3aae86ed8	Email campaign setup	\N	\N	planned	\N	2026-03-08	2026-03-14	\N	\N	\N	total	f	\N	13	9d840afa-6514-44bd-aaec-ec9ee09bd74c	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
648ec479-4d4f-4918-afe4-3eddf1354e64	ETL pipeline for analytics	\N	\N	in_progress	\N	2026-02-28	2026-03-07	\N	\N	\N	total	f	\N	14	6b27fa29-a3ea-4469-9134-7eae1ba166f4	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
e1800199-a866-4dc6-aa37-280159c6169b	Dashboard visualisations	\N	\N	planned	\N	2026-03-07	2026-03-14	\N	\N	\N	total	f	\N	15	6b27fa29-a3ea-4469-9134-7eae1ba166f4	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
def17a76-1c4d-49d6-ab2b-c430ce345bf1	Portal login and SSO	\N	\N	in_progress	\N	2026-02-28	2026-03-05	\N	\N	\N	total	f	\N	16	d769e030-8903-4ff9-b731-e082a579629f	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
dec066db-e8ed-4d97-912a-92e6922606e1	Customer profile page	\N	\N	planned	\N	2026-03-05	2026-03-10	\N	\N	\N	total	f	\N	17	d769e030-8903-4ff9-b731-e082a579629f	\N	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	0
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.team_members (team_id, user_id, sort_order) FROM stdin;
093cbb80-6af9-4cf1-b0f5-4f39c953915a	4ac83d84-43e6-4389-bf01-f0c0251affb9	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	a13df553-f991-456a-9401-7c90bc033e88	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	549dd47f-510d-4315-aa26-8dc131f272b2	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	edc56289-b344-42c3-a6a3-4d3e014d5812	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	76d17f64-9249-46dc-aa2e-97c127c4c0b0	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	77f58837-3712-4af6-b549-4de11804561d	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	63e3e230-8516-4cb7-b323-440cf28fe175	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	dd572bbc-6f68-4046-98b8-36ebbe945667	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	9bdd4897-c917-4304-bbc4-cf6ee4579def	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	5eb86614-6fc0-49ac-97e3-601d92788d24	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	86e6ea5d-5142-4c37-b94f-af48785430c9	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	91e53610-e137-45b7-8dba-974c0953926f	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	e78e0255-f170-45a0-993d-83d0655d0fff	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	92558eff-94d2-4abb-9c7e-5e1dd0faa398	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	6b3a2241-2175-4fb2-b7c6-552996ec1cce	0
093cbb80-6af9-4cf1-b0f5-4f39c953915a	351b506c-39db-4960-bd2f-ffa52ca3bc87	0
dd8eda34-623f-48a9-8953-d0783fe9d91d	4ac83d84-43e6-4389-bf01-f0c0251affb9	0
dd8eda34-623f-48a9-8953-d0783fe9d91d	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	0
dd8eda34-623f-48a9-8953-d0783fe9d91d	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	0
dd8eda34-623f-48a9-8953-d0783fe9d91d	edc56289-b344-42c3-a6a3-4d3e014d5812	0
dd8eda34-623f-48a9-8953-d0783fe9d91d	63e3e230-8516-4cb7-b323-440cf28fe175	0
dd8eda34-623f-48a9-8953-d0783fe9d91d	dd572bbc-6f68-4046-98b8-36ebbe945667	0
dd8eda34-623f-48a9-8953-d0783fe9d91d	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	0
dd8eda34-623f-48a9-8953-d0783fe9d91d	91e53610-e137-45b7-8dba-974c0953926f	0
33679f52-ea82-4ccb-8f44-2d84d097c77e	a13df553-f991-456a-9401-7c90bc033e88	0
33679f52-ea82-4ccb-8f44-2d84d097c77e	76d17f64-9249-46dc-aa2e-97c127c4c0b0	0
33679f52-ea82-4ccb-8f44-2d84d097c77e	9bdd4897-c917-4304-bbc4-cf6ee4579def	0
33679f52-ea82-4ccb-8f44-2d84d097c77e	92558eff-94d2-4abb-9c7e-5e1dd0faa398	0
c6aba7bf-0e05-4f2d-8eb4-92cb8bdf10b7	549dd47f-510d-4315-aa26-8dc131f272b2	0
c6aba7bf-0e05-4f2d-8eb4-92cb8bdf10b7	77f58837-3712-4af6-b549-4de11804561d	0
c6aba7bf-0e05-4f2d-8eb4-92cb8bdf10b7	5eb86614-6fc0-49ac-97e3-601d92788d24	0
c6aba7bf-0e05-4f2d-8eb4-92cb8bdf10b7	351b506c-39db-4960-bd2f-ffa52ca3bc87	0
16f2a505-0eda-449d-89b4-c36b85a188dc	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	0
16f2a505-0eda-449d-89b4-c36b85a188dc	86e6ea5d-5142-4c37-b94f-af48785430c9	0
16f2a505-0eda-449d-89b4-c36b85a188dc	e78e0255-f170-45a0-993d-83d0655d0fff	0
fd7ac454-3db1-46b9-a203-55dc9adf5144	6b3a2241-2175-4fb2-b7c6-552996ec1cce	0
fd7ac454-3db1-46b9-a203-55dc9adf5144	dd572bbc-6f68-4046-98b8-36ebbe945667	0
fd7ac454-3db1-46b9-a203-55dc9adf5144	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	0
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.teams (id, name, is_favourite, workspace_id, created_at, updated_at) FROM stdin;
093cbb80-6af9-4cf1-b0f5-4f39c953915a	Everyone	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
dd8eda34-623f-48a9-8953-d0783fe9d91d	Engineering	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
33679f52-ea82-4ccb-8f44-2d84d097c77e	Design	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c6aba7bf-0e05-4f2d-8eb4-92cb8bdf10b7	Marketing	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
16f2a505-0eda-449d-89b4-c36b85a188dc	Product	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
fd7ac454-3db1-46b9-a203-55dc9adf5144	Data & Analytics	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: time_off; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.time_off (id, user_id, workspace_id, date_from, date_to, reason, colour, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_competencies; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.user_competencies (id, user_id, competency_id, workspace_id, level, assessed_date, assessed_by, expiry_date, notes, created_at, updated_at) FROM stdin;
88531aee-0fb9-4adc-83bf-309f9db9231c	4ac83d84-43e6-4389-bf01-f0c0251affb9	b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2026-01-01	4ac83d84-43e6-4389-bf01-f0c0251affb9	2027-02-20	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
208f8a0d-aab3-41cf-85e8-e68ca01d03f1	4ac83d84-43e6-4389-bf01-f0c0251affb9	bad75b03-45a7-4206-89f6-2ca11880b7b1	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-11-20	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-04-11	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a896cc5d-0734-46fc-8100-04226bc6b7e6	4ac83d84-43e6-4389-bf01-f0c0251affb9	dc0b5cce-365b-43df-bae7-b0cec4ec8b24	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-12-03	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-08-02	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c6173091-99e7-42a1-a0e1-4a3bc25e389b	4ac83d84-43e6-4389-bf01-f0c0251affb9	4a33d04d-b931-4738-b062-736a30a506ce	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-12-25	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d9aacefd-8421-442e-9d97-f3bd0096378a	4ac83d84-43e6-4389-bf01-f0c0251affb9	6c8d3dad-7389-40fa-b3f2-4fb9d6776e44	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2026-01-03	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
13b35135-13f8-4b40-bf82-c5ecaeeba9af	4ac83d84-43e6-4389-bf01-f0c0251affb9	38bcfae5-40ce-40ca-83f3-6ec590124b00	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-09-12	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7dee2d05-ef86-4fe4-933c-d6e8337482e9	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-10-13	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-05-13	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2847fdbe-bffb-4dfa-b98f-f1d3fb2d9153	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	5b5e05cc-ab7d-4aea-94d9-b16f87454250	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2026-01-21	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f2f79eed-6c59-4d26-a11b-ca80ba3d746c	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2026-01-22	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9835ff01-840e-44a6-93bd-e338397ae87a	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	042a970e-b9cb-4267-b615-d7e25fedf857	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2026-01-06	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c192a9e9-6891-43ed-a52d-8b7441915861	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	6c8d3dad-7389-40fa-b3f2-4fb9d6776e44	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-05	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4419999d-9867-4f9d-9a79-28f677c66d8b	b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-01	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ed8d9b11-62b1-4503-a3c1-8fe1d6c0b8f7	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2026-01-23	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-12-13	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cbe50fbc-d89a-40f9-972a-bd17a4458a03	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	bad75b03-45a7-4206-89f6-2ca11880b7b1	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-10	4ac83d84-43e6-4389-bf01-f0c0251affb9	2027-01-11	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7f534ea4-4810-4c33-a9b4-2c922716652f	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	c7481d48-e30d-4f04-99cc-3bb82abfdf3a	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-09-12	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
25da0282-d93f-4b2c-bea9-a6e6c532a8b3	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	6c8d3dad-7389-40fa-b3f2-4fb9d6776e44	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-10-14	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3a1a05c1-8706-4151-a633-fadeae1497dd	933be77b-5ee8-4c1c-ad5c-0c104b1d4942	5ddb17a6-3b39-4536-943b-14d152eb20f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-10-07	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-07-20	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
afafc74c-ace2-49fd-8573-f0b2cb02c320	edc56289-b344-42c3-a6a3-4d3e014d5812	b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-11-19	4ac83d84-43e6-4389-bf01-f0c0251affb9	2027-01-25	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
923649a5-2d9b-4c38-9977-bc5a24e4a62a	edc56289-b344-42c3-a6a3-4d3e014d5812	5ddb17a6-3b39-4536-943b-14d152eb20f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-12-20	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-04-02	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
71c5adca-f66c-4cf6-ae1d-672cf11d5175	edc56289-b344-42c3-a6a3-4d3e014d5812	042a970e-b9cb-4267-b615-d7e25fedf857	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-10-13	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
00ce8a21-1a08-444f-a997-fde23ed3d380	edc56289-b344-42c3-a6a3-4d3e014d5812	bad75b03-45a7-4206-89f6-2ca11880b7b1	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-11-19	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-09-20	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
b28c2226-20a5-4dc9-b43c-3d9c1255f8e9	edc56289-b344-42c3-a6a3-4d3e014d5812	6c8d3dad-7389-40fa-b3f2-4fb9d6776e44	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-21	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
27d7bb68-22bd-4db4-9444-ccbe3ecdca7a	63e3e230-8516-4cb7-b323-440cf28fe175	b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-11-04	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-07-18	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2fdcbba3-c375-4d4b-a395-be690dbf4e9a	63e3e230-8516-4cb7-b323-440cf28fe175	5b5e05cc-ab7d-4aea-94d9-b16f87454250	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2026-01-03	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a4ac5e25-bbf9-4cb3-aca9-8c69ca0d3197	63e3e230-8516-4cb7-b323-440cf28fe175	bad75b03-45a7-4206-89f6-2ca11880b7b1	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-10-24	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-05-16	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7f743e67-fa8e-496d-bf2a-192820a94748	63e3e230-8516-4cb7-b323-440cf28fe175	042a970e-b9cb-4267-b615-d7e25fedf857	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2026-01-05	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f4f4b84a-8a8f-4ebb-895b-8f0683cf1e00	63e3e230-8516-4cb7-b323-440cf28fe175	6c8d3dad-7389-40fa-b3f2-4fb9d6776e44	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-10-30	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e3e7b7ed-5a44-4667-9ecb-f3bf829043e9	dd572bbc-6f68-4046-98b8-36ebbe945667	b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-11-23	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-09-22	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
79cfa946-93a5-4ce1-9cbb-c6f5c32db931	dd572bbc-6f68-4046-98b8-36ebbe945667	bad75b03-45a7-4206-89f6-2ca11880b7b1	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-10-04	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-04-21	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1195d0eb-defe-4c71-a04f-6305353dccad	dd572bbc-6f68-4046-98b8-36ebbe945667	5ddb17a6-3b39-4536-943b-14d152eb20f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-12-29	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-12-29	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f1e2c34d-5c86-4cac-80dc-93f9f2bfcac4	dd572bbc-6f68-4046-98b8-36ebbe945667	042a970e-b9cb-4267-b615-d7e25fedf857	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-10-25	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
8e1b2e9d-20a2-48c7-9981-e4994434288e	dd572bbc-6f68-4046-98b8-36ebbe945667	6c8d3dad-7389-40fa-b3f2-4fb9d6776e44	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2026-01-09	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
07e796e7-bf85-40e7-bf2d-26e2977f58db	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-11-15	4ac83d84-43e6-4389-bf01-f0c0251affb9	2027-01-06	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
4b1fb310-1137-4f8a-8c7c-54c63c5d1e06	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	c7481d48-e30d-4f04-99cc-3bb82abfdf3a	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-10-29	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ac09ae24-d077-4343-96c8-5b1dc25af3e2	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	6c8d3dad-7389-40fa-b3f2-4fb9d6776e44	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-09-04	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1d536810-7943-49bf-ad85-ecffad28d60b	9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	d436ecba-b7fa-42b8-b500-16591bbadb34	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2026-01-12	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-07-06	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
04acb8f8-d564-4fec-9abb-9767fd4a73b7	91e53610-e137-45b7-8dba-974c0953926f	b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-02	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-04-22	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9b66a2ac-ff07-4b06-bbdb-59744cd7bb77	91e53610-e137-45b7-8dba-974c0953926f	dc0b5cce-365b-43df-bae7-b0cec4ec8b24	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2026-01-09	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-08-25	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
dc36c80a-d1fe-420f-8956-5ef753cd726d	91e53610-e137-45b7-8dba-974c0953926f	bad75b03-45a7-4206-89f6-2ca11880b7b1	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2026-01-04	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-07-27	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2eaa0443-493e-4448-a971-83c212b3e418	91e53610-e137-45b7-8dba-974c0953926f	5ddb17a6-3b39-4536-943b-14d152eb20f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-11-19	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-10-10	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a24f96d7-5864-4a1d-ba63-00e429d2a59f	91e53610-e137-45b7-8dba-974c0953926f	042a970e-b9cb-4267-b615-d7e25fedf857	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-10-05	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
e64c0867-36dd-423c-a492-512f539b15da	6b3a2241-2175-4fb2-b7c6-552996ec1cce	b14a723d-15df-4e25-b5c8-7ed6fa10ab1d	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-10-28	4ac83d84-43e6-4389-bf01-f0c0251affb9	2027-02-18	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
cf4be016-4e73-4f4e-aa57-21a76037d5dd	6b3a2241-2175-4fb2-b7c6-552996ec1cce	c7481d48-e30d-4f04-99cc-3bb82abfdf3a	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-12-19	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
24c653ef-4da4-4b6a-bf65-a02d5c6b31b3	6b3a2241-2175-4fb2-b7c6-552996ec1cce	d436ecba-b7fa-42b8-b500-16591bbadb34	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-10-31	4ac83d84-43e6-4389-bf01-f0c0251affb9	2026-10-05	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f54a135a-7e74-4520-b92c-7242726a2298	6b3a2241-2175-4fb2-b7c6-552996ec1cce	6c8d3dad-7389-40fa-b3f2-4fb9d6776e44	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-07	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c45458e6-e048-487a-bedc-7a8e080cb289	a13df553-f991-456a-9401-7c90bc033e88	5b5e05cc-ab7d-4aea-94d9-b16f87454250	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-11-22	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5e31b119-e12f-41a2-bc3f-56a5cf39b16e	a13df553-f991-456a-9401-7c90bc033e88	2ef5fc7b-4fd2-4c20-93d1-c39e5f57cda8	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2026-01-11	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d1ab6d01-1eca-4686-a9b4-19c2c29b0ee0	a13df553-f991-456a-9401-7c90bc033e88	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-12-17	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
56960b94-82d7-4a3a-ae2f-986a12835724	a13df553-f991-456a-9401-7c90bc033e88	38bcfae5-40ce-40ca-83f3-6ec590124b00	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-09-15	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1581542f-cda1-4898-ac80-2a17810dac01	a13df553-f991-456a-9401-7c90bc033e88	1977b095-dd8e-4f7c-b0ea-a3a7c8a4225f	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-11-28	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5e52890e-33b0-44d6-9436-a4ac893c3aaf	a13df553-f991-456a-9401-7c90bc033e88	4a33d04d-b931-4738-b062-736a30a506ce	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-19	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
9db5fa98-d8e7-4a3e-be81-525421e33431	76d17f64-9249-46dc-aa2e-97c127c4c0b0	5b5e05cc-ab7d-4aea-94d9-b16f87454250	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-10-03	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7e6427e4-0c71-4df8-b2da-8ce00d085842	76d17f64-9249-46dc-aa2e-97c127c4c0b0	2ef5fc7b-4fd2-4c20-93d1-c39e5f57cda8	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-10-24	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
c664e2f7-3426-42a5-9aee-180373756098	76d17f64-9249-46dc-aa2e-97c127c4c0b0	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-11-21	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
d45f898b-4b09-4315-8ecf-2a2dceb46186	76d17f64-9249-46dc-aa2e-97c127c4c0b0	a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-09-09	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
be2f56a9-e1f6-465f-9852-313d75db2c88	9bdd4897-c917-4304-bbc4-cf6ee4579def	5b5e05cc-ab7d-4aea-94d9-b16f87454250	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-04	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
bb2da921-5e8f-4d6a-8443-aa98f58b2b70	9bdd4897-c917-4304-bbc4-cf6ee4579def	2ef5fc7b-4fd2-4c20-93d1-c39e5f57cda8	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-11-07	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6089d264-1008-49da-bd9e-b41ded58b0e5	9bdd4897-c917-4304-bbc4-cf6ee4579def	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2026-01-15	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
6233554d-8515-44eb-ac9d-3ebb30ff5e84	9bdd4897-c917-4304-bbc4-cf6ee4579def	a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-02	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
137c9e56-def1-4852-8010-5da83c62d91e	92558eff-94d2-4abb-9c7e-5e1dd0faa398	5b5e05cc-ab7d-4aea-94d9-b16f87454250	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2026-01-21	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
959b4189-ab7b-45c8-932d-20e7d03b22e5	92558eff-94d2-4abb-9c7e-5e1dd0faa398	2ef5fc7b-4fd2-4c20-93d1-c39e5f57cda8	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-11-10	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
daf167ff-dba8-4370-a034-3ab494f421ce	92558eff-94d2-4abb-9c7e-5e1dd0faa398	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-10-19	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
35afb8e2-3a87-413c-94ef-f687cef54960	549dd47f-510d-4315-aa26-8dc131f272b2	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-11-22	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
1ffea342-2174-48e3-94c1-457183f2908a	549dd47f-510d-4315-aa26-8dc131f272b2	1977b095-dd8e-4f7c-b0ea-a3a7c8a4225f	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2026-01-13	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a07e480c-d226-466b-92bb-a7936a809eac	549dd47f-510d-4315-aa26-8dc131f272b2	c7481d48-e30d-4f04-99cc-3bb82abfdf3a	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-06	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
059d238a-8c2d-4363-95d0-896d81fc831b	549dd47f-510d-4315-aa26-8dc131f272b2	38bcfae5-40ce-40ca-83f3-6ec590124b00	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-09-06	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0a326722-a4cc-4db1-ac19-83816dcc6201	549dd47f-510d-4315-aa26-8dc131f272b2	4a33d04d-b931-4738-b062-736a30a506ce	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-11-10	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
789d9cdb-2afd-499b-8bbc-f672a9acc63c	77f58837-3712-4af6-b549-4de11804561d	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-12-06	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a646e375-6b28-4b16-a0be-d390104bf80f	77f58837-3712-4af6-b549-4de11804561d	38bcfae5-40ce-40ca-83f3-6ec590124b00	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-09-24	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
a36708cb-25c0-40f6-8df4-7d012b29c584	77f58837-3712-4af6-b549-4de11804561d	a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-10-20	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
2e9a392f-421c-4f1d-9388-c6e5632e5260	5eb86614-6fc0-49ac-97e3-601d92788d24	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-10-04	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7ca38205-c03e-4680-b628-a688208139c9	5eb86614-6fc0-49ac-97e3-601d92788d24	c7481d48-e30d-4f04-99cc-3bb82abfdf3a	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-12-24	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
86b6c2e5-d6fb-432b-ad74-4ef1280db14a	5eb86614-6fc0-49ac-97e3-601d92788d24	a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-11-23	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
671181e2-256e-4655-83d3-d5b81a4b5d24	351b506c-39db-4960-bd2f-ffa52ca3bc87	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-12-25	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
66d303ee-9395-4f5a-82c6-41418aec7e5e	351b506c-39db-4960-bd2f-ffa52ca3bc87	a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-11-27	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7b5bebd0-6ca0-4291-b09f-89b667b4d902	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	1977b095-dd8e-4f7c-b0ea-a3a7c8a4225f	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-09-08	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
02fcf5cc-76cf-45f8-bd0a-f3c76041e548	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-09-14	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7b9679c0-fdb9-4d2f-8aa1-0f0f5d8f1907	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-11-23	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
679931fd-3233-456a-a875-206e84a565a7	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	38bcfae5-40ce-40ca-83f3-6ec590124b00	db8b3402-39f2-455b-8d28-4d8279ca46c0	expert	2025-09-02	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
5a3cad0d-938e-44b2-83d1-d7d5c12cf75d	a6c1ea43-ed62-4b24-bae1-582d0897a6e8	4a33d04d-b931-4738-b062-736a30a506ce	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-10-12	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3eedd23a-c1a9-46f0-9735-0c1ef588e2e0	86e6ea5d-5142-4c37-b94f-af48785430c9	1977b095-dd8e-4f7c-b0ea-a3a7c8a4225f	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-09-02	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
0f40a89c-2a60-4c37-bea3-dd4585363272	86e6ea5d-5142-4c37-b94f-af48785430c9	a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-10-19	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
ea2a0dba-0269-4909-a528-5cce92de7c65	86e6ea5d-5142-4c37-b94f-af48785430c9	38bcfae5-40ce-40ca-83f3-6ec590124b00	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-10-29	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
3c92f5dc-6953-4911-8dde-fc289276e3b6	86e6ea5d-5142-4c37-b94f-af48785430c9	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	practitioner	2025-12-04	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
7150d8f7-285c-4e35-8828-514555edfdfd	e78e0255-f170-45a0-993d-83d0655d0fff	c7481d48-e30d-4f04-99cc-3bb82abfdf3a	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-12-25	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
f8b70a8b-74fe-4157-806e-ad8bce23a498	e78e0255-f170-45a0-993d-83d0655d0fff	a7246568-167d-4a6d-89c8-02872d4d01f4	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-09-21	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
30a7b1de-0cb2-4a7e-befe-bd3eb11642da	e78e0255-f170-45a0-993d-83d0655d0fff	635b4a1b-3168-4382-8650-414cd946ba6c	db8b3402-39f2-455b-8d28-4d8279ca46c0	awareness	2025-09-25	4ac83d84-43e6-4389-bf01-f0c0251affb9	\N	\N	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.users (id, name, email, password_hash, initials, colour, avatar_url, role, pin_on_top, workspace_id, created_at, updated_at, notification_prefs, totp_secret, totp_enabled) FROM stdin;
4ac83d84-43e6-4389-bf01-f0c0251affb9	Bill Sherwood	billforrestuk@gmail.com	$2b$12$mn/kzJodL6iUomzq3blFsOdGN0GNRGXE7WeTSx2Rs1bFySoD0RrCG	BS	#4186E0	\N	owner	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
b4975c2d-f9bd-4f8f-86d4-1ac161714b6b	Bob Smith	bob@acme.com	$2b$12$4skSs./sdt1HwddzG5mf5.5hrSA703S3nkj.eZrLQRawx88HgBaUm	BS	#E44332	\N	admin	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
933be77b-5ee8-4c1c-ad5c-0c104b1d4942	Charlie Brown	charlie@acme.com	$2b$12$RQr4F1K8OZd9ONQ/Jg5/qeNr9suSNm4KDb1g5.S5/FkhbERy4dkLW	CB	#5CBF4D	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
a13df553-f991-456a-9401-7c90bc033e88	Diana Prince	diana@acme.com	$2b$12$OXyrCys.3UxxNDI8rw5Y7OAWa2Zh3ckvWiTGvsVw.Zyda2Qsm3Nn6	DP	#9B59B6	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
549dd47f-510d-4315-aa26-8dc131f272b2	Eve Davis	eve@acme.com	$2b$12$3sRMzDCAFiKokjbR2z.g5.sB8ftf79.QzM3fiij27X8fi7oe0MLke	ED	#F0C239	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
edc56289-b344-42c3-a6a3-4d3e014d5812	Frank Wilson	frank@acme.com	$2b$12$Db6n0n2QlKePCK.Zk0prruIKiQXk6wPl9HOqsYOtht7qXzTWhXs1W	FW	#1ABC9C	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
76d17f64-9249-46dc-aa2e-97c127c4c0b0	Grace Lee	grace@acme.com	$2b$12$saP/AySvplP5zvM5fy/m3Oh..DQtuume3ktndtrAK7NqCMGhnXwfW	GL	#E67E22	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
77f58837-3712-4af6-b549-4de11804561d	Henry Taylor	henry@acme.com	$2b$12$sQdiQ1.dSRq007xljdHi8uuJKKxGNxQW8aSsCm68fU6iDN.V/wuQm	HT	#3498DB	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
63e3e230-8516-4cb7-b323-440cf28fe175	Ivy Chen	ivy@acme.com	$2b$12$nBtc7AFo3qmd.RXT5/wIWOLjMnxhL2mdw62vWn0uz.jwFHQL2t83e	IC	#E74C3C	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
dd572bbc-6f68-4046-98b8-36ebbe945667	Jack Morgan	jack@acme.com	$2b$12$JE0g6E0HWzoZQZ0n8AwVw.1YwImvPCl86PvMznpHwI5rGEPr.vUQ.	JM	#2ECC71	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
9bdd4897-c917-4304-bbc4-cf6ee4579def	Karen Patel	karen@acme.com	$2b$12$ksoThqFtRAWxC58QdsxxmeipF/AxH/NR9H6dBKmVuSwqVFRly2wM2	KP	#F39C12	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
a6c1ea43-ed62-4b24-bae1-582d0897a6e8	Liam O'Brien	liam@acme.com	$2b$12$FkcC94ENIJvJn0.Vmresse0lYg.fldc5MLHgnEPbAsCCgN9qxjpqO	LO	#8E44AD	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
9fa32f3a-e6b3-49a0-8c9e-bcf5e789c3d8	Mia Thompson	mia@acme.com	$2b$12$A5kghn8gVYm8aZXL.d/tf.Z5mcEiFDnhpHyvxKnGCrhzFuI2My5vG	MT	#16A085	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
5eb86614-6fc0-49ac-97e3-601d92788d24	Noah Garcia	noah@acme.com	$2b$12$q1.PI03ZSHqjw07iVALVHeY.wrd7Hr0ZY/tPmn8T/wqE1W3k24jwC	NG	#D35400	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
86e6ea5d-5142-4c37-b94f-af48785430c9	Olivia Hughes	olivia@acme.com	$2b$12$.u/YLfxoDyguZFxXmmz/kuwKTtq.olMk3grQoqa5N5I.WWbd21in2	OH	#2980B9	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
91e53610-e137-45b7-8dba-974c0953926f	Pete Robinson	pete@acme.com	$2b$12$8GEABYKuKi6X.rncKic3w.TWUnHHMxeVJB8IkpZydpwTzJk2YqbYe	PR	#27AE60	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
e78e0255-f170-45a0-993d-83d0655d0fff	Quinn Foster	quinn@acme.com	$2b$12$N4lqNDUv14N5UQYfnOy1xeEfyAuKlHLU1MMmy9T5aJGyqytHouCGq	QF	#C0392B	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
92558eff-94d2-4abb-9c7e-5e1dd0faa398	Rachel Kim	rachel@acme.com	$2b$12$Z3hx1a280G5awko4/.feQ.PagN1vRd65HIdsskmagrk0wT1KfcELG	RK	#7D3C98	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
6b3a2241-2175-4fb2-b7c6-552996ec1cce	Sam Martinez	sam@acme.com	$2b$12$wtVIvzpDWHY261n4bz569O2RFcVqLE2eDqgodTLWG5ucsKetfMhYW	SM	#148F77	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
351b506c-39db-4960-bd2f-ffa52ca3bc87	Tanya Novak	tanya@acme.com	$2b$12$Ndchrqk2x8lvLk0/bT9.zuOuym4S4di5vNg63SISdFnAIHvQRca9m	TN	#D68910	\N	regular	f	db8b3402-39f2-455b-8d28-4d8279ca46c0	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	\N	\N	f
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.webhook_logs (id, event, payload, response_status, response_body, success, webhook_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.webhooks (id, name, url, secret, events, is_active, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: planview
--

COPY public.workspaces (id, name, created_at, updated_at, enabled_modules) FROM stdin;
db8b3402-39f2-455b-8d28-4d8279ca46c0	Acme Corp	2026-02-28 09:34:27.379447+00	2026-02-28 09:34:27.379447+00	{}
\.


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_messages ai_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_sessions ai_chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: analysis_reports analysis_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.analysis_reports
    ADD CONSTRAINT analysis_reports_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: candidate_events candidate_events_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidate_events
    ADD CONSTRAINT candidate_events_pkey PRIMARY KEY (id);


--
-- Name: candidates candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidates
    ADD CONSTRAINT candidates_pkey PRIMARY KEY (id);


--
-- Name: checklists checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.checklists
    ADD CONSTRAINT checklists_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: competencies competencies_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.competencies
    ADD CONSTRAINT competencies_pkey PRIMARY KEY (id);


--
-- Name: compliance_items compliance_items_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.compliance_items
    ADD CONSTRAINT compliance_items_pkey PRIMARY KEY (id);


--
-- Name: custom_field_values custom_field_values_field_id_task_id_key; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_field_id_task_id_key UNIQUE (field_id, task_id);


--
-- Name: custom_field_values custom_field_values_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: development_goals development_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_goals
    ADD CONSTRAINT development_goals_pkey PRIMARY KEY (id);


--
-- Name: development_plans development_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_plans
    ADD CONSTRAINT development_plans_pkey PRIMARY KEY (id);


--
-- Name: key_results key_results_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.key_results
    ADD CONSTRAINT key_results_pkey PRIMARY KEY (id);


--
-- Name: kudos kudos_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.kudos
    ADD CONSTRAINT kudos_pkey PRIMARY KEY (id);


--
-- Name: leave_allowances leave_allowances_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_allowances
    ADD CONSTRAINT leave_allowances_pkey PRIMARY KEY (id);


--
-- Name: leave_requests leave_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_pkey PRIMARY KEY (id);


--
-- Name: meeting_actions meeting_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_pkey PRIMARY KEY (id);


--
-- Name: meetings meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: objectives objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_pkey PRIMARY KEY (id);


--
-- Name: onboarding_checklist_items onboarding_checklist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklist_items
    ADD CONSTRAINT onboarding_checklist_items_pkey PRIMARY KEY (id);


--
-- Name: onboarding_checklists onboarding_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_pkey PRIMARY KEY (id);


--
-- Name: onboarding_template_items onboarding_template_items_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_template_items
    ADD CONSTRAINT onboarding_template_items_pkey PRIMARY KEY (id);


--
-- Name: onboarding_templates onboarding_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_templates
    ADD CONSTRAINT onboarding_templates_pkey PRIMARY KEY (id);


--
-- Name: person_documents person_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_documents
    ADD CONSTRAINT person_documents_pkey PRIMARY KEY (id);


--
-- Name: person_profiles person_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_pkey PRIMARY KEY (id);


--
-- Name: person_profiles person_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_user_id_key UNIQUE (user_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: pulse_responses pulse_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_responses
    ADD CONSTRAINT pulse_responses_pkey PRIMARY KEY (id);


--
-- Name: pulse_surveys pulse_surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_surveys
    ADD CONSTRAINT pulse_surveys_pkey PRIMARY KEY (id);


--
-- Name: review_cycles review_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.review_cycles
    ADD CONSTRAINT review_cycles_pkey PRIMARY KEY (id);


--
-- Name: review_periods review_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.review_periods
    ADD CONSTRAINT review_periods_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: rota_entries rota_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rota_entries
    ADD CONSTRAINT rota_entries_pkey PRIMARY KEY (id);


--
-- Name: rotas rotas_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rotas
    ADD CONSTRAINT rotas_pkey PRIMARY KEY (id);


--
-- Name: segments segments_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.segments
    ADD CONSTRAINT segments_pkey PRIMARY KEY (id);


--
-- Name: shared_timelines shared_timelines_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.shared_timelines
    ADD CONSTRAINT shared_timelines_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: task_assignees task_assignees_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_assignees
    ADD CONSTRAINT task_assignees_pkey PRIMARY KEY (task_id, user_id);


--
-- Name: task_dependencies task_dependencies_blocker_id_blocked_id_key; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_blocker_id_blocked_id_key UNIQUE (blocker_id, blocked_id);


--
-- Name: task_dependencies task_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_pkey PRIMARY KEY (id);


--
-- Name: task_tags task_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_pkey PRIMARY KEY (task_id, tag_id);


--
-- Name: task_templates task_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_templates
    ADD CONSTRAINT task_templates_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (team_id, user_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: time_off time_off_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_off
    ADD CONSTRAINT time_off_pkey PRIMARY KEY (id);


--
-- Name: user_competencies user_competencies_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: ix_activity_workspace_created; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_activity_workspace_created ON public.activities USING btree (workspace_id, created_at);


--
-- Name: ix_ai_chat_messages_session_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_ai_chat_messages_session_id ON public.ai_chat_messages USING btree (session_id);


--
-- Name: ix_ai_chat_sessions_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_ai_chat_sessions_user_id ON public.ai_chat_sessions USING btree (user_id);


--
-- Name: ix_ai_chat_sessions_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_ai_chat_sessions_workspace_id ON public.ai_chat_sessions USING btree (workspace_id);


--
-- Name: ix_analysis_reports_report_type; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_analysis_reports_report_type ON public.analysis_reports USING btree (report_type);


--
-- Name: ix_analysis_reports_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_analysis_reports_user_id ON public.analysis_reports USING btree (user_id);


--
-- Name: ix_analysis_reports_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_analysis_reports_workspace_id ON public.analysis_reports USING btree (workspace_id);


--
-- Name: ix_attachment_task; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_attachment_task ON public.attachments USING btree (task_id);


--
-- Name: ix_candidates_status; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_candidates_status ON public.candidates USING btree (status);


--
-- Name: ix_candidates_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_candidates_workspace_id ON public.candidates USING btree (workspace_id);


--
-- Name: ix_checklist_task_sort; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_checklist_task_sort ON public.checklists USING btree (task_id, sort_order);


--
-- Name: ix_comment_task_created; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_comment_task_created ON public.comments USING btree (task_id, created_at);


--
-- Name: ix_compliance_items_expiry; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_compliance_items_expiry ON public.compliance_items USING btree (expiry_date);


--
-- Name: ix_compliance_items_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_compliance_items_user_id ON public.compliance_items USING btree (user_id);


--
-- Name: ix_leave_allowances_user_year; Type: INDEX; Schema: public; Owner: planview
--

CREATE UNIQUE INDEX ix_leave_allowances_user_year ON public.leave_allowances USING btree (user_id, year);


--
-- Name: ix_leave_requests_dates; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_leave_requests_dates ON public.leave_requests USING btree (start_date, end_date);


--
-- Name: ix_leave_requests_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_leave_requests_user_id ON public.leave_requests USING btree (user_id);


--
-- Name: ix_meeting_actions_meeting_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_meeting_actions_meeting_id ON public.meeting_actions USING btree (meeting_id);


--
-- Name: ix_meetings_manager_report; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_meetings_manager_report ON public.meetings USING btree (manager_id, report_id);


--
-- Name: ix_meetings_scheduled_date; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_meetings_scheduled_date ON public.meetings USING btree (scheduled_date);


--
-- Name: ix_meetings_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_meetings_workspace_id ON public.meetings USING btree (workspace_id);


--
-- Name: ix_notification_user_unread; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_notification_user_unread ON public.notifications USING btree (user_id, workspace_id, is_read, created_at);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_notifications_workspace_user; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_notifications_workspace_user ON public.notifications USING btree (workspace_id, user_id, is_read);


--
-- Name: ix_objectives_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_objectives_user_id ON public.objectives USING btree (user_id);


--
-- Name: ix_objectives_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_objectives_workspace_id ON public.objectives USING btree (workspace_id);


--
-- Name: ix_person_documents_document_type; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_documents_document_type ON public.person_documents USING btree (document_type);


--
-- Name: ix_person_documents_expiry_date; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_documents_expiry_date ON public.person_documents USING btree (expiry_date);


--
-- Name: ix_person_documents_profile_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_documents_profile_id ON public.person_documents USING btree (profile_id);


--
-- Name: ix_person_documents_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_documents_workspace_id ON public.person_documents USING btree (workspace_id);


--
-- Name: ix_person_profiles_department; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_profiles_department ON public.person_profiles USING btree (department);


--
-- Name: ix_person_profiles_manager_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_profiles_manager_id ON public.person_profiles USING btree (manager_id);


--
-- Name: ix_person_profiles_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_person_profiles_workspace_id ON public.person_profiles USING btree (workspace_id);


--
-- Name: ix_project_workspace; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_project_workspace ON public.projects USING btree (workspace_id);


--
-- Name: ix_rota_entries_dates; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_rota_entries_dates ON public.rota_entries USING btree (date_from, date_to);


--
-- Name: ix_rota_entries_rota_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_rota_entries_rota_id ON public.rota_entries USING btree (rota_id);


--
-- Name: ix_rota_entries_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_rota_entries_user_id ON public.rota_entries USING btree (user_id);


--
-- Name: ix_rotas_workspace_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_rotas_workspace_id ON public.rotas USING btree (workspace_id);


--
-- Name: ix_segment_project; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_segment_project ON public.segments USING btree (project_id);


--
-- Name: ix_shared_timelines_token; Type: INDEX; Schema: public; Owner: planview
--

CREATE UNIQUE INDEX ix_shared_timelines_token ON public.shared_timelines USING btree (token);


--
-- Name: ix_tag_project; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_tag_project ON public.tags USING btree (project_id);


--
-- Name: ix_task_assignees_user_task; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_assignees_user_task ON public.task_assignees USING btree (user_id, task_id);


--
-- Name: ix_task_parent_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_parent_id ON public.tasks USING btree (parent_id);


--
-- Name: ix_task_project_status; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_project_status ON public.tasks USING btree (project_id, status);


--
-- Name: ix_task_recurring; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_recurring ON public.tasks USING btree (workspace_id) WHERE (is_recurring = true);


--
-- Name: ix_task_sort_order; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_sort_order ON public.tasks USING btree (project_id, sort_order);


--
-- Name: ix_task_workspace_dates; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_workspace_dates ON public.tasks USING btree (workspace_id, date_from, date_to);


--
-- Name: ix_task_workspace_status; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_task_workspace_status ON public.tasks USING btree (workspace_id, status);


--
-- Name: ix_taskdep_blocked; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_taskdep_blocked ON public.task_dependencies USING btree (blocked_id);


--
-- Name: ix_taskdep_blocker; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_taskdep_blocker ON public.task_dependencies USING btree (blocker_id);


--
-- Name: ix_team_members_team_user; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_team_members_team_user ON public.team_members USING btree (team_id, user_id);


--
-- Name: ix_time_off_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_time_off_user_id ON public.time_off USING btree (user_id);


--
-- Name: ix_user_competencies_competency_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_user_competencies_competency_id ON public.user_competencies USING btree (competency_id);


--
-- Name: ix_user_competencies_user_id; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_user_competencies_user_id ON public.user_competencies USING btree (user_id);


--
-- Name: ix_user_email; Type: INDEX; Schema: public; Owner: planview
--

CREATE UNIQUE INDEX ix_user_email ON public.users USING btree (email);


--
-- Name: ix_user_workspace; Type: INDEX; Schema: public; Owner: planview
--

CREATE INDEX ix_user_workspace ON public.users USING btree (workspace_id);


--
-- Name: activities activities_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: activities activities_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: ai_chat_messages ai_chat_messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.ai_chat_sessions(id) ON DELETE CASCADE;


--
-- Name: ai_chat_sessions ai_chat_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_chat_sessions ai_chat_sessions_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: analysis_reports analysis_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.analysis_reports
    ADD CONSTRAINT analysis_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: analysis_reports analysis_reports_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.analysis_reports
    ADD CONSTRAINT analysis_reports_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: candidate_events candidate_events_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidate_events
    ADD CONSTRAINT candidate_events_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON DELETE CASCADE;


--
-- Name: candidate_events candidate_events_interviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidate_events
    ADD CONSTRAINT candidate_events_interviewer_id_fkey FOREIGN KEY (interviewer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: candidates candidates_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.candidates
    ADD CONSTRAINT candidates_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: checklists checklists_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.checklists
    ADD CONSTRAINT checklists_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: clients clients_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: comments comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: comments comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: competencies competencies_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.competencies
    ADD CONSTRAINT competencies_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: compliance_items compliance_items_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.compliance_items
    ADD CONSTRAINT compliance_items_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.person_documents(id) ON DELETE SET NULL;


--
-- Name: compliance_items compliance_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.compliance_items
    ADD CONSTRAINT compliance_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: compliance_items compliance_items_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.compliance_items
    ADD CONSTRAINT compliance_items_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: custom_field_values custom_field_values_field_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_field_id_fkey FOREIGN KEY (field_id) REFERENCES public.custom_fields(id) ON DELETE CASCADE;


--
-- Name: custom_field_values custom_field_values_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: custom_fields custom_fields_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: development_goals development_goals_linked_competency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_goals
    ADD CONSTRAINT development_goals_linked_competency_id_fkey FOREIGN KEY (linked_competency_id) REFERENCES public.competencies(id) ON DELETE SET NULL;


--
-- Name: development_goals development_goals_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_goals
    ADD CONSTRAINT development_goals_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.development_plans(id) ON DELETE CASCADE;


--
-- Name: development_plans development_plans_review_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_plans
    ADD CONSTRAINT development_plans_review_period_id_fkey FOREIGN KEY (review_period_id) REFERENCES public.review_periods(id) ON DELETE SET NULL;


--
-- Name: development_plans development_plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_plans
    ADD CONSTRAINT development_plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: development_plans development_plans_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.development_plans
    ADD CONSTRAINT development_plans_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: tasks fk_task_parent; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_task_parent FOREIGN KEY (parent_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: key_results key_results_objective_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.key_results
    ADD CONSTRAINT key_results_objective_id_fkey FOREIGN KEY (objective_id) REFERENCES public.objectives(id) ON DELETE CASCADE;


--
-- Name: kudos kudos_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.kudos
    ADD CONSTRAINT kudos_from_user_id_fkey FOREIGN KEY (from_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kudos kudos_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.kudos
    ADD CONSTRAINT kudos_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kudos kudos_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.kudos
    ADD CONSTRAINT kudos_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: leave_allowances leave_allowances_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_allowances
    ADD CONSTRAINT leave_allowances_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: leave_allowances leave_allowances_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_allowances
    ADD CONSTRAINT leave_allowances_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: leave_requests leave_requests_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: leave_requests leave_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: leave_requests leave_requests_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: meeting_actions meeting_actions_carried_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_carried_from_id_fkey FOREIGN KEY (carried_from_id) REFERENCES public.meeting_actions(id) ON DELETE SET NULL;


--
-- Name: meeting_actions meeting_actions_meeting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_meeting_id_fkey FOREIGN KEY (meeting_id) REFERENCES public.meetings(id) ON DELETE CASCADE;


--
-- Name: meeting_actions meeting_actions_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: meetings meetings_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: meetings meetings_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: meetings meetings_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: milestones milestones_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: milestones milestones_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: objectives objectives_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.objectives(id) ON DELETE SET NULL;


--
-- Name: objectives objectives_review_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_review_period_id_fkey FOREIGN KEY (review_period_id) REFERENCES public.review_periods(id) ON DELETE SET NULL;


--
-- Name: objectives objectives_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: objectives objectives_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: onboarding_checklist_items onboarding_checklist_items_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklist_items
    ADD CONSTRAINT onboarding_checklist_items_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: onboarding_checklist_items onboarding_checklist_items_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklist_items
    ADD CONSTRAINT onboarding_checklist_items_checklist_id_fkey FOREIGN KEY (checklist_id) REFERENCES public.onboarding_checklists(id) ON DELETE CASCADE;


--
-- Name: onboarding_checklists onboarding_checklists_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.onboarding_templates(id) ON DELETE SET NULL;


--
-- Name: onboarding_checklists onboarding_checklists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: onboarding_checklists onboarding_checklists_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: onboarding_template_items onboarding_template_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_template_items
    ADD CONSTRAINT onboarding_template_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.onboarding_templates(id) ON DELETE CASCADE;


--
-- Name: onboarding_templates onboarding_templates_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.onboarding_templates
    ADD CONSTRAINT onboarding_templates_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: person_documents person_documents_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_documents
    ADD CONSTRAINT person_documents_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.person_profiles(id) ON DELETE CASCADE;


--
-- Name: person_documents person_documents_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_documents
    ADD CONSTRAINT person_documents_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: person_documents person_documents_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_documents
    ADD CONSTRAINT person_documents_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: person_profiles person_profiles_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: person_profiles person_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: person_profiles person_profiles_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.person_profiles
    ADD CONSTRAINT person_profiles_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: projects projects_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: projects projects_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: pulse_responses pulse_responses_survey_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_responses
    ADD CONSTRAINT pulse_responses_survey_id_fkey FOREIGN KEY (survey_id) REFERENCES public.pulse_surveys(id) ON DELETE CASCADE;


--
-- Name: pulse_responses pulse_responses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_responses
    ADD CONSTRAINT pulse_responses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: pulse_surveys pulse_surveys_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.pulse_surveys
    ADD CONSTRAINT pulse_surveys_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: review_cycles review_cycles_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.review_cycles
    ADD CONSTRAINT review_cycles_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: review_periods review_periods_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.review_periods
    ADD CONSTRAINT review_periods_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_cycle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES public.review_cycles(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: rota_entries rota_entries_rota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rota_entries
    ADD CONSTRAINT rota_entries_rota_id_fkey FOREIGN KEY (rota_id) REFERENCES public.rotas(id) ON DELETE CASCADE;


--
-- Name: rota_entries rota_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rota_entries
    ADD CONSTRAINT rota_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rota_entries rota_entries_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rota_entries
    ADD CONSTRAINT rota_entries_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: rotas rotas_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.rotas
    ADD CONSTRAINT rotas_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: segments segments_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.segments
    ADD CONSTRAINT segments_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: shared_timelines shared_timelines_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.shared_timelines
    ADD CONSTRAINT shared_timelines_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: shared_timelines shared_timelines_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.shared_timelines
    ADD CONSTRAINT shared_timelines_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: shared_timelines shared_timelines_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.shared_timelines
    ADD CONSTRAINT shared_timelines_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: tags tags_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: task_assignees task_assignees_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_assignees
    ADD CONSTRAINT task_assignees_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_assignees task_assignees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_assignees
    ADD CONSTRAINT task_assignees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_dependencies task_dependencies_blocked_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_blocked_id_fkey FOREIGN KEY (blocked_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_dependencies task_dependencies_blocker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_blocker_id_fkey FOREIGN KEY (blocker_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_templates task_templates_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.task_templates
    ADD CONSTRAINT task_templates_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: teams teams_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: time_off time_off_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_off
    ADD CONSTRAINT time_off_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: time_off time_off_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.time_off
    ADD CONSTRAINT time_off_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: user_competencies user_competencies_assessed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_assessed_by_fkey FOREIGN KEY (assessed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_competencies user_competencies_competency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_competency_id_fkey FOREIGN KEY (competency_id) REFERENCES public.competencies(id) ON DELETE CASCADE;


--
-- Name: user_competencies user_competencies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_competencies user_competencies_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.user_competencies
    ADD CONSTRAINT user_competencies_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: users users_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: webhook_logs webhook_logs_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planview
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: planview
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict UUQJG5iwpLXxlYaAcVgfAYXvwn0eTA6zkeymztynsIZxIg6ME41pmaee0Z9mFyS

